/* Watchdog Timer kapal�, "INTOSC with I/0 function" etkin, Brown-out Reset kapal�, MCLR kapal�*/

#define JETON GPIO.GP3
#define SENSOR GPIO.GP4
#define MOTOR GPIO.GP0
unsigned short sayac=0, zaman=0;
void main() {
 TRISIO=0X18;//GP3 ve GP4 pinleri giri� yap�l�yor
 GPIO=0; // Port temizleniyor
// OPTION_REG=0X8F; // �n�l�ekleyici WDT i�in tahsis edildi ve 128 de�erinde (2,3sn), dahili pull-up'lar kapal�
 INTCON.GIE=1; //Evrensel kesme aktif
 INTCON.PEIE=1; //�evresel ayg�t kesmesi aktif
 INTCON.GPIE=1; //Port durum de�i�im kesmesi aktif
 PIE1.TMR1IE=1; //Timer1 kesmesi aktif
 IOC=0X18;//GP3 ve GP4 giri� kesmeleri aktifle�tiriliyor
 T1CON=0B01110000;
 TMR1L=0xDC;
 TMR1H=0x0B;  //3036 ba�lang�� de�eri
 Delay_ms(10);
 T1CON.TMR1ON=1;
 while(1){
  if(zaman>20){  // Motor maksimum 2sn kadar �al���yor
   sayac=0;
   zaman=0;
   MOTOR=0;
  }
  if(SENSOR){
   if(zaman>0){
    sayac=0;
    zaman=0;
    MOTOR=0;
   }
  }
 }
}
void interrupt(){
  if(INTCON.GPIF){
   if(JETON){
    sayac++;
    zaman=0;
    if(sayac>2){
     MOTOR=1;
    }
   } /*
   else if(SENSOR){
    sayac=0;
    zaman=0;
    MOTOR=0;
   } */
   INTCON.GPIF=0;
  }

  if(PIR1.TMR1IF){
   zaman++;
   T1CON.TMR1ON=0;
   Delay_us(50);
   TMR1H=0X0B;    //S�re = 4*Prescaler*(65536-3036)*______1______ = 0,5sn
   TMR1L=0XDC;    //                                4.000.000
   T1CON.TMR1ON=1;
   PIR1.TMR1IF=0;
 }
}