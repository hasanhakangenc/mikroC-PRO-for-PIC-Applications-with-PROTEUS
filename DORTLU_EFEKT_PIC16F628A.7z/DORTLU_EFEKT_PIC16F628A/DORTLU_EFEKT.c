char efekt=0;
void bekle(){
 Delay_ms(250);
}
void bos(){
 PORTA=0;
 PORTB=0;
}
void karasimsek(){
// while(1){
  PORTA = 0B10000000;  //d��ardan i�eriye efekt yap�l�yor
  PORTB = 0B00000010;
  bekle();
  PORTA = 0B01000000;
  PORTB = 0B00000100;
  bekle();
  PORTA = 0B00001000;
  PORTB = 0B00001000;
  bekle();
  PORTA = 0B00000100;
  PORTB = 0B00010000;
  bekle();
  PORTA = 0B00000010;
  PORTB = 0B00100000;
  bekle();
  PORTA = 0B00000001;
  PORTB = 0B01000000;
  bekle();
  
  PORTA = 0B00000010;  //i�erden d��ar�ya efekt yap�l�yor
  PORTB = 0B00100000;
  bekle();
  PORTA = 0B00000100;
  PORTB = 0B00010000;
  bekle();
  PORTA = 0B00001000;
  PORTB = 0B00001000;
  bekle();
  PORTA = 0B01000000;
  PORTB = 0B00000100;
  bekle();
  PORTA = 0B10000000;
  PORTB = 0B00000010;
  bekle();
 //}
}

void tek_cift(){
 //while(1){
  PORTA=0B01000101;
  PORTB=0B00101010;
  bekle();
  PORTA=0B10001010;
  PORTB=0B01010100;
  bekle();
// }
}

yuruyen_isik(){
  PORTA = 0B10000000;  //soldan saga
  PORTB = 0;
  bekle();
  PORTA = 0B01000000;
  bekle();
  PORTA = 0B00001000;
  bekle();
  PORTA = 0B00000100;
  bekle();
  PORTA = 0B00000010;
  bekle();
  PORTA = 0B00000001;
  bekle();

  PORTA = 0;
  PORTB = 0B01000000;
  bekle();
  PORTB = 0B00100000;
  bekle();
  PORTB = 0B00010000;
  bekle();
  PORTB = 0B00001000;
  bekle();
  PORTB = 0B00000100;
  bekle();
  PORTB = 0B00000010;
  bekle();
  

  PORTB = 0B00000100;  //sagdan sola
  bekle();
  PORTB = 0B00001000;
  bekle();
  PORTB = 0B00010000;
  bekle();
  PORTB = 0B00100000;
  bekle();
  PORTB = 0B01000000;
  bekle();
  
  PORTB = 0;
  PORTA = 0B00000001;
  bekle();
  PORTA = 0B00000010;
  bekle();
  PORTA = 0B00000100;
  bekle();
  PORTA = 0B00000100;
  bekle();
  PORTA = 0B01000000;
  bekle();
  PORTA = 0B10000000;
  bekle();
}

void main() {
 main:
 OPTION_REG = 0;
 TRISA = 0X00;
 TRISB = 0X01;//B0 pini giri� oldu
 PORTA = 0;
 PORTB = 0;
 CMCON = 0X07;//mikrodenetleyici dijital olarak ayarland�
 INTCON.INTE = 1;
 INTCON.GIE = 1;
 while(1){
  switch (efekt){
   case 1: karasimsek();break;
   case 2: tek_cift(); break;
   case 3: yuruyen_isik();break;
   default: bos();
  }
 }
}
void interrupt() org 0x0004{
 if(INTCON.INTF){
  efekt++;
  if(efekt==4) efekt=0;
  INTCON.INTF = 0;
  asm{
   goto main
  }
 }
}