// DAC mod�l ba�lant�lar�
sbit Chip_Select at RC0_bit;  //DAC'� se�me pini
sbit Chip_Select_Direction at TRISC0_bit;

unsigned int value;

// DAC art�m� (0..4095) --> ��k�� voltaj� (0..Vref)
void DAC_Output(unsigned int valueDAC) {
  char temp;

  Chip_Select = 0;                  // DAC �ipini se�

  // Y�ksek byte g�nderiliyor
  temp = (valueDAC >> 8) & 0x0F;  // valueDAC[11..8] de�erini temp[3..0]'a y�kle
  temp |= 0x30;                   // DAC ayar�n� tan�mla, MCP4921 datasheet'ini inceleyin
  SPI1_Write(temp);               // Y�ksek byte'� SPI ile g�nder

  // D���k byte g�nderiliyor
  temp = valueDAC;               // valueDAC[7..0] de�erini temp[7..0]'a y�kle
  SPI1_Write(temp);              // D���k byte'� SPI ile g�nder

  Chip_Select = 1;              // DAC�ipini se�me
}

void main() {
  ANSEL = 0;
  ANSELH = 0;
  TRISA0_bit = 1;              // RA0 pini giri�
  TRISA1_bit = 1;              // RA1 pini giri�
  Chip_Select = 1;             // DAC'� se�me
  Chip_Select_Direction = 0;   // CS# pinini ��k�� olarak ayarla
  SPI1_Init();                 // SPI mod�l�n� haz�rla

  value = 2048;       // Program ba�lad���nda DAC ��k��a
                      // referans seviyesinin orta de�erini verir

 while (1) {                             // Sonsuz d�ng�

    if ((RA0_bit) && (value < 4095)) {   // E�er RA0 butonuna bas�l�rsa
      value++;                           //   de�eri art�r
      }
    else {
      if ((RA1_bit) && (value > 0)) {    // RA1 butonuna bas�l�rsa
        value--;                         // de�eri azalt
        }
      }
    DAC_Output(value);                   // De�eri DAC �ipine g�nder
    Delay_ms(1);                         // Tu� bas�m ad�m�n� yava�lat
  }
}