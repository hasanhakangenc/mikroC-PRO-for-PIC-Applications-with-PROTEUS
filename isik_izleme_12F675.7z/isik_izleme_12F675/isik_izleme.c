// Servo tan�mlamalar� ve de�i�kenleri
#define MAKS_DEGER 200
#define CW_DONUS MAKS_DEGER  - 7
#define CCW_DONUS MAKS_DEGER - 24
#define ESIK_DEGERI 50
#define SERVO GPIO.GP4
#define LED GPIO.GP5
unsigned char maks_darbe=0;
unsigned char darbe_zirvesi=0;
unsigned char zirve_degeri = 0;
unsigned int i;
unsigned char ldr_sol;
unsigned char ldr_sag;
int ldr_fark;
void ayar(){
  TRISIO = 0X03;   //�lk iki port giri� yap�ld�.
  GPIO = 0X00;
  /* Servo ayarlan�yor */
  maks_darbe=0;
  darbe_zirvesi=0;
  zirve_degeri = MAKS_DEGER; // zirve_de�eri = MAX_VALUE ise Servo durduruluyor
  OPTION_REG = 0b10000000; // 1:2 �n �l�ekleme de�eri
  TMR0=206;            // Her 0.1 ms'de bir kesme    2*(256-206)/1.000.000 = 0.1ms
  INTCON.TMR0IE = 1;  // TMR0 kesmesi etkinle�tiriliyor
  INTCON.GIE = 1;    // Evrensel kesme etkin
  /* Port giri�lerinin davran��� belirleniyor ve analog kanal ayarlar� yap�l�yor */
  ANSEL = 0b00010011; //A/D d�n��t�rme h�z� dahili RC h�z�. AN3 ve AN2 kanal� Dijital I/O di�erleri analog giri� yap�ld�.
}
void kontrol(){
 for(i=0;i<10;i++){
  LED = ~LED;
  Delay_ms(50);
 }
 LED=0;
}
static void interrupt(){
  if(TMR0IF_bit) {     // TIMER0 ger�ekle�mi�se
    maks_darbe++;      // Maksimum darbe art�r�l�yor
    darbe_zirvesi++;   // Darbe zirvesi art�r�l�yor
    /* MAKS_DEGER=200 ise darbe de�erleri s�f�rlan�yor. */
    if (maks_darbe >= MAKS_DEGER) {
      maks_darbe=0;
      darbe_zirvesi=0;
      SERVO=0;              // GP4'� durdur
    }
    /* zirve_degeri = MAKS_DEGER - n ise, n=7: 7 x 0.1ms = 0.7ms, n=24: 24 x 0.1ms = 2.4ms */
    /* 0.7ms -> CW Rotation, 2.4ms -> CCW Rotation*/
    if (darbe_zirvesi == zirve_degeri) {
      SERVO=1;              // GP4'� s�r
    }
    TMR0 = 206;             // 0.1ms kesme i�in ilk de�er
    INTCON.TMR0IF = 0;      // TIMER0 kesme bayra�� temizleniyor
  }
}
void main(){
  ayar();
  kontrol();
  while(1) {
    /* ADC burada okunuyor */
    ADCON0=0B00000001;  // ADC portunun AN0 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50); /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;// ldr_sol d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sol=ADRESH;     // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    ADCON0=0B00000101;  // ADC portunun AN1 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50);  /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;  // ldr_sag d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sag=ADRESH;    // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    /* Fark hesaplan�yor */
    ldr_fark=ldr_sol - ldr_sag;
    if ((ldr_fark >= -ESIK_DEGERI) && (ldr_fark <= ESIK_DEGERI)) {
      zirve_degeri = MAKS_DEGER;     // Servo motor durduruluyor
    } else {
      if (ldr_fark > ESIK_DEGERI) {
        zirve_degeri = CCW_DONUS;  // Saat y�n�n�n tersi d�n��
      } else {
        zirve_degeri = CW_DONUS;   // Saat y�n� d�n��
      }
    }
  }
}