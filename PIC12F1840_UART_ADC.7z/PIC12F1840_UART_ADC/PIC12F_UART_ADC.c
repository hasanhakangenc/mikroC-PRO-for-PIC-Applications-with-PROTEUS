#define Version "Version 14/06/2015  "
#define LCD4x20


#define TAB 9
#define CLS 12
#define CR 13
#define LF 10
#define BEEP 7

/*
CONFIG1 : $8007 : 0x0984
CONFIG2 : $8008 : 0x3413
*/

const code char mesg0[]="Test I2C LCD4x20 + ADC avec moy glissante\r\n";
const code char mesg1[]="12F1840  avec interface 2T\r\n";
const code char mesg2[]=Version" MikroC Pro 6.50\r\n";
const code char mesg3[]="UART 19200  FOSC interne  16Mhz\r\n";
const code char * Messages[]={mesg0,mesg1,mesg2,mesg3};

 // timer0
unsigned char  NbCycles_T0 = 30;     //    Nb de fois 16.384 mS

//unsigned long  NbCycles_T1= 7 ;  // 8x125mS=1sec
//65535-62500=3035 @16Mhz et prescaler=8 => 125mS

char buffer[32];
unsigned char *txt;
unsigned char TEXTE[10];//  ="12F1840_Usart_Interrupt_Timer1";


//unsigned short error;
int Index1;
unsigned int CptErr;
unsigned int Count1;
unsigned int Count0;
int Flag_Timer1;
int Flag_Timer0;
int Flag_Buffer;

unsigned char c1;
unsigned int

unsigned int i,j,k,l;
unsigned int M;
unsigned char OldValue;
unsigned char NewValue;
unsigned int Sum;
unsigned char Flag_F;
unsigned char Cpt;
unsigned char Average;
unsigned char FiLo[16];



// --------for test  --------------

//-------------------------
void strConstRamCpy(char *dest, const char *source);
void Write_String(char * texte);
void UART1_Write_CText(const char *txt);
void CRLF(void);
void interrupt(void) ;
void Init_Timer0(void);
void Init_Timer1(void);

#ifdef LCD4x20
#define _LCD_FIRST_ROW          0x80     //Move cursor to the 1st row
#define _LCD_SECOND_ROW         0xC0     //Move cursor to the 2nd row
#define _LCD_THIRD_ROW          0x94     //Move cursor to the 3rd row
#define _LCD_FOURTH_ROW         0xD4     //Move cursor to the 4th row
#define _LCD_CLEAR              0x01     //Clear display
#define _LCD_RETURN_HOME        0x02     //Return cursor to home position, returns a shifted display to
                                         //its original position. Display data RAM is unaffected.
#define _LCD_CURSOR_OFF         0x0C     //Turn off cursor
#define _LCD_UNDERLINE_ON       0x0E     //Underline cursor on
#define _LCD_BLINK_CURSOR_ON    0x0F     //Blink cursor on
#define _LCD_MOVE_CURSOR_LEFT   0x10     //Move cursor left without changing display data RAM
#define _LCD_MOVE_CURSOR_RIGHT  0x14     //Move cursor right without changing display data RAM
#define _LCD_TURN_ON            0x0C     //Turn Lcd display on
#define _LCD_TURN_OFF           0x08     //Turn Lcd display off
#define _LCD_SHIFT_LEFT         0x18     //Shift display left without changing display data RAM
#define _LCD_SHIFT_RIGHT        0x1E     //Shift display right without changing display data RAM

#define  Waddr 0x4E
#endif

void interrupt(void)  org 0x04
{
   // ---- timer 0  --
  if((INTCON.TMR0IE==1)&&( INTCON.TMR0IF==1) )
  {
        TMR0=0;
        Count0++;
       // 16.384 x 61=> 1sec
       // 16.384mS x 122 => 2 secondes
       if (Count0 >NbCycles_T0)
       {
          Count0=0;
          TMR0=0;
          Flag_Timer0=1;
        }
      INTCON.TMR0IF=0;
   }
 }

#ifdef LCD4x20

void I2C_LCD_Cmd(char out_char) {

    char hi_n, lo_n;
    char rs = 0x00;

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(Waddr);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    I2C1_Stop();

    if(out_char == 0x01)Delay_ms(2);
}

void I2C_LCD_Chr(char row, char column, char out_char) {

    char hi_n, lo_n;
    char rs = 0x01;

    switch(row){

        case 1:
        I2C_LCD_Cmd(0x80 + (column - 1));
        break;
        case 2:
        I2C_LCD_Cmd(0xC0 + (column - 1));
        break;
        case 3:
        I2C_LCD_Cmd(0x94 + (column - 1));
        break;
        case 4:
        I2C_LCD_Cmd(0xD4 + (column - 1));
        break;
    };

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(Waddr);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    I2C1_Stop();
}

void I2C_LCD_Chr_Cp(char out_char) {

    char hi_n, lo_n;
    char rs = 0x01;

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(Waddr);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | rs | 0x04 | 0x08);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | rs | 0x00 | 0x08);
    I2C1_Is_Idle();
    I2C1_Stop();
}


void I2C_LCD_Init() {

     char rs = 0x00;

     I2C1_Start();
     I2C1_Is_Idle();
     I2C1_Wr(Waddr);
     I2C1_Is_Idle();

     Delay_ms(30);

     I2C1_Wr(0x30 | rs | 0x04 | 0x08);
     I2C1_Is_Idle();
     Delay_us(50);
     I2C1_Wr(0x30 | rs | 0x00 | 0x08);
     I2C1_Is_Idle();

     Delay_ms(10);

     I2C1_Wr(0x30 | rs | 0x04 | 0x08);
     I2C1_Is_Idle();
     Delay_us(50);
     I2C1_Wr(0x30 | rs | 0x00 | 0x08);
     I2C1_Is_Idle();

     Delay_ms(10);

     I2C1_Wr(0x30 | rs | 0x04 | 0x08);
     I2C1_Is_Idle();
     Delay_us(50);
     I2C1_Wr(0x30 | rs | 0x00 | 0x08);
     I2C1_Is_Idle();

     Delay_ms(10);

     I2C1_Wr(0x20 | rs | 0x04 | 0x08);
     I2C1_Is_Idle();
     Delay_us(50);
     I2C1_Wr(0x20 | rs | 0x00 | 0x08);
     I2C1_Is_Idle();
     I2C1_Stop();

     Delay_ms(10);

     I2C_LCD_Cmd(0x28);
     I2C_LCD_Cmd(0x06);
}

void I2C_LCD_Out(char row, char col, char *text) {
    while(*text)
         I2C_LCD_Chr(row, col++, *text++);
}

void I2C_LCD_Out_Cp(char *text) {
    while(*text)
         I2C_LCD_Chr_Cp(*text++);
}
#endif


void Raz_Buffer()
{  int i;
        buffer[0]=0;
        j=0;
        Index1=0;
        Flag_Buffer =0;
        // nettoye le debut de buffer ,car utilis� pour init BT
        for(i=0;i<32;i++)buffer[i]=0;
        i=RCREG;
        RCIE_bit = 1;
}

void UART1_Write_CText(const char *txt1)
 {
   while (*txt1)
      UART1_Write(*txt1++);
}

// --- Copie le texte depuis ROM vers RAM
void strConstRamCpy(char *dest, const char *source) {
  while(*source) *dest++ = *source++ ;
  *dest = 0 ;    // terminateur
}

void CRLF()
{
 UART1_Write(CR);
 UART1_Write(LF);
}

 void Init_Timer0(void)    // 1 seconde
 {

 OPTION_REG.PS2=1;   // prescaler 1/256
 OPTION_REG.PS1=1;
 OPTION_REG.PS0=1;
 OPTION_REG.PSA=0; // prescaler sur Timer0
 OPTION_REG.TMR0CS=0; // source FOSC/4
 INTCON.TMR0IF=0;
 INTCON.TMR0IE=0;    // disable interrupt Timer0
 TMR0= 0 ; //  255-0=255  prescaler=1/256 => 16.384 mS
 CPSCON0=0;
 }

void PrintMsg(int x)
{
   strConstRamCpy(txt,Messages[x]);
   txt=&TEXTE[0];
   UART1_Write_Text(txt);
  }


void main()
{
  // voir page 61
  // 0=4xPLL OFF, 1111=IOFS=16Mhz  0=0  00=SCS=config via Conf1 word FOSC<2:0>
  // 0=4xPLL OFF, 1110=IOFS=8Mhz  0=0  00=SCS=config via Conf1 word FOSC<2:0>
  OSCCON=0b01111000;    // choix 16Mhz  internal osc

        // RA5 as input for RX , RA4 as output for TX RA2 as input
  TRISA=0b00101111;      // RA4 en sorties
  ANSELA=0;             // no analog
  ANSELA.ANSA0=1;       // RA0= Analog input
  WPUA=0b00110000;      // weak pull up on RX & TX

  CM1CON0=0;       // disable comparators
  CM1CON1=0;
   // RA4=TX RA5=RX   (voir page 111 )
  APFCON=0;
  APFCON.P1BSEL=1;    // pour deconnecter de RA0 mais connecte sur RA4 ???!!
  APFCON.RXDTSEL=1;   // RX sur RA5
  APFCON.TXCKSEL=1;   // TX sur RA4
    // RA5 as input for RX , RA4 as output for TX RA2 as input
  TRISA=0b0100100;      // RA0 et RA1 en sorties
  PORTA.F0=0;

  FVRCON.FVREN=1;       // fixed voltage reference     (voir page 124)
  FVRCON.TSEN=0;        // temperature enable=0;
  FVRCON.TSRNG=1;       // temperature range high   car VDD>3,6V
  FVRCON.CDAFVR1=0;     // Comparator & DAC OFF
  FVRCON.CDAFVR0=0;
  FVRCON.ADFVR1=1;     // ref=4.096V
  FVRCON.ADFVR0=1;

   Raz_Buffer();
   txt=&TEXTE[0];
   UART1_Init(19200);

   // re-init AGAIN , because Uart init disturbing
   //TRISA=0b00101111;      // RA0 et RA1 en sorties

   // 2 times to get empty fifo !
   if (PIR1.RCIF==1) c1 = RCREG;     // vide Fifo
   if (PIR1.RCIF==1) c1 = RCREG;     // vide fifo
   Delay_ms(500);
   UART_Write(CLS);


   INTCON=0;
   PIR1=0;
   PIR2=0;

   TMR0IF_bit=0;
   TMR0IE_bit=1;
   INTCON.PEIE=0;  // disable IT des peripherique voir fig  8.1 p 77
   INTCON.GIE=0;
   //NbCycles_T1= 7;    // 0 � 7 => 8 fois 125mS

   k=0;
   l=0;
   j=0;

   UART1_Write(CLS);
   Delay_ms(500);
    UART1_Write('A');    UART1_Write('B'); UART1_Write('C');
   Flag_Buffer=0;
   Index1=0;
   CRLF();

  txt=&TEXTE[0];
  strConstRamCpy(txt,mesg0); txt=&TEXTE[0];UART1_Write_Text(txt);
  strConstRamCpy(txt,mesg1); txt=&TEXTE[0];UART1_Write_Text(txt);
  strConstRamCpy(txt,mesg2); txt=&TEXTE[0];UART1_Write_Text(txt);
   strConstRamCpy(txt,mesg3); txt=&TEXTE[0];UART1_Write_Text(txt);
  CRLF();
  //txt=&TEXTE[0];PrintMsg(0);
  //txt=&TEXTE[0];PrintMsg(1);
  txt=&TEXTE[0];
 // --------------- Test Zone -------------------------
 CRLF();
  Count1=0;
  CptErr=0;
  c1=0;
  RCSTA=0;
  RCSTA.CREN=1;  //enable receiver
  RCSTA.SPEN=1;  // serial port Pins Enable
  RCSTA.SREN=1;  // single byte receive
  c1 = RCREG;   // RAZ errors


  ADC_Init();
  ADCON1.ADPREF1= 1;  // Vref sur FVR 4.096V
  ADCON1.ADPREF0= 1;
  ADCON1.ADFM=0; // cadrage � gauche
  ADCON0=0;      // chanel AN0 select
  ADCON0.CHS0=0 ;   // chanel AN0 select
  ADCON0.ADON=1 ;// Turn ADC On

  UART1_Write_CText("IT UART RA4-RA5 & Timer0  \n\r");

  Count0=0;
  Flag_Timer0=0;
  TMR0=0;          //  0 � 255  sur 8 bits

  Init_Timer0();   // but not started!
  TMR0=0;          //  0 � 255  sur 8 bits !

  UART1_Write_CText("Init Timer0 \n\r");

   // on arme tout !
   INTCON.TMR0IF=0;
   INTCON.TMR0IE=1;
   UART1_Write_CText("Init interrupt..\r\n");

  I2C1_Init(100000);
  UART1_Write_CText("I2C init.\r\n");

  I2C_LCD_Init();
  I2C_LCD_Cmd(_LCD_CURSOR_OFF);
  I2C_LCD_Cmd(_LCD_CLEAR);
  I2C_LCD_Out(1,1,"I2C LCD4x20,UART,ADC");

  UART1_Write_CText("LCD I2C 4x20 ..init\r\n");
  CRLF();



  j=0;
  k=0;
  l=0;


  Sum=0;
  Average=0;
  OldValue=0;
  Flag_F=0;
  Cpt=0;

  Flag_Timer0=0;
   INTCON.PEIE=1;  // autorise IT des peripherique voir fig  8.1 p 77
   INTCON.GIE=1;   // Enable all interrupts (timer1 & UART)

  while(1)
  {
  txt=&TEXTE[0];
  //*(txt)=0;
  ByteToStr(Cpt, txt) ;
  // *(txt+3)=0;
  UART1_Write_Text(txt);  UART1_Write(TAB);

  I2C_LCD_Out(1,1,"Index FILO = ");
  I2C_LCD_Out(1,13,txt);
  //  M=ADC_Get_Sample(2);  // lecture sur RA2


  ADCON0.ADGO=1;//Start conversion
  while(ADCON0.ADGO==1); //Is conversion done?
  NewValue=ADRESH;
  // *(txt)=0;
  ByteToStr(NewValue, txt) ;
  //*(txt+3)=0;
  I2C_LCD_Out(2,1,"Now=");
  I2C_LCD_Out(2,5,txt);
  UART1_Write_Text(txt);
  UART1_Write(TAB);
  FiLo[Cpt]=NewValue;
  Cpt ++;
  if (Flag_F==1)
  {
  Sum=0;
  for (i=0;i<16;i++)  Sum=Sum +(unsigned int)FiLo[i];

  WordToStr(Sum, txt) ;
  I2C_LCD_Out(3,1,"Sum=");
  I2C_LCD_Out(3,5,txt);
  UART1_Write_Text(txt);  UART1_Write(TAB);
  Average=(unsigned char) (Sum / 16) ; // divise par 16
  I2C_LCD_Out(4,1,"Moy=");
  I2C_LCD_Out(4,5,txt);
   ByteToStr(Average, txt) ;
  UART1_Write_Text(txt);
  }
  else
  {
     UART1_Write_CText("  Wait filtering..");
     I2C_LCD_Out(1,1,"Wait Filtering      ");
  }
  if (Cpt>15)
  {
   Flag_F=1   ;
   Cpt=0;
   }
  CRLF();
    while (Flag_Timer0==0);
    Flag_Timer0=0;


  }
 }