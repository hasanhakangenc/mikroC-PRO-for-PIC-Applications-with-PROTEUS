short i, WDT_degeri;
void write_WDT(){
 TABLAT=WDT_degeri;
 asm{
  CLRWDT  //Vardiya zamanlay�c�s� resetleniyor
 }
 WDTCON.SWDTEN=0;
 TBLPTRU = 0x30;
 TBLPTRH = 0X00;
 TBLPTRL = 0X03;
 asm{
  TBLWT* /* 1'er byte artarak giden adres de�erlerine i�aretleme yap�p tablo de�erini yazd�ran assembly komutu */
 }
 EECON1 = 0b11000100;
 STATUS.C = 0; // Ta�ma olmad�
 if(INTCON.GIE){
  STATUS.C = 1;
 }
 INTCON.GIE=0;
 EECON2 = 0X55;
 EECON2 = 0XAA;
 EECON1.WR = 1;
 
 if(STATUS.C){
  INTCON.GIE=1;
 }
 EECON1.WREN=0;
 WDTCON.SWDTEN=1;
}
void blink_LED(){
  for(i=0;i<10;i++){
   asm{
    sleep
   }
   LATB = ~LATB; //Toggle RB0
  }
}
void main() {
 ADCON0=0;
 ADCON1=0;
 CMCON=0X07;
 LATB = 0;
 TRISB = 0;
 WDTCON.SWDTEN=1;
 //OSCCON=0X72;
 while(1){
  WDT_degeri = 12; // 0b00001100, WDT son�l�ekleyicisi 1:64, yakla��k 1/4 saniye
  write_WDT();
  blink_LED();
  WDT_degeri = 16; // 0b00010000, WDT son�l�ekleyicisi 1:256, yakla��k 1 saniye
  write_WDT();
  blink_LED();
 }
}