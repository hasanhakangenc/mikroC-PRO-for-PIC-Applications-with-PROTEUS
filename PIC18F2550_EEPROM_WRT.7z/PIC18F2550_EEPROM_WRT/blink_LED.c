short i;
void main() {
 ADCON0=0;
 ADCON1=0;
 CMCON=0X07;
 LATB = 0;
 TRISB = 0;
 //OSCCON=0X72;
 while(1){
   LATB = ~LATB;
   Delay_ms(250);
 }
}