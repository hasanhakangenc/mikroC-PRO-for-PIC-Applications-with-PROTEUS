#define KONTROL PORTA.RA0 // A portunun 0. pinine (RA0) KONTROL ismi veriliyor
void main() {
    OPTION_REG = 0x0F; // �n �l�ekleyici WDT'ye ayarlan�yor (1:128)
    TRISA = 0;         // T�m A portlar� ��k�� yap�l�yor
    TRISB = 0;         // T�m B portlar� ��k�� yap�l�yor
    PORTA = 0;         // Portlar temizleniyor
    PORTB = 0;
    KONTROL = 1;      // RA0 lojik-1 yap�l�yor
    Delay_ms(250);    // 250ms sonra lojik-0 yap�l�yor
    KONTROL = 0;
    PCON.OSCF=1;/*
    asm{ // Assembly kod blo�u a��l�yor
     SLEEP; // Mikrodenetleyici uyku moduna al�n�yor
     NOP;
    } */
}