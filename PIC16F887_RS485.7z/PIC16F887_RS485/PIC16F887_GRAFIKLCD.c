#define GLCD_Data PORTD
#define GLCD_Data_Direction  TRISD
#define GLCD_E PORTB.RB5
#define GLCD_DI PORTB.RB4
#define GLCD_RW PORTB.RB3
#define GLCD_Reset PORTB.RB2
#define GLCD_CS2 PORTB.RB1
#define GLCD_CS1 PORTB.RB0

void GLCD_Write (unsigned char r, unsigned char datax);
unsigned char GLCD_Read_Data (unsigned char r);
void GLCD_Init();
void Set_Column(unsigned char col);
void Set_Row(unsigned char row);
void Set_XY(unsigned char row, unsigned col);
void Display_Set_Start_Line(unsigned char line);
unsigned char GLCD_Busy();
void Check_GLCD_Busy();
char GLCD_Status();
void GLCD_Write_Char(unsigned char datax);
void GLCD_Write_Str(unsigned char *str, unsigned char count);
char GLCD_Read();
void GLCD_Clear_Display();
void GLCD_Clear_Line(unsigned char datax);
void GLCD_Dot(unsigned char x, unsigned char y);


//char mesaj[] ={0x00, 0x00, 0x7F, 0x09, 0x09,0x09,0x06,0x00};

// ------------------------------------------------------
// GLCD Picture name: mikro.bmp
// GLCD Model: KS0108 128x64
// ------------------------------------------------------

//char mesaj[] = {192, 224, 112, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176,  96, 224, 128,0,0,0};

// ------------------------------------------------------
// GLCD Picture name: bayrak.bmp
// GLCD Model: KS0108 128x64
// ------------------------------------------------------

char mesaj1[] = {255, 127,  31,  15,   7,   3,   1, 193, 224, 240, 248, 248, 248, 252, 252, 252, 253, 249, 251, 247, 255, 255, 255, 255, 255,  63, 255, 255, 255, 255, 255, 255};
char mesaj2[] = {255,   0,   0,   0,   0,   0, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 247, 247, 247, 227,   0, 128, 193, 193, 201, 156, 255};
char mesaj3[] = {255, 255, 252, 248, 240, 224, 192, 193, 131, 135, 143, 143, 143, 159, 159, 159, 223, 207, 239, 255, 247, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};


// ------------------------------------------------------
// GLCD Picture name: bayrak.bmp
// GLCD Model: KS0108 128x64
// ------------------------------------------------------
/*
char mesaj1[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj2[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127,  63,  31,  15,   7, 135, 135, 195, 227, 227, 227, 247, 247, 231, 239, 239, 223, 191, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj3[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,   1,   0,   0,   0,   0, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 207, 207,   0,   3, 135, 135,  51, 123, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj4[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 248, 240, 224, 192, 193, 131, 135, 143,  31,  31,  31, 159, 159, 159, 223, 223, 239, 247, 255, 255, 255, 252, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj5[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj6[] = {3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3};
 */
 
 // ------------------------------------------------------
// GLCD Picture name: bayrak.bmp
// GLCD Model: KS0108 128x64
// ------------------------------------------------------
/*
char mesaj1[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj2[] = {255, 255, 255, 255, 255, 255, 255, 255, 255,  15,   7,   3,   1, 224, 240, 248, 252, 252, 252, 252, 252, 249, 251, 255, 127, 127,  15,  31,  63,  31, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj3[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 240, 224, 192, 128,   7,  15,  31,  63,  63,  63,  63,  63, 159, 223, 255, 254, 254, 240, 248, 252, 248, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char mesaj4[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
 */


// ------------------------------------------------------
// GLCD Picture name: 11899850_10153560195804410_1277928106073228765_n.bmp
// GLCD Model: KS0108 128x64
// ------------------------------------------------------

char mesaj4[] = {0,   0,   0,   0,   0,   0,   0, 128,  32,  16,   8,   8,   4,   6,   6,   6,   2,   2,   4,   4,   4,  12,   8,  16,  32, 128,   0,   0,   0,   0,   0,   0};
char mesaj5[] = {0,   0,   0,   0,   0,   0,   0, 125,   0,  16,  88,  40, 104,  24,   0,   0,   0,   0,   0,  56, 104,  40, 104,  16,  64,  63,   0,   0,   0,   0,   0,   0};
char mesaj6[] = {0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 192,  64,  64,  84,  72,   0,   0,   0,   0,   0, 128,   0,   0,   0,   0,   0,   0,   0};
char mesaj7[] = {0,   0,   0,   0,   0,   0,   0,   0,   0, 244,   8,  24,  56,  48,  48,  48,  49,  49,  48, 176,  58,  60,  12, 242,   0,   0,   0,   0,   0,   0,   0,   0};




void main(){
  OSCCON = 0X72;
  ANSEL  = 0;                        // Configure AN pins as digital I/O
  ANSELH = 0;
  C1ON_bit = 0;                      // Disable comparators
  C2ON_bit = 0;

  PORTA = 0;
  PORTB = 0;
  PORTC = 0;
  PORTD = 0;
  PORTE = 0;
  TRISA = 0;
  TRISB = 0;
  TRISC = 0XC0;
  TRISD = 0;
  TRISE = 0;

  GLCD_Init();        // Turn ON
  Check_GLCD_Busy();  // Wait if busy
  GLCD_Clear_Display();
 /* Set_XY(0,0);
  GLCD_Write_Str(mesaj1, 32);
  Set_XY(1,0);
  GLCD_Write_Str(mesaj2, 32);
  Set_XY(2,0);
  GLCD_Write_Str(mesaj3, 33);*/
  Set_XY(0,64);
  GLCD_Write_Str(mesaj4, 32);
  Set_XY(1,64);
  GLCD_Write_Str(mesaj5, 32);
  Set_XY(2,64);
  GLCD_Write_Str(mesaj6, 32);
  Set_XY(3,64);
  GLCD_Write_Str(mesaj7, 32);
  while(1);
}

void GLCD_Write (unsigned char r, unsigned char datax)
{
    GLCD_Data_Direction = 0x00; // Set as Output
    GLCD_E = 0;         // E pin Low
    GLCD_DI = r;        // RS(DI) set low for command or high for data
    GLCD_RW = 0;        // RW set low for write mode
    delay_us(1);        // Twl > 450ns & Tasu > 140ns
    GLCD_Data = datax;   // Set dat in the data port
    GLCD_E = 1;         // E pin High
    delay_us(1);        // Twh > 450ns and Tdsu > 520ns
    GLCD_E = 0;         // E pin Low
    delay_us(1);        // Tdhw > 10ns
    GLCD_E = 1;         // E pin High
}
unsigned char GLCD_Read_Data (unsigned char r)
{
    unsigned char datax;
    GLCD_Data_Direction = 0xFF; // Set as Input
    GLCD_E = 0;         // E pin Low
    GLCD_DI = r;        // RS(DI) set low for command or high for data
    GLCD_RW = 1;        // RW set low for read mode
    delay_us(1);        // Twl > 450ns & Tasu > 140ns
    GLCD_E = 1;         // E pin High
    delay_us(1);        // Data appears after a delay of Td (>320ns)
                        // read data after considering E High level width time Twh > 450ns
                        // 500ns is enough
    datax = GLCD_Data;   // Set data in the data port
    GLCD_E = 0;         // E pin Low
    delay_us(1);        // Tdhr > 20ns, before disappearing data in the line
}

void GLCD_Init()
{
    GLCD_Reset = 1;     // Reset the display
    GLCD_CS1 = 1;       // Select left controller
    GLCD_CS2 = 1;       // Select right controller
    GLCD_Write(0, 0x3F); // Write command for turning ON
}

void Set_Column(unsigned char col)
{
    unsigned char datax;
    if (col<64)
    {
        GLCD_CS1 = 1;   // Turn ON left controller
        GLCD_CS2 = 0;
        // Command format  -> 01XXXXXX
        // XXXXXX -> Column address in 0 - 63 range
        datax = (col | 0x40) & 0x7F;
        GLCD_Write(0,datax);
    }
    else
    {
        GLCD_CS1 = 0;
        GLCD_CS2 = 1;   // Turn ON right controller
        // Command format  -> 01XXXXXX
        // XXXXXX -> Column address in 0 - 63 range
        datax = ((col-64) | 0x40) & 0x7F ;
        GLCD_Write(0,datax);
    }
}

void Set_Row(unsigned char row)
{
    unsigned char datax;
    // Command format :10111XXX, XXX -> row
    datax= (row | 0xB8) & 0xBF;
    GLCD_Write(0, datax);
}

void Set_XY(unsigned char row, unsigned col)
{
    Set_Row(row);
    Set_Column(col);
}

void Display_Set_Start_Line(unsigned char line)
{
    unsigned char datax;
    GLCD_CS1 = 1;       // Select left controller
    GLCD_CS2 = 1;       // Select right controller
    datax = 0xC0 | line;   // Set start line command
    GLCD_Write(0, datax);
}

unsigned char GLCD_Busy()
{
    unsigned char datax;
    datax = GLCD_Read_Data(0);
    return (datax && 0x80);   // Return flag status,
                                //  1 if Busy, else 0
}

// function to wait until busy signal clear off
// This can be called after an instruction to wait till it clears busy flag
void Check_GLCD_Busy()
{
    while(GLCD_Busy());
}

char GLCD_Status()
{
    unsigned char datax;
    datax = GLCD_Read_Data(0);     // Read in command mode
    return (datax && 0x30);   // Return flag status,
                                  //  1 if display OFF, 2 if reset and 0 else
}

void GLCD_Write_Char(unsigned char datax)
{
    GLCD_Write(1, datax);    // Write in data mode
}

//Function to send multiple bytes to the RAM
// Make sure that data sent doesn't exceeds the page and Column limits
void GLCD_Write_Str(unsigned char *str, unsigned char count)
{
    unsigned char c=0;
    do{
        GLCD_Write(1, *str);    // Write in data mode
        c++;
        str++;
        } while(c < count);
}

char GLCD_Read()
{
    unsigned char datax;
    datax = GLCD_Read_Data(1);    // Read in data mode
    return datax;
}

void GLCD_Clear_Display()
{
    unsigned char i=0;
    GLCD_Clear_Line(i);    // Clear each line
}

void GLCD_Clear_Line(unsigned char datax){
 unsigned char i, j;
 for(i=0;i<8;i++){
  for(j=0;j<128;j++){
   Set_XY(i, j);
   GLCD_Write_Char(datax);
  }
 }
}

void GLCD_Dot(unsigned char x, unsigned char y)
{
    Set_XY(x, y);    // Set position
    GLCD_Write(1, 0x70);    // Write in data mode
}