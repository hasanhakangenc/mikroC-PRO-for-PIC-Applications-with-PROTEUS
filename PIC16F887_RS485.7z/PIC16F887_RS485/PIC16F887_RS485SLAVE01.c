char dat[6];  // mesaj alma/g�nderme verisi
char i,j;

sbit  rs485_rxtx_pin at RC2_bit;             // iletim/g�nderim pini tanimlanir
sbit  rs485_rxtx_pin_direction at TRISC2_bit;// iletim/g�nderim pin y�n�

// Kesme rutini
void interrupt() {
 if(RCIF_bit){
  RS485Slave_Receive(dat);
 }
}

void main() {
  OSCCON = 0X72;     // Dengeli 8MHz dahili osilat�r
  ANSEL  = 0;        // AN pinleri dijital I/O olarak ayarlanir
  ANSELH = 0;
  C1ON_bit = 0;      // karsilastiricilar kapali
  C2ON_bit = 0;

  PORTB = 0;
  PORTD = 0;
  TRISB = 0;
  TRISD = 0;


  UART1_Init(9600);          // UART1 mod�l� baslatilir
  Delay_ms(100);
  RS485Slave_Init(160);     // MCU 160 nolu adresle k�le olarak baslatilir

  dat[4] = 0;               // mesaj alindi bayragi temizlenir
  dat[5] = 0;               // hata bayragi temizlenir

  RCIE_bit = 1;            // UART1 alma kesmesi etkin
  TXIE_bit = 0;            // UART1 iletim kesmesi pasif
  PEIE_bit = 1;            // cevresel donanim kesmesi etkin
  GIE_bit = 1;             // t�m kesmeler etkin

  while (1) {
    if (dat[5])  {        // iletisimde hata algilanirsa, PORTD'yi arttirarak
     PORTD++;             // hatayi bildir ve hata baytini temizle
     dat[5] = 0;
    }
    if (dat[4]) {               // gecerli mesaj alimi tamamlandiginda
      dat[4] = 0;               // data[4] temizlenir
      j = dat[3];
      for (i = 1; i <= j;i++){
        PORTB = dat[i-1];
        Delay_ms(250);
      }
      dat[0] = dat[0]+1;     // dat[0]'i arttir, dat[1] ve dat[2]'yi azalt
      dat[1] = dat[1]-1;
      dat[2] = dat[2]-1;
      Delay_ms(1);
      RS485Slave_Send(dat,3); // ve master aygita geri g�nder
    }
  }
}