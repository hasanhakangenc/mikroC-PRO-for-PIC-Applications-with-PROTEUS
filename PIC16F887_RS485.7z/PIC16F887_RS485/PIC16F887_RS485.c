char dat[7]; // mesaj alma/g�nderme verisi
char i,j;

sbit  rs485_rxtx_pin  at RC2_bit;             // iletim/g�nderim pini tanimlanir
sbit  rs485_rxtx_pin_direction at TRISC2_bit; // iletim/g�nderim pin y�n�

// Kesme rutini
void interrupt() {
  if(RCIF_bit){
   RS485Master_Receive(dat);
  }
}

void main(){
  unsigned int cnt = 0;
  OSCCON = 0X72;       // Dengeli 8MHz dahili osilat�r
  ANSEL  = 0;          // AN pinleri dijital I/O olarak ayarlanir
  ANSELH = 0;
  C1ON_bit = 0;        // karsilastiricilar kapali
  C2ON_bit = 0;

  PORTB  = 0;
  PORTD  = 0;
  TRISB  = 0;
  TRISD  = 0;

  UART1_Init(9600);       // UART1 mod�l� baslatilir
  Delay_ms(100);

  RS485Master_Init();    // MCU Master olarak baslatilir
  dat[0] = 0;
  dat[1] = 127;
  dat[2] = 255;
  dat[4] = 0;            // mesaj alindi bayragi temizlenir
  dat[5] = 0;            // hata bayragi temizlenir
  dat[6] = 0;

  RS485Master_Send(dat,3,160);


  RCIE_bit = 1;         // UART1 alma kesmesi etkin
  TXIE_bit = 0;         // UART1 iletim kesmesi kapali
  PEIE_bit = 1;         // cevresel kesmeler etkin
  GIE_bit = 1;          // tum kesmeler etkin

  while (1){
  // gecerli mesaj alimi tamamlandiginda
  // data[4] 255 degerine kurulur
   if(dat[6] == 160){ //Adresi 160 olan k�le aygitin verisi islenir
    if (dat[5])  {  // hata algilanirsa, PORTD ve cnt degiskeni artirilir
      PORTD++;
      cnt++;
    }
    if (dat[4]) {                  // mesaj basarili olarak alindiysa
      dat[4] = 0;                  // mesaj alindi bayragini temizle
      j = dat[3];  // dat[3] verisi bu uygulamada 3 degerine kuulmustur
      for (i = 1; i <= j; i++) { // 3 baytlik veri gonderildiginden
        PORTB = dat[i-1]; // PORTB uzerinde sirasiyla dat[0], dat[1] ve dat[2]
        Delay_ms(250);    // 250msn'lik araliklarla g�sterilir
      }                   // alinan dat[0]'i arttir, data[1] ve dat[2]'yi azalt
      dat[0] = dat[0]+1;  // k�le aygita geri g�nder
      dat[1] = dat[1]-1;
      dat[2] = dat[2]-1;
      Delay_ms(1);
      RS485Master_Send(dat,3,160);//160 adresli k�leye islenmis veriyi g�nder
    }
   if (cnt > 10) { // eger iletisimde 10 defadan fazla hata
    RS485Master_Send(dat,1,50); // olursa  mesaji yayin adresinden g�nder
    cnt=0;
   }
  }
 }
}