char dat[6];
char i,j;

sbit  rs485_rxtx_pin at RC2_bit;
sbit  rs485_rxtx_pin_direction at TRISC2_bit;

void interrupt() {
 if(RCIF_bit){
  RS485Slave_Receive(dat);
 }
}

void main() {
  OSCCON = 0X72;
  ANSEL  = 0;
  ANSELH = 0;
  C1ON_bit = 0;
  C2ON_bit = 0;

  PORTA = 0;
  PORTB = 0;
  PORTD = 0;
  PORTE = 0;
  TRISA = 0;
  TRISB = 0;
  TRISD = 0;
  TRISE = 0;

  UART1_Init(9600);
  Delay_ms(100);
  RS485Slave_Init(100);

  dat[4] = 0;
  dat[5] = 0;

  RCIE_bit = 1;
  TXIE_bit = 0;
  PEIE_bit = 1;
  GIE_bit = 1;

  while (1) {
    if (dat[5]){  // hata varsa
      PORTE++;
      dat[5] = 0;
    }
    if (dat[4]){ // mesaj alindiysa
      dat[4] = 0;
      PORTA = dat[0];
      Delay_ms(1);
    }
  }
}