#define duty_artir PORTB.RB1
#define duty_azalt PORTB.RB2
unsigned int i, mod, buton_sure, duty_cycle=200;
void ayar(){
  TRISA = 0X00;
  PORTA = 0;
  TRISB = 0X07;//harici kesme ve RB1-RB2 giri�i aktif
  PORTB = 0;
  TRISC = 0X00;
  PORTC = 0;
  TRISD = 0X00;
  PORTD = 0;
  TRISE = 0X00;
  PORTE = 0;
  OPTION_REG = 0; // 1:2 �n �l�ekleme de�eri
  /* Port giri�lerinin davran��� belirleniyor ve analog kanal ayarlar� yap�l�yor */
  ANSEL = 0; //t�m kanallar dijital yap�ld�
  ANSELH = 0; //t�m kanallar dijital yap�ld�
  ADCON1 = 0;
  CCP1CON = 0B00001100;; //ECCP1 standart PWM olarak a��k
  CCP2CON = 0; //PWM2 kapal�
  TMR2 = 0;
  PR2=249;
  CCPR1L = duty_cycle;
  INTCON = 0;
  Delay_ms(50);
  PIE1 = 0;
  PIR1 = 0;
  T2CON = 0B00000001; //Prescaler 1:4 - 2kHz sinyal
  Delay_ms(10);
  T2CON.TMR2ON = 1;
  OSCCON=0X70; //Dahili 8MHz frekans
  PSTRCON=0B00000001; //Ba�lang��ta P1A aktif PWM pini
  OPTION_REG=1; //dahili pull-up'lar aktif ve prescaler 1:4
  WPUB=7;//Harici kesme giri�i ve RB1 i�in dahili weak pull-up aktif
  IOCB=6;//Durum de�i�imi aktif - 7 de�eri y�klenirse harici kesme giri�i
  INTCON.GIE=1;                  // port durum kesmesi gibi davran�r!!!
  INTCON.TMR0IE=1;//Timer0 kesmesi aktif
  INTCON.INTE=1; //RB0 harici kesme aktif
  INTCON.RBIE=1; //Port durum de�i�im kesmesi aktif
  TMR0=206;
}
void mod0(){
 PSTRCON=0B00010001;
}
void mod1(){
 PSTRCON=0B00010010;
}
void mod2(){
 PSTRCON=0B00010100;
}
void mod3(){
 PSTRCON=0B00011000;
}
void mod4_disko(){
 PSTRCON = PSTRCON << 1;
 if(PSTRCON>8)PSTRCON=0B00000001;
 Delay_ms(100);
}
void mod5_hepsi(){
   PSTRCON=0B00011111;
}
void main(){
  ayar();
  while(1) {
   if(duty_artir && duty_azalt) buton_sure=0;
   if(!duty_artir){
    if(buton_sure>100 && duty_cycle<200){
     duty_cycle++;
     CCPR1L=duty_cycle;
     buton_sure=0;
    }
   }
   if(!duty_azalt){
    if(buton_sure>100 && duty_cycle>10){
     duty_cycle--;
     CCPR1L=duty_cycle;
     buton_sure=0;
    }
   }
   switch (mod){
    case 0:mod0();break;
    case 1:mod1();break;
    case 2:mod2();break;
    case 3:mod3();break;
    case 4:mod4_disko();break;
    case 5:mod5_hepsi();break;
   }
  }
}
void interrupt(){
 if(INTCON.INTF){
   mod++;
   if(mod>5) mod=0;
   INTCON.INTF=0;
 }
 if(INTCON.RBIF){
  if(!duty_artir){
   if(duty_cycle<200) duty_cycle++;
  }
  if(!duty_azalt){
   if(duty_cycle>10) duty_cycle--;
  }
  CCPR1L=duty_cycle;
  INTCON.RBIF=0;
 }
 if(INTCON.TMR0IF){  // (256-206)*4/2.000.000 = 0.1msn elde ediliyor
  buton_sure++;
  TMR0=206;
  INTCON.TMR0IF=0;
 }
}