unsigned short ikaz_biti=0;
unsigned short saniye, zaman=0;
unsigned short i, yukselen=0;
unsigned short ilk=0;
sbit SES at RB3_bit;
sbit KIRMIZI at RB2_bit;
void setup(){
  ikaz_biti=0;
}
void main() {
TRISB = 0x01;
PORTB = 0;
TRISA = 0x00;
PORTA = 0;
setup();
INTCON.GIE=1;   //Evrensel kesme aktif
INTCON.INTE=1;  //Harici kesme aktif
INTCON.T0IE=1; //Timer0 kesmesi aktif
TMR0=220;
CMCON=0X07;  //Analog kar��la�t�r�c�lar kapat�ld�
OPTION_REG = 0b00000111;   // Assign 1:256 prescaler to Timer0
PCON.OSCF=0;
PWM1_Init(2000);
PWM1_Start();
PWM1_Set_Duty(0);
KIRMIZI=0;
SES=0;
ikaz_biti=0;
 while(1){
  if(!ikaz_biti){
   SES=0;
   KIRMIZI=0;
   PWM1_Set_Duty(0);
    asm{
     sleep
    }
  }
  if(ikaz_biti){
    if(saniye<=50)
     PWM1_Set_Duty(200);
     KIRMIZI=~KIRMIZI;
    }
    if(saniye>50){
    PWM1_Set_Duty(0);
     saniye=0;
     ikaz_biti=0;
    }
   }
 }

void interrupt(){
 if(INTCON.INTF){
   zaman=0;
   ikaz_biti=1;
   INTCON.INTF=0;
 }
 if(INTCON.T0IF){
   saniye++;
   INTCON.T0IF=0;
   TMR0=220;
 }
}