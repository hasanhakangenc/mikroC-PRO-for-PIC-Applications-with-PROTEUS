const zaman = 1000;
const PWM_MAX = 200;
sbit MAVI_BIR at GP1_bit;
sbit MAVI_IKI at GP2_bit;
sbit KIRMIZI_BIR at GP4_bit;
sbit KIRMIZI_IKI at GP5_bit;
char sayac, i, LDR, darbe_aktif;
unsigned int PWM;
unsigned int sure;
void setup(){ /*
  asm{
   BSF STATUS, RP0 //Bank 1
   CALL 0x3FF //Get the cal value
   MOVWF OSCCAL //Calibrate
   BCF STATUS, RP0 //Bank 0
 }   */
  TRISIO = 0B00000001; //hepsi cikis - AN0 giris
  GPIO = 0X00;   // T�m portlar sifirlaniyor
  INTCON.GIE=1;
  INTCON.TMR0IE=1;
  ANSEL = 0b00010001; //Osilat�r frekansinin 16'da biri hizda �rnekleme
  Delay_ms(10); // LED baglanacak AN0 kanali analog giris yapiliyor
  CMCON=0X07;  //Analog karilastiricilar kapali
  OPTION_REG = 0B00000000;   // Timer0 kesmesi i�in 1:256 �n�l�ekleyici de�eri ataniyor
  TMR0 = 206;
  sayac = EEPROM_Read(0x02);
  if(sayac>=4){
   sayac=0;
  }
  sayac++;
  EEPROM_Write(0x02,sayac);
}
void bekle(){
 while(sure<zaman);
}
void bitti(){
 GPIO = 0X00;
 ADCON0 = 0;
 INTCON.GIE = 0;
 asm{
  sleep  //bosta bekleme aninda uyku modunda tutuluyor
 }
}
void yuruyen_isik(){
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00100000;
  GPIO = 0B00000000;
 }
 bekle();
 sure=0;
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00010000;
  GPIO = 0B00000000;
 }
  bekle();
  sure=0;
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00000010;
  GPIO = 0B00000000;
 }
  bekle();
  sure=0;
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00000100;
  GPIO = 0B00000000;
 }
  bekle();
  sure=0;
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00000010;
  GPIO = 0B00000000;
 }
  bekle();
  sure=0;
 while(sure<zaman){
  while(darbe_aktif) GPIO = 0B00010000;
  GPIO = 0B00000000;
 }
  bekle();
  sure=0;
}
void polis_efekti(){
  for(i=0;i<3;i++){
   while(sure<(zaman-500)){
    while(darbe_aktif){
     MAVI_BIR = 1;
     MAVI_IKI = 1;
    }
    MAVI_BIR = 0;
    MAVI_IKI = 0;
   }
   sure=0;
   MAVI_BIR = 0;
   MAVI_IKI = 0;
   bekle();
   sure=0;
  }
  GPIO=0;
  for(i=0;i<3;i++){
   while(sure<(zaman-500)){
    while(darbe_aktif){
     KIRMIZI_BIR = 1;
     KIRMIZI_IKI = 1;
    }
    KIRMIZI_BIR = 0;
    KIRMIZI_IKI = 0;
   }
   sure=0;
   KIRMIZI_BIR = 0;
   KIRMIZI_IKI = 0;
   bekle();
   sure=0;
  }
  GPIO=0;
}
void sos(){
 for(i=0;i<3;i++){
   while(sure<(zaman-500)){
    while(darbe_aktif){
     MAVI_BIR = 1;
     MAVI_IKI = 1;
     KIRMIZI_BIR = 1;
     KIRMIZI_IKI = 1;
    }
    MAVI_BIR = 0;
    MAVI_IKI = 0;
    KIRMIZI_BIR = 0;
    KIRMIZI_IKI = 0;
   }
   sure=0;
   MAVI_BIR = 0;
   MAVI_IKI = 0;
   KIRMIZI_BIR = 0;
   KIRMIZI_IKI = 0;
   bekle();
   sure=0;
  }
  GPIO=0;
  for(i=0;i<3;i++){
   while(sure<(zaman+1000)){
    while(darbe_aktif){
     MAVI_BIR = 1;
     MAVI_IKI = 1;
     KIRMIZI_BIR = 1;
     KIRMIZI_IKI = 1;
    }
    MAVI_BIR = 0;
    MAVI_IKI = 0;
    KIRMIZI_BIR = 0;
    KIRMIZI_IKI = 0;
   }
   sure=0;
   MAVI_BIR = 0;
   MAVI_IKI = 0;
   KIRMIZI_BIR = 0;
   KIRMIZI_IKI = 0;
   bekle();
   sure=0;
  }
  GPIO=0;
}
void main(){
 setup();
 while(1){
  if(sayac<4){
   ADCON0=0B00000001;  // ADC portunun AN0 kanali se�iliyor. A/D islemi �alistiriliyor
   Delay_us(50);
   GO_DONE_bit=1;
   while(GO_DONE_bit) continue;
   LDR = ADRESH; // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
   if(LDR>PWM_MAX) LDR=PWM_MAX;
  }
   switch(sayac){
    case 1:yuruyen_isik();break;
    case 2:polis_efekti();break;
    case 3:sos();break;
    case 4:bitti();break;
   }
 }
}
void interrupt(){
 if(INTCON.TMR0IF){  // (256-251)*2/1.000.000 = 0.01msn elde ediliyor
  sure++;
  PWM++;
  if(PWM<(225-LDR)){
   darbe_aktif=0;
  }
  if(PWM>(225-LDR)){
   darbe_aktif=1;
  }
  if(PWM>=225) PWM=0;
  INTCON.TMR0IF=0;
  TMR0=206;
 }
}