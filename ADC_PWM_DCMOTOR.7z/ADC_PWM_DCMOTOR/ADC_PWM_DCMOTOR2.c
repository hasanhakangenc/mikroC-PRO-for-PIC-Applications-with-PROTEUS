#define MAKS_PWM 255
#define MIN_PWM 0
#define LED PORTE.RE0
unsigned short duty_cycle;
unsigned char maks_darbe=0;
unsigned char darbe_zirvesi=0;
unsigned char zirve_degeri = 0;
unsigned int i;
unsigned short ldr_sol;
unsigned short ldr_sag;
int ldr_fark;
void ayar(){
  TRISA = 0X03;
  PORTA = 0;
  TRISB = 0X00;
  PORTB = 0;
  TRISC = 0X00;
  PORTC = 0;
  TRISD = 0X00;
  PORTD = 0;
  TRISE = 0X00;
  PORTE = 0;
  OPTION_REG = 0; // 1:2 �n �l�ekleme de�eri
  /* Port giri�lerinin davran��� belirleniyor ve analog kanal ayarlar� yap�l�yor */
  ANSEL = 0b00000011; //AN1 ve AN0 kanal� analog, di�erleri dijital yap�ld�.
  ANSELH = 0;
  ADCON1 = 0;
  CCP1CON = 0; //PWM kapal�
  TMR2 = 0;
  PR2=249;
  CCP1CON = 0B01001100;    //Full-bridge ileri mod
  CCPR1L = MIN_PWM;
  INTCON = 0;
  Delay_ms(50);
  PIE1 = 0;
  PIR1 = 0;
  T2CON = 0B00000011;
  OSCCON = 0X70; //Konfig�rasyon ayarl� ve dahili 8MHz
  Delay_ms(10);
  T2CON.TMR2ON = 1;
}
void kontrol(){
 for(i=0;i<10;i++){
  LED = ~LED;
  Delay_ms(50);
 }
 LED=0;
}

void main(){
  ayar();
  kontrol();
  while(1) {
    /* ADC burada okunuyor */
    ADCON0=0B11000001;  // ADC portunun AN0 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50); /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;// ldr_sol d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sol=ADRESH;     // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    ADCON0=0B11000101;  // ADC portunun AN1 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50);  /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;  // ldr_sag d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sag=ADRESH;    // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    /* Fark hesaplan�yor */
    ldr_fark=ldr_sol - ldr_sag;
    if (ldr_fark > 0) {
   /*   while(!PIR1.TMR2IF)
      PIR1.TMR2IF=0;   */
      CCP1CON = 0B11001100; //Geri y�n beslemeli tam-k�pr� ��k��, P1B PWM ��k���
      duty_cycle = ldr_fark;
      CCPR1L = duty_cycle;
      delay_ms(5);
    }
    else if(ldr_fark < 0){
 /*     while(!PIR1.TMR2IF)
      PIR1.TMR2IF=0;  */
      CCP1CON = 0B01001100;//�leri y�n beslemeli tam-k�pr� ��k��, P1D PWM ��k���
      duty_cycle = (-1)*ldr_fark;
      CCPR1L = duty_cycle;
      delay_ms(5);
    }
    else{
      CCP1CON = 0;
    }
  }
}