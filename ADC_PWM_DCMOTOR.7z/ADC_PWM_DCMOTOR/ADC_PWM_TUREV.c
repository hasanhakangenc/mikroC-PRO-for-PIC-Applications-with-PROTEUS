#define MAKS_PWM 255
#define MIN_PWM 0
#define LED PORTE.RE0
unsigned short duty_cycle;
signed short carpan;
unsigned char maks_darbe=0;
unsigned char darbe_zirvesi=0;
unsigned char zirve_degeri = 0;
unsigned int i;
unsigned short ldr_sol;
unsigned short ldr_sag;
unsigned short ldr_fark, fark, ilk_fark, son_fark;
void ayar(){
  TRISA = 0X03;
  PORTA = 0;
  TRISB = 0X00;
  PORTB = 0;
  TRISC = 0X00;
  PORTC = 0;
  TRISD = 0X00;
  PORTD = 0;
  TRISE = 0X00;
  PORTE = 0;
  /* Port giri�lerinin davran��� belirleniyor ve analog kanal ayarlar� yap�l�yor */
  ANSEL = 0b00000011; //AN1 ve AN0 kanal� analog, di�erleri dijital yap�ld�.
  ANSELH = 0;
  ADCON1 = 0;
  CCP1CON = 0; //PWM kapal�
  T1CON = 0B00110000;
  T2CON = 0B00000011;
  TMR1L = 24;
  TMR1H = 2;// 00000010 00011000 = 536
  TMR2 = 0;
  PR2=249;
  CCP1CON = 0B01001100;    //Full-bridge ileri mod
  CCPR1L = MIN_PWM;
  Delay_ms(50);
  INTCON.GIE=1;
  INTCON.PEIE=1; //�evresel kesme a��l�yor
  PIE1.TMR1IE=1; //Timer1 kesmesi a��l�yor
  PIR1.TMR1IF=0;
  OSCCON = 0X70; //Konfig�rasyon ayarl� ve dahili 8MHz
  Delay_ms(10);
  T1CON.TMR1ON = 1;
  T2CON.TMR2ON = 1;
}
void kontrol(){
 for(i=0;i<10;i++){
  LED = ~LED;
  Delay_ms(50);
 }
 LED=0;
}

void main(){
  ayar();
  kontrol();
  while(1) {
    /* ADC burada okunuyor */
    ADCON0=0B11000001;  // ADC portunun AN0 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50); /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;// ldr_sol d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sol=ADRESH;     // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    ADCON0=0B11000101;  // ADC portunun AN1 kanal� se�iliyor. A/D i�lemi �al��t�r�l�yor
    Delay_us(50);  /* ADC mod�l�n�n d�n��t�rmeye haz�r hale gelmesi i�in kas�tl� bekleme yap�l�yor */
    GO_DONE_bit=1;
    while(GO_DONE_bit) continue;  // ldr_sag d�n��t�rme i�leminin bitmesi bekleniyor
    ldr_sag=ADRESH;    // 8 bitlik MSB okunuyor, ADRESL'deki 2 bitlik LSB �nemsenmiyor
    
    /* Fark hesaplan�yor */
    if(ldr_fark > 0){
    son_fark = ldr_fark;
    fark = (son_fark - ilk_fark);
    ilk_fark = fark;
    if(fark > 0){
     CCP1CON = 0B11001100; //Geri y�n beslemeli tam-k�pr� ��k��, P1B PWM ��k���
     carpan = 1;
    }
    else if(fark < 0){
     CCP1CON = 0B10001100;
     carpan = -1;
    }
    else{
      CCP1CON = 0;
    }
    duty_cycle = carpan * fark;
    CCPR1L = duty_cycle;
    delay_ms(5);
   }
   if(ldr_fark < 0){
    son_fark = (-1)*ldr_fark;
    fark = (son_fark - ilk_fark);
    ilk_fark = fark;
    if(fark > 0){
     CCP1CON = 0B10001100; //�leri y�n beslemeli tam-k�pr� ��k��, P1B PWM ��k���
     carpan = 1;
    }
    else if(fark < 0){
     CCP1CON = 0B11001100;
     carpan = -1;
    }
    else{
      CCP1CON = 0;
    }
    duty_cycle = carpan * fark;
    CCPR1L = duty_cycle;
    delay_ms(5);
   }
   else{
    CCP1CON = 0;
   }
  }
}
void interrupt(){
 if(PIR1.TMR1IF){
  ldr_fark=ldr_sol - ldr_sag;
  TMR1L = 24;
  TMR1H = 2;// 00000010 00011000 = 536
  PIR1.TMR1IF=0;
 }
}