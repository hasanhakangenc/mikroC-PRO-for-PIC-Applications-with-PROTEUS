sbit KIRMIZI at GP0_bit;
sbit MAVI at GP1_bit;

sbit MANRXPIN at GP4_bit;
sbit MANRXPIN_Direction at TRISIO4_bit;

char hata, gecici, HataSayac;
char vericikodu1[] = "1";


void setup(){
  TRISIO = 0x00; //HEPS� �IKI�
  GPIO = 0X00;   // T�m portlar s�f�rlan�yor
  CMCON=0X07;  //Analog kar��la�t�r�c�lar kapat�ld�
  ANSEL=0X00;  //Analog giri�ler dijital I/O olarak ayarlan�yor
  OPTION_REG = 0b00000111;   // Timer0 kesmesi i�in 1:256 �n�l�ekleyici de�eri atan�yor
  MAVI=0;
  KIRMIZI=0;
  Man_Receive_Init();
}
void main(){
setup();
 while(1){
  gecici = Man_Receive(&hata);
  if(gecici == 0x0B) break;
 }
 do{
   gecici = Man_Receive(&hata);             // Attempt byte receive
   if (hata) {                            // If error occured
    HataSayac++;                         // Update error counter
    if (HataSayac > 20) {                // In case of multiple errors
     gecici = Man_Synchro();               // Try to synchronize again
     //Man_Receive_Init();               // Alternative, try to Initialize Receiver again
     HataSayac = 0;                     // Reset error counter
    }
   }
    else {                                  // No error occured
     if (gecici != 0x0E){                     // If "End" byte was received(see Transmitter example)
       KIRMIZI=1;
       MAVI=1;                   //   do not write received byte on LCD
     }
    }
    Delay_ms(25);
   }while (gecici != 0x0E) ;
}