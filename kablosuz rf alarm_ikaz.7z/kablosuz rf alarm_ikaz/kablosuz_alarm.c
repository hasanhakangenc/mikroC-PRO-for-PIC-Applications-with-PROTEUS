unsigned short ikaz_biti=0;
unsigned short saniye, zaman=0;
unsigned short i, yukselen=0;
unsigned short ilk=0;
sbit SES at GP0_bit;
sbit KIRMIZI at GP1_bit;
sbit REED_ROLE at GP2_bit;
sbit BIR at GP5_bit;

sbit MANTXPIN at GP4_bit;
sbit MANTXPIN_Direction at TRISIO4_bit;

char indeks, karakter;
char vericikodu1[] = "1";


void setup(){
  ikaz_biti=0;
  TRISIO = 0x24; //GP2, GP4 ve GP5 giri� di�erleri ��k��
  GPIO = 0X00;   // T�m portlar s�f�rlan�yor
  INTCON.GIE=1;   //Evrensel kesme aktif
  INTCON.INTE=1;  //Harici kesme aktif
  INTCON.T0IE=1; //Timer0 kesmesi aktif
  TMR0=125;      //Timer0 kesmesi ba�lang�� de�eri kuruluyor
  CMCON=0X07;  //Analog kar��la�t�r�c�lar kapat�ld�
  ANSEL=0X00;  //Analog giri�ler dijital I/O olarak ayarlan�yor
  OPTION_REG = 0b00000111;   // Timer0 kesmesi i�in 1:256 �n�l�ekleyici de�eri atan�yor
  WPU = 0X24;
  IOC = 0X04;
  KIRMIZI=0;
  SES=0;
  Man_Send_Init();
}
void bitti(){
 GPIO = 0X00;
 saniye=0;
 ikaz_biti=0;
}
void bir_dakika(){
  if(saniye<=10){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>10){
    bitti();
  }
}
void bes_dakika(){
  if(saniye<=50){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>50){
    bitti();
  }
}
void main(){
setup();
 while(1){
  if(!ikaz_biti){
   GPIO = 0X00;
    asm{
     sleep
    }
  }
  if(ikaz_biti){
   Man_Send(0x0B);                // "start" byte g�nderiliyor
   Delay_ms(50);
   karakter = vericikodu1[0];
   indeks = 0;                     // Initialize index variable
    while (karakter) {            // String ends with zero
      Man_Send(karakter);         // Send character
      Delay_ms(90);
      indeks++;                    // Increment index variable
      karakter = vericikodu1[indeks];       // Take next char from string
    }
    Man_Send(0x0E);                // "end" byte g�nderiliyor
    Delay_ms(50);
    if(!BIR){ //Anahtar da 0 konumunda. S�re 1dk.
     bir_dakika();
    }
    if(BIR){ //Anahtarlar 1 konumunda. S�re 5dk.
     bes_dakika();
    }
   }
 }
}

void interrupt(){
 if(INTCON.INTF){
   zaman=0;
   ikaz_biti=1;
   INTCON.INTF=0;
 }
 if(INTCON.T0IF){
   zaman++;
   if(zaman>32){
    saniye++;
    zaman=0;
   }
   INTCON.T0IF=0;
   TMR0=125;
 }
}