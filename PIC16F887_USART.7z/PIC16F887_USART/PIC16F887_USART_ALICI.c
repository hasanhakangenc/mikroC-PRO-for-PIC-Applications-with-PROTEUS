char veri = 0;
//Fonksiyon deklerasyonlari
void UART_RX_Init(void);
void port_Init(void);

//Ana fonksiyon
void main(void) {
 port_Init();
 UART_RX_Init();
  while(1) {
       //islemler kesme yordami i�inde yapiliyor
  }
}

//UART mod�l� 9600 alici ayari yapiliyor
void UART_RX_Init(void){
 BAUDCTL = 0;
 TXSTA.BRGH = 1;
 SPBRG = 51;
 TXSTA.SYNC = 0;
 RCSTA.SPEN = 1;
 RCSTA.CREN = 1;
}

//Portlar ve kesmeler ayarlaniyor
void port_Init(void){
 OSCCON = 0X70;
 INTCON.GIE = 1;
 INTCON.PEIE = 1;
 PIE1.RCIE = 1;
 ANSEL = 0; //t�m portlar dijital I/O
 ANSELH = 0;
 CM1CON0 = 0;  //karsilastiricilar kapali
 CM2CON0 = 0;
 TRISA = 0;
 PORTA = 0;
 TRISB = 0;
 PORTB = 0;
 TRISC = 0xC0;
 PORTC = 0;
 TRISD = 0;
 PORTD = 0;
 TRISE = 0;
 PORTE = 0;
}

void interrupt(void){
 if(PIR1.RCIF){
  veri = RCREG;
  PORTD = veri;
 }
}