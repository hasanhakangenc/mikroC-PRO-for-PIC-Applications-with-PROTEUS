sbit para at GP2_bit;
sbit top at GP4_bit;
sbit motor at GP0_bit;
unsigned short aktif, saniye, sayac; // DC motor y�n de�i�imini takip eden de�i�ken

void kur(){
 TRISIO = 0X1C; // Port G2, GP3 ve G4 giri�
 GPIO = 0X00;
 INTCON.GIE=1;   // Evrensel kesme aktif
 INTCON.INTE=1;  // Harici kesme aktif
 INTCON.GPIE=1;  // Port de�i�im kesmesi aktif
 INTCON.T0IE=1;  //Timer kesmesi aktif
 TMR0=125; // Timer0 i�in ba�lang�� de�eri
 IOC = 0B00010000; /* Interrupt-On-Change GP4 pini i�in aktif */
 CMCON = 0X07;// Kar��la�t�r�c�lar kapat�ld�
 ADCON0 = 0X00; // Analog mod�l� kapat�ld�
 ANSEL = 0X00; // Analog giri�ler dijital I/O olarak ayarland�
 OPTION_REG = 0B01000111; /* Dahili pull-up pasif, y�kselen kenar tetiklemesi, Prescaler 1:256 Timer0 */
 WPU = 0B00010100; // Bireysel GP4 ve GP2 i�in weak pull-up aktif
 aktif, saniye, sayac=0;
}
void bitti(){
 GPIO = 0X00;
 saniye=0;
 aktif =0;
}
void devam(){
  if(saniye<=10){
   motor=1;
  }
  if(saniye>10){
   bitti();
  }
}
void main(){
 kur();
 while(1){
  if(aktif){
   devam();
  }
  if(!aktif){
   GPIO = 0X00;
    asm{
     sleep
    }
  }
 }
}
void interrupt(){
 if(INTCON.INTF){
  if(!top){
   sayac=0;
   aktif=1;
  }
   INTCON.INTF=0;
 }
 if(INTCON.GPIF){
  if(top){
   aktif=0;
  }
  INTCON.GPIF=0;
 }
 if(INTCON.T0IF){
   sayac++;
   if(sayac>32){
    saniye++;
    sayac=0;
   }
   INTCON.T0IF=0;
   TMR0=125;
 }
}