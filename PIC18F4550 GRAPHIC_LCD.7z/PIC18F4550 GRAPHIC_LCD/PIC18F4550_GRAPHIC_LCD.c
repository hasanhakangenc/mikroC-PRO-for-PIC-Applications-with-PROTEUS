/* GLCD pinleri i�in MCU portlar� tan�mlan�yor */
#define GLCD_Data PORTD
#define GLCD_Data_Direction TRISD
#define GLCD_E PORTB.RB5
#define GLCD_DI PORTB.RB4
#define GLCD_RW PORTB.RB3
#define GLCD_Reset PORTB.RB2
#define GLCD_CS2 PORTB.RB1
#define GLCD_CS1 PORTB.RB0

/* Bu k�s�mda program i�inde kullan�lan t�m fonksiyonlar
derleyiciye tan�t�l�yor. B�ylece program�n istenen yerinden
ilgili fonksiyon �a�r�labilir */

void GLCD_Write (unsigned char r, unsigned char datax);
unsigned char GLCD_Read_Data (unsigned char r);
void GLCD_Init();
void Set_Column(unsigned char col);
void Set_Row(unsigned char row);
void Set_XY(unsigned char row, unsigned col);
void Display_Set_Start_Line(unsigned char line);
unsigned char GLCD_Busy();
void Check_GLCD_Busy();
char GLCD_Status();
void GLCD_Write_Char(unsigned char datax);
void GLCD_Write_Str(unsigned char *str, unsigned char count);
char GLCD_Read();
void GLCD_Clear_Display();
void GLCD_Clear_Display2();
void GLCD_Clear_Line(unsigned char datax);
void GLCD_Clear_Line2(unsigned char datax);
void GLCD_Dot(unsigned char x, unsigned char y);

/* kodu ��kart�lm�� resimler y�ksekliklerine uygun olarak sat�rlara
b�l�n�yor */
char bayrak1[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char bayrak2[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127,  63,  31,  15,  15,   7, 135, 199, 227, 227, 227, 243, 247, 231, 231, 239, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char bayrak3[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,   1,   0,   0,   0,   0, 252, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 239, 207, 207,   1,   3, 135, 131,  51, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char bayrak4[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 248, 240, 224, 192, 192, 131, 135, 143,  31,  31,  31, 159, 159, 159, 223, 223, 239, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char bayrak5[] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};
char bayrak6[] = {3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3};

char mustafa_kemal1[] = {0,   0,   0,   0,   0,   0,   0,   0,   0, 128, 128, 128, 192, 224, 224, 240, 248, 248, 252, 252, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 252, 252, 240, 224, 192, 128, 128,   0,   0,   0,   0,   0,   0,   0,   0};
char mustafa_kemal2[] = {0,   0, 240, 252, 252, 254, 254, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 252, 232,   0,   0,   0,   0};
char mustafa_kemal3[] = {0,   0,   0,  15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191,   0,   0,   0,   0};
char mustafa_kemal4[] = {0,   0,   0,   0,   1,  31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 127, 127, 127, 255, 223, 223, 223, 159, 159,  31,  31,  31, 159, 159, 159, 159,  63,  63, 127, 255, 255,  31,   0,   0,   0,   0};
char mustafa_kemal5[] = {0,   0,   0,   0,   0,   0,   0,  31,  15, 255,  63,  31, 207, 195, 131,   1,   3,   5,   6,   6,   6,   6,   2,   5,   7,   7,   1,   1,   1,   0,   3,   7,   3,   7,   2,   4,   0,   0,   7,   1,   0,   0,   0,   0,   0};
char mustafa_kemal6[] = {0,   0,   0,   0,   0,   0,   0,  16,  64,  96, 242, 249,  95, 187, 207, 239, 111,  39,  78,  64,   0, 128, 192, 192, 192, 148, 204, 204, 204, 188, 200, 228, 192, 128,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};
char mustafa_kemal7[] = {0,   0,   0,   0,   0,   0,   0,   0,   1, 193, 115, 253, 255, 254, 255, 255, 253, 252, 255, 254, 254, 252, 225, 225, 193, 192, 198, 199, 198, 198, 128, 192, 192, 160,   0, 128,   0,   0,   0,   0,   0,   0,   0,   0,   0};
char mustafa_kemal8[] = {0,   0,   0,   0,   0,   0,   0,   8,  28,  28, 253, 255, 255, 127, 255, 255, 255, 127, 127, 215, 187, 255, 255, 127,  95, 127, 159, 191, 127, 247, 127, 255,  79,  51,  50, 192,   0,   0,   0,   0,   0,   0,   0,   0,   0};

char C_[] = {0,4,10,17,17,0};
char h_[] = {0,31,4,28,0,0};
char m_[] = {0,24,4,28,4,24};
char tt_[] = {0,2,31,2,0,0};
char T_[] = {0,1,1,31,1,1};
char u_[] = {0,29,16,29,0,0};
char uu_[] = {0,28,16,28,0,0};
char r_[] = {0,30,2,2,0,0};
char k_[] = {0,31,8,20,0,0};
char i_[] = {0,0,29,0,0,0};
char y_[] = {0,18,12,2,0,0};
char e_[] = {0,12,26,22,0,0};
char bos_[] = {0,0,0,0,0,0,0};

char *turkiye[]={T_, u_, r_, k_, i_, y_, e_};
char *cumhuriyeti[]={C_, uu_, m_, h_, uu_, r_, i_, y_, e_, tt_, i_};
int i, k, j, carpan=54;
unsigned char deneme;

void main(){
  OSCCON = 0X72;
  CMCON=0X07; // Analog kar��la�t�r�c�lar kapal�
  ADCON0=0; // A/D mod�l� kapal�
  ADCON1=0X0F; // T�m AN kanallari dijital I/O olarak ayarl�
  TRISA = 0;
  TRISB = 0;
  TRISC = 0;
  TRISD = 0;
  TRISE = 0;
  PORTA = 0;
  PORTB = 0;
  PORTC = 0;
  PORTD = 0;
  PORTE = 0;

  GLCD_Init();        // GLCD a��l�yor
  Check_GLCD_Busy();  // Me�gulse bekle
  GLCD_Clear_Display();

/* T�rkiye Bayra�� Yazd�r�l�yor */
  Set_XY(0,1);
  GLCD_Write_Str(bayrak1, 64);
  Set_XY(1,1);
  GLCD_Write_Str(bayrak2, 64);
  Set_XY(2,1);
  GLCD_Write_Str(bayrak3, 64);
  Set_XY(3,1);
  GLCD_Write_Str(bayrak4, 64);
  Set_XY(4,1);
  GLCD_Write_Str(bayrak5, 64);
  Set_XY(5,1);
  GLCD_Write_Str(bayrak6, 64);

/* Mustafa Kemal Atat�rk yazd�r�l�yor */
  Set_XY(0,65);
  GLCD_Write_Str(mustafa_kemal1, 45);
  Set_XY(1,65);
  GLCD_Write_Str(mustafa_kemal2, 45);
  Set_XY(2,65);
  GLCD_Write_Str(mustafa_kemal3, 45);
  Set_XY(3,65);
  GLCD_Write_Str(mustafa_kemal4, 45);
  Set_XY(4,65);
  GLCD_Write_Str(mustafa_kemal5, 45);
  Set_XY(5,65);
  GLCD_Write_Str(mustafa_kemal6, 45);
  Set_XY(6,65);
  GLCD_Write_Str(mustafa_kemal7, 45);
  Set_XY(7,65);
  GLCD_Write_Str(mustafa_kemal8, 45);
 
 /* T�rkiye Cumhuriyeti yazd�r�l�yor */
  for (i = 0; i < 7; i++){
    for (k = 0; k < 6; k++){
     Set_XY(6,i*6+k);
     GLCD_Write(1, *turkiye[i]);
     turkiye[i]++;
    }
   }
   for (i = 0; i < 11; i++){
    for (k = 0; k < 6; k++){
     Set_XY(7,i*6+k);
     GLCD_Write(1, *cumhuriyeti[i]);
     cumhuriyeti[i]++;
    }
   }
}

void GLCD_Write (unsigned char r, unsigned char datax)
{
 GLCD_Data_Direction = 0x00; // ��k�� olarak kurulur
 GLCD_E = 0; // E pini lojik-0
 GLCD_DI = r; // RS(DI) komut i�in 0, veri i�in 1
 GLCD_RW = 0; // RW yazma modu i�in lojik-0 yap�l�r
 delay_us(1); // Twl > 450ns ve Tasu > 140ns
 GLCD_Data = datax; // Veri portuna veri g�nderilir
 GLCD_E = 1; // E pini lojik-1
 delay_us(1); // Twh > 450ns ve Tdsu > 520ns
 GLCD_E = 0; // E pini lojik-0
 delay_us(1); // Tdhw > 10ns
 GLCD_E = 1; // E pini lojik-1
}

unsigned char GLCD_Read_Data (unsigned char r)
{
 unsigned char datax;
 GLCD_Data_Direction = 0xFF; // Giri� olarak kurulur
 GLCD_E = 0; // E pini lojik-0
 GLCD_DI = r; // RS(DI) komut i�in 0, veri i�in 1
 GLCD_RW = 1; // RW okuma modu i�in lojik-1 yap�l�r
 delay_us(1); // Twl > 450ns ve Tasu > 140ns
 GLCD_E = 1; // Veri Td gecikmesi sonras� g�z�k�r
 datax = GLCD_Data; // Veri portundaki veri al�n�r
 GLCD_E = 0; // E pini lojik-0
 delay_us(1); // Tdhr > 20ns verinin hatta kaybolmas�ndan �nce
}

/* GLD'yi �al��maya haz�r hale getiren fonksiyon */
void GLCD_Init()
{
    GLCD_Reset = 1;     // G�stergeyi resetle
    GLCD_CS1 = 1;       // Sol kontrolc�y� se�
    GLCD_CS2 = 1;       // Sa� kontrolc�y� se�
    GLCD_Write(0, 0x3F); // A�MA i�in yazma komutu
}

/* S�tunu se�mek i�in kullan�lan fonksiyon */
void Set_Column(unsigned char col)
{
    unsigned char datax;
    if (col<64)
    {
        GLCD_CS1 = 1;
        GLCD_CS2 = 0;
        // Komut format�  -> 01XXXXXX
        // XXXXXX -> 0-63 aral���nda s�tun adresi
        datax = (col | 0x40) & 0x7F;
        GLCD_Write(0,datax);
    }
    else
    {
        GLCD_CS1 = 0;
        GLCD_CS2 = 1;
        // Komut format�  -> 01XXXXXX
        // XXXXXX -> 0-63 aral���nda s�tun adresi
        datax = ((col-64) | 0x40) & 0x7F ;
        GLCD_Write(0,datax);
    }
}

/* Sat�r ayarlan�yor */
void Set_Row(unsigned char row)
{
    unsigned char datax;
    // Komut format� :10111XXX, XXX -> sat�r
    datax= (row | 0xB8) & 0xBF;
    GLCD_Write(0, datax);
}

void Set_XY(unsigned char row, unsigned col)
{
    Set_Row(row);
    Set_Column(col);
}

/* Bu fonksiyon iste�e ba�l� olarak kullan�l�r.
Ekran belle�indeki verinin g�sterildi�i sat�r hatt�n�
de�i�tirmeyi sa�lar. B�ylece animasyonlu i�erik tasarlanabilir */
void Display_Set_Start_Line(unsigned char line)
{
    unsigned char datax;
    GLCD_CS1 = 1;
    GLCD_CS2 = 1;
    datax = 0xC0 | line;  // Ba�lang�� sat�r� komudunu kur
    GLCD_Write(0, datax);
}

unsigned char GLCD_Busy()
{
    unsigned char datax;
    datax = GLCD_Read_Data(0);
    return (datax && 0x80);  // Durum bayra�� d�nd�r�l�yor,
                             //  DB7 biti 1 ise me�gul, 0 ise haz�rd�r
}

/* Me�gul sinyali temizlenene kadar beklemeyi sa�layan fonksiyon
 Bir komut �a�r�ld�ktan sonra me�gul bayra�� temizlenene kadar beklemek
i�in kullan�labilir. */
void Check_GLCD_Busy()
{
    while(GLCD_Busy());
}

char GLCD_Status()
{
    unsigned char datax;
    datax = GLCD_Read_Data(0);     // Komut modunda oku
    return (datax && 0x30);   // durum bayra��n� d�nd�r,
//  Ekran kapal�ysa 1, reset i�in 2 ve di�er durumlarda 0
}

void GLCD_Write_Char(unsigned char datax)
{
    GLCD_Write(1, datax);    // Veri modunda yazma
}

// �ok say�da bayt�n RAM'e g�nderilmesi i�in kullan�lan fonksiyon
// G�nderilen verinin sayfa ve s�tun limitlerini a�mad���ndan emin olun
void GLCD_Write_Str(unsigned char *str, unsigned char count)
{
    unsigned char c=0;
    do{
        GLCD_Write(1, *str);    // Veri modunda yazma
        c++;
        str++;
        } while(c < count);
}

char GLCD_Read()
{
    unsigned char datax;
    datax = GLCD_Read_Data(1);    // Veri modunda okuma
    return datax;
}

void GLCD_Clear_Display()
{
    unsigned char i=0;
    GLCD_Clear_Line(i);    // Her sat�r� temizle
}

void GLCD_Clear_Line(unsigned char datax){
 unsigned char i, j;
 for(i=0;i<8;i++){
  for(j=0;j<128;j++){
   Set_XY(i, j);
   GLCD_Write_Char(datax);
  }
 }
}

void GLCD_Dot(unsigned char x, unsigned char y)
{
    Set_XY(x, y);    // Pozisyon kurulur
    GLCD_Write(1, 0x70);    // Veri modunda yazma
}