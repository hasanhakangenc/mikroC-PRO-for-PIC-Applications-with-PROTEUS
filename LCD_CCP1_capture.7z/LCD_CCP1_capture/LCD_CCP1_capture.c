char msj01[] = "TIMER1= ";
char msj02[6];
char msj03[6];
char msj04[6];

unsigned int timer1, ccp1, sayac;

sbit LCD_RS at RB0_bit; //LCD ba�lant�lar� ayarlan�yor
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;

sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;

void ayarlar(){
 TRISA=0;
 PORTA=0;
 Lcd_Init(); // Lcd_Init PORTB LCD i�in haz�rland�
 TRISB2_bit=0;
 TRISB3_bit=1;
 PORTB=0;
 CMCON=0x07; // Kar��la�t�r�c� mod�lleri dijitale ayarland�
 OPTION_REG  = 0B10000000; //dahili pull-up'lar aktif de�il
 INTCON.GIE = 1; // Evrensel kesme aktif yap�l�yor
 INTCON.PEIE=1; // �evresel ayg�t kesmesi aktif yap�l�yor
 PIE1.TMR1IE=1; //Timer1 kesmesi aktif
 T1CON = 0B00110001;//Timer1 MCU osilat�r� ile e�le�tirilerek aktif yap�l�yor
 //prescaler 1:8
 CCP1CON = 0B00000101; // Her y�kselen kenarda yakalama modudur
 Delay_us(50);
 TMR1H=0X00;
 TMR1L=0X00;

}
void main() {
  ayarlar();
  Lcd_out(1,1,msj01);
 while(1){
  timer1=((TMR1H << 8) + TMR1L);
  WordtoStr(timer1,msj02);//2byte'l�k bilgi string mesaja �evriliyor
  Lcd_out(1,9,msj02);
  WordtoStr(sayac,msj03);//2byte'l�k bilgi string mesaja �evriliyor
  Lcd_out(2,1,msj03);
  WordtoStr(ccp1,msj04);//2byte'l�k bilgi string mesaja �evriliyor
  Lcd_out(2,9,msj04);
  delay_ms(100);
 }
}

void interrupt()
{
 if(CCP1IF_bit){ //CCP1IF kesmesi mi?
  ccp1 = ((CCPR1H << 8) + CCPR1L);
  CCP1IF_bit=0; //CCP kesmesi yeni kesme i�in s�f�rlan�yor
  Delay_us(50);
 }
 if(TMR1IF_bit){
  sayac++; //Timer1 kesme h�z�n� izlemek i�in kullan�lan de�i�ken
  T1CON.TMR1ON=0;
  Delay_us(50);
  TMR1H=0;
  TMR1L=0;
  T1CON.TMR1ON=1;
  TMR1IF_bit=0; //Timer1 kesmesi yeniden saymas� i�in s�f�rlan�yor
 }
}