#define MOTOR PORTC.RC2
#define MIRRORC1 CM1CON0.C1OUT
#define MIRRORC2 CM2CON0.C2OUT
unsigned char i, kesme1, kesme2;
void ayar(){
/* Bu k�s�mda giri�/��k�� durumuna g�re portlar�n ayar� yap�l�r. */
 TRISA.RA0 = 1; //C12IN0- giri� olarak ayarlan�yor
 TRISA.RA1 = 1; //C12IN1- giri� olarak ayarlan�yor
 TRISA.RA2 = 1; //C2 evirmeyen giri�i C2IN+ giri� olarak ayarlan�yor
 TRISA.RA3 = 1; //C1 evirmeyen giri�i C1IN+ giri� olarak ayarlan�yor
 TRISA.RA4 = 0;
 TRISA.RA5 = 0;
 PORTA = 0;
 PORTB = 0;
 TRISC = 0;
 PORTC = 0;
 TRISD = 0;
 PORTD = 0;
 TRISE = 0;
 PORTE = 0;
 /* Bu k�s�mda port giri�lerinin davran��� belirlenir ve
 analog kanal ayarlar� yap�l�r. */
 ANSEL = 0X0F; //A0-A3 kanallar� analog di�erleri dijital I/O
 ANSELH = 0; //T�m AN kanallar� dijital I/O olarak ayarland�
 INTCON.GIE = 1;
 INTCON.PEIE = 1;
 OSCCON=0X70; /* Osilat�r dahili 8MHz ve OSC pinlerinin davran���
 CONFIG1 konfig�rasyon s�zc���ne g�re ayarlan�yor */
 /* Bu k�s�mda C1 ve C2 kar��la�t�r�c�lar�n�n ayarlar� yap�l�r. */
 CM1CON0.C1ON = 1; //C1 a��l�yor
 CM1CON0.C1OE = 1; //C1OUT RA4 pininden al�nacak
 CM1CON0.C1POL = 0;
 CM1CON0.C1R = 0; //C1 evirmeyen giri�i RA3/C1IN+ olarak ayarlan�yor
 CM1CON0.C1CH0 = 0; //
 CM1CON0.C1CH1 = 0; // C1IN- giri�i olarak C12IN0- se�iliyor

 CM2CON0.C2ON = 1; //C2 a��l�yor
 CM2CON0.C2OE = 1; //C2OUT RA5 pininden al�nacak
 CM2CON0.C2POL = 0;
 CM2CON0.C1R = 0; //C2 evirmeyen giri�i RA2/C2IN+ olarak ayarlan�yor
 CM2CON0.C1CH0 = 1; //
 CM2CON0.C1CH1 = 0; // C2IN- giri�i olarak C12IN1- se�iliyor
                 //yapay gecikme yap�l�yor
 C1IF_bit = 0;
 C2IF_bit = 0; //Kesmeler aktif edilmeden �nce bayraklar� temizleniyor
     asm{
     NOP;NOP;NOP;NOP; //Kar��la�t�r�c� mod�llerinin besleme dengesi i�in yapay bekleme
    }
   PIE2.C1IE = 1; //C1 kar��la�t�r�c�s� kesmesi aktif
   PIE2.C2IE = 1; //C2 kar��la�t�r�c�s� kesmesi aktif
}
void main(){
 ayar();
 while(1) {
  if(kesme1 && kesme2) MOTOR=1;
  if(!kesme1 || !kesme2){
   MOTOR=0;
   asm{
    sleep;nop;
   }
  }
 }
}
void interrupt(){
 if(PIR2.C1IF){ // C1 kesmesi mi?
  if(MIRRORC1)kesme1=1;
  if(!MIRRORC1)kesme1=0;
  PIR2.C1IF=0;
 }
 if(PIR2.C2IF){ // C2 kesmesi mi?
  if(MIRRORC2)kesme2=1;
  if(!MIRRORC2)kesme2=0;
  PIR2.C2IF=0;
 }
}