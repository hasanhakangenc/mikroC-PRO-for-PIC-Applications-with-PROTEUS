#define AI1 PORTA.RA0
#define AI2 PORTA.RA1
#define BI1 PORTA.RA2
#define BI2 PORTA.RA3
#define ileriA PORTB.RB0
#define geriA PORTB.RB1
#define ileriB PORTB.RB2
#define geriB PORTB.RB3
unsigned short zaman, arttir, azalt;
unsigned char birlerA, onlarA, birlerB, onlarB;
//unsigned int taramasuresi=45;
short sayacA=0, sayacB=0, sayac11, sayac22;
void port_Init(void);
void main() {
  port_Init();

 while(1){
  birlerA=sayacA%10;    //saya� A degerinin birler basamagi aliniyor.
  onlarA=(sayacA/10)%10;//saya� A degerinin onlar basamagi aliniyor.
  birlerB=sayacB%10;    //saya� B degerinin birler basamagi aliniyor.
  onlarB=(sayacB/10)%10;//saya� B degerinin onlar basamagi aliniyor.
  AI1 = 1; //A takimi 1'ler basamagi aktif yapiliyor
  AI2 = 1;
  BI1 = 1; //B takimi 1'ler basamagi aktif yapiliyor
  BI2 = 1;
  sayac11 = birlerA<<4;
  PORTC=sayac11+onlarA; //Birler basamaginin bilgisi displaylere g�nderiliyor
  //Vdelay_ms(taramasuresi);
 /* AI1 = 0;
  AI2 = 1;
  BI1 = 0;
  BI2 = 1;  */
  sayac22 = birlerB<<4;
  PORTD=sayac22+onlarB; //Onlar basamaginin bilgisi displaylere g�nderiliyor
  //Vdelay_ms(taramasuresi);
  
  if(ileriA==0){
   delay_ms(100);
   if(ileriA==0){
    sayacA++;
    if(sayacA>99) sayacA=0;
   }
  }
  if(geriA==0){
   delay_ms(100);
   if(geriA==0){
    if(sayacA==0) sayacA=99;
    else sayacA--;
   }
  }
  if(ileriB==0){
   delay_ms(100);
   if(ileriB==0){
    sayacB++;
    if(sayacB>99) sayacB=0;
   }
  }
  if(geriB==0){
   delay_ms(100);
   if(geriB==0){
    if(sayacB==0) sayacB=99;
    else sayacB--;
   }
  }
 }
}
 //Portlar ve kesmeler ayarlaniyor
void port_Init(void){
 OSCCON = 0X72; //8MHz dahili osilat�r
 OPTION_REG = 0; //Dahili pull-ap'lar aktif
 WPUB = 0X0F; //B potu ilk 4 pini i�in weak pull-up'lar aktif
 ANSEL = 0; //t�m portlar dijital I/O
 ANSELH = 0;
 CM1CON0 = 0;  //karsilastiricilar kapali
 CM2CON0 = 0;
 TRISA = 0;
 PORTA = 0;
 TRISB = 0x0F; //B portu ilk 4 pini giris
 PORTB = 0;
 TRISC = 0;
 PORTC = 0;
 TRISD = 0;
 PORTD = 0;
 TRISE = 0;
 PORTE = 0;
}