#define TEST PORTA.RA5
char i;
unsigned int sure;
void ayar(){
 ANSELA=0x01; //AN0 analog di�erleri dijital I/O
 OSCCON=0B01110000; //8MHZ dahili HFINTOSC
 FVRCON=0; //Sabit voltaj referans� mod�l� kapal�
 OPTION_REG = 0B00000000; //Timer0 prescaler 1:2
 DACCON0.DACEN=1; //DAC mod�l� a��l�yor
 DACCON0.DACLPS=1; //Pozitif referans kayna��
 DACCON0.DACOE=1;  //DAC voltaj seviyesi DACOUT pininden al�n�r
 DACCON0.DACPSS1=0;
 DACCON0.DACPSS0=0; //DAC pozitif kayna�� VDD
 TRISA = 0X01; //DACOUT pini giri� olarak ayarlan�yor
 PORTA = 0;
 LATA = 0;
 INTCON.GIE=1;
 INTCON.T0IE=1;
 TMR0=255;
}
void main() {
  ayar();
  DACCON1=0; //0B00000000;
  Delay_ms(100);
  while(1){
   for(i=0;i<32;i++){
    while(sure<35);
    sure=0;
    DACCON1++;
   }
   for(i=0;i<32;i++){
    while(sure<34);
    sure=0;
    DACCON1--;
   }
  }
}
void interrupt(){
 if(INTCON.TMR0IF){//Timer0 kesmesi 1us'ye ayarland�
  sure++;
  TMR0=255;
  INTCON.TMR0IF=0;
 }
}