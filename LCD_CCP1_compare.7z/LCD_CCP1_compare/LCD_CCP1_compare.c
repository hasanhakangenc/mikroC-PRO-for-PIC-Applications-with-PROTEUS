char msj01[] = "TIMER1= ";
char msj02[6];
unsigned int timer1, ccp1, sayac;
sbit LCD_RS at RA7_bit; //LCD ba�lant�lar� ayarlan�yor
sbit LCD_EN at RA6_bit;
sbit LCD_D4 at RA0_bit;
sbit LCD_D5 at RA1_bit;
sbit LCD_D6 at RA2_bit;
sbit LCD_D7 at RA3_bit;

sbit LCD_RS_Direction at TRISA7_bit;
sbit LCD_EN_Direction at TRISA6_bit;
sbit LCD_D4_Direction at TRISA0_bit;
sbit LCD_D5_Direction at TRISA1_bit;
sbit LCD_D6_Direction at TRISA2_bit;
sbit LCD_D7_Direction at TRISA3_bit;

void ayarlar(){
 TRISA=0;
 PORTA=0;
 TRISB=0X01; //B0 pini giri�
 PORTB=0;
 Lcd_Init();
 CMCON=0x07; // Kar��la�t�r�c� mod�lleri dijitale ayarland�
 OPTION_REG  = 0; // Dahili pull-up'lar pasif
 INTCON.GIE = 1; // Evrensel kesme aktif yap�l�yor
 INTCON.INTE = 1; // Harici kesme aktif yap�l�yor
 T1CON = 0B00000010;// Timer1 say�c� moduna ayarlan�yor, prescaler 1:1
 CCP1CON = 0B00001000; // CCP1'i lojik-1 yapan kar��la�t�rma modu
 Delay_us(50);
 CCPR1H=0x00;
 CCPR1L=0X0A; //CCPR1 kaydedicileri toplamda 10 de�erine ayarlan�yor
 TMR1H=0X00;
 TMR1L=0X00;
 T1CON.TMR1ON=1;//Timer1 �al��t�r�l�yor
}
void main() {
  ayarlar();
  Lcd_out(1,1,msj01);
 while(1){
   timer1=((TMR1H << 8) + TMR1L);
   WordtoStr(timer1,msj02);//2byte'l�k bilgi string mesaja �evriliyor
   Lcd_cmd(_LCD_CURSOR_OFF);
   Lcd_out(1,9,msj02);
 }
}
void interrupt()
{
 if(CCP1IF_bit){ //CCP1IF kesmesi mi?
  TMR1H=0X00;
  TMR1L=0X00;
  CCP1IF_bit=0; //CCP kesmesi yeni kesme i�in s�f�rlan�yor
  Delay_us(50);
 }
 if(INTF_bit){
  CCP1CON=0;
  Delay_us(50);
  CCP1CON=0B00001000;//resetleme sonras� CCP1 tekrar kuruluyor
  CCPR1H=0x00;
  CCPR1L=0X0A;
  INTF_bit=0;
 }
}