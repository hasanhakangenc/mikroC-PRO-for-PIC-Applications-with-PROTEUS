unsigned int i;
char msj01[] = "ELEKTRONIK BOLUMUNE HOSGELDIN";
char msj02[] = "MERHABA ONUR";

//const char character[] = {0,0,14,17,17,17,14,0};


char *pointer_msj01, *pointer_msj02;   //pointer t�r�nde de�i�ken
unsigned int uzunluk_msj01, uzunluk_msj02, konum;

sbit LCD_RS at RB2_bit; //LCD ba�lant�lar� ayarlan�yor
sbit LCD_EN at RB3_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;

sbit LCD_RS_Direction at TRISB2_bit;
sbit LCD_EN_Direction at TRISB3_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;


/**************************************************************/
/**************************************************************/
void ayarlar(){
 TRISB=0x00;
 PORTB=0;
 TRISA=0X00;
 PORTA=0;
 INTCON = 0; // T�m kesmeler iptal edildi
 Lcd_Init(); // Lcd_Init PORTB LCD i�in haz�rland�
 //Lcd_Cmd(_LCD_CURSOR_OFF);  // LCD kurs�r kapat�ld�
// Lcd_Cmd(_LCD_CLEAR); // LCD'de rastgele karekter olu�mamas� i�in silindi
 CMCON=0x07; // Kar��la�t�r�c� mod�lleri dijitale ayarland�
}
  /*
void CustomChar(char pos_row, char pos_char) {
  char i;
    Lcd_Cmd(64);
    for (i = 0; i<=7; i++) Lcd_Chr_CP(character[i]);
    Lcd_Cmd(_LCD_RETURN_HOME);
    Lcd_Chr(pos_row, pos_char, 0);
} */
 /**************************************************************/
void main() {
 ayarlar();
 //CustomChar(1,1);
 uzunluk_msj01 = strlen(msj01);
 uzunluk_msj02 = strlen(msj02);
 konum = (16-uzunluk_msj02)/2;
 for(;;){
  pointer_msj01 = &msj01;
  pointer_msj02 = &msj02;
  for(i=0;i<16;i++){
   Lcd_Out(1,16-i,msj01);
   Lcd_Out(2,konum,pointer_msj02);
   delay_ms(100);
  }
  for(i=0;i<uzunluk_msj01;i++){
   Lcd_Out(1,1,pointer_msj01);
   Lcd_Out(2,konum,pointer_msj02);
   delay_ms(100);
   Lcd_Cmd(_LCD_CLEAR);
   pointer_msj01++;
  }
 }
}