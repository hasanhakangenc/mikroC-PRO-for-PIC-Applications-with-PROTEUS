// LCD Tan�mlamalar�
#define _LCD_TEMIZLE            0x01 // Ekran� temizle
#define _LCD_BASLANGIC          0x02 // Kurs�r� ba�lang�� noktas�na getir
#define _LCD_KAPAT              0x08 // Ekran� kapat
#define _LCD_AC                 0x0C // Ekran� a� - kurs�r kapal�
#define _LCD_CURSOR_ON          0x0E // Ekran� a� - kurs�r de a��k
#define _LCD_BLINK_CURSOR_ON    0x0F // Kurs�r� yak�p-s�nd�r
#define _LCD_MOVE_CURSOR_LEFT   0x10 // Kurs�r� g�r�nt� veri RAM'ini de�i�tirmeden sola kayd�r
#define _LCD_MOVE_CURSOR_RIGHT  0x14 // Kurs�r� g�r�nt� veri RAM'ini de�i�tirmeden sa�a kayd�r
#define _LCD_SHIFT_LEFT         0x18 // G�r�nt� veri RAM'ini de�i�tirmeden g�r�nt�y� sola kayd�r
#define _LCD_SHIFT_RIGHT        0x1E // G�r�nt� veri RAM'ini de�i�tirmeden g�r�nt�y� sa�a kayd�r
#define _LCD_FIRST_ROW          0x80 // Kurs�r� 1'nci sat�ra getir
#define _LCD_SECOND_ROW         0xC0 // Kurs�r� 2'nci sat�ra getir
#define _LCD_THIRD_ROW          0x94 // Kurs�r� 3'nci sat�ra getir
#define _LCD_FOURTH_ROW         0xD4 // Kurs�r� 4'nci sat�ra getir
#define _LCD_4BIT_HAZIRLA       0X20 // LCD 4 bit modunda haz�rlan�yor ve RS/E bitleri lojik-0
#define _LCD_4BIT_FORMAT        0X28 // LCD 4 bit 2 sat�r 5x7 dotmatriks format�nda kuruluyor
#define _PCF8574_ADDR           0x4E // A0-2 pinleri lojik-1(VDD'ye ba�l�yken) olan PCF8574 yazma adresi

// Lcd sabitleri
char txt1[] = "I2C LCD";
char txt2[] = "16x2, 20x2, 20x4";
char txt3[] = "PIC12F1840";
char txt4[9] = "        ";
unsigned short osilator;

void I2C_LCD_Cmd(char out_char) {

    char hi_n, lo_n; //high nibble ve low nibble verileri
    // 4bitlik modda �nce high sonra low nibble de�erleri g�nderildi�i i�in
    // 1 byte'l�k bilginin y�ksek ve al�ak 4bit k�s�mlar� ay�klan�yor
    hi_n = out_char & 0xF0;  // 1 Byte'�n y�ksek k�sm� al�n�yor
    lo_n = (out_char << 4) & 0xF0; // 1 Byte'�n al�ak k�sm� al�n�yor

    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(_PCF8574_ADDR);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | _LCD_KAPAT);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | _LCD_KAPAT);
    I2C1_Is_Idle();
    I2C1_stop();

    if(out_char == 0x01)Delay_ms(2);
}

void I2C_LCD_Chr(char row, char column, char out_char) {
    char hi_n, lo_n;
    switch(row){
        case 1:
        I2C_LCD_Cmd(_LCD_FIRST_ROW + (column - 1));
        break;
        case 2:
        I2C_LCD_Cmd(_LCD_SECOND_ROW + (column - 1));
        break;
        case 3:
        I2C_LCD_Cmd(_LCD_THIRD_ROW + (column - 1));
        break;
        case 4:
        I2C_LCD_Cmd(_LCD_FOURTH_ROW + (column - 1));
        break;
    };

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(_PCF8574_ADDR);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | _LCD_TEMIZLE | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | _LCD_TEMIZLE | _LCD_KAPAT);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | _LCD_TEMIZLE | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | _LCD_TEMIZLE | _LCD_KAPAT);
    I2C1_Is_Idle();
    I2C1_stop();
}

void I2C_LCD_Chr_Cp(char out_char) {
    char hi_n, lo_n;
    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;
    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(_PCF8574_ADDR);
    I2C1_Is_Idle();
    I2C1_Wr(hi_n | _LCD_TEMIZLE | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(hi_n | _LCD_TEMIZLE | _LCD_KAPAT);
    I2C1_Is_Idle();
    Delay_us(100);
    I2C1_Wr(lo_n | _LCD_TEMIZLE | _LCD_AC);
    I2C1_Is_Idle();
    Delay_us(50);
    I2C1_Wr(lo_n | _LCD_TEMIZLE | _LCD_KAPAT);
    I2C1_Is_Idle();
    I2C1_stop();
}

void I2C_LCD_Init() {
    I2C1_Start();
    I2C1_Is_Idle();
    I2C1_Wr(_PCF8574_ADDR);
    I2C1_Is_Idle();

    // 4 bitlik veri transfer moduna g�re LCD ayarlan�yor
    Delay_ms(10);
    I2C1_Wr(_LCD_4BIT_HAZIRLA);
    I2C1_Is_Idle();
    I2C1_Stop();
    Delay_ms(10);
    I2C_LCD_Cmd(_LCD_4BIT_FORMAT);
}

void I2C_LCD_Out(char row, char col, char *text) {
    while(*text)
         I2C_LCD_Chr(row, col++, *text++);
}

void I2C_LCD_Out_Cp(char *text) {
    while(*text)
         I2C_LCD_Chr_Cp(*text++);
}

void main() {
    ANSELA = 0x00;
    TRISA  = 0x00;
    PORTA  = 0x00;
    LATA   = 0x00;
    /* 
    ------ Osilat�r�n ayarlanmas� -------
    Proje edit�r�nde PLL kapal�ysa (CONFIG1 PLLEN=0 ise),
    dahili osilat�r frekans� 31kHz-16MHz aras� ayarlan�r.
    PLLEN = 1 ise ya da SPLLEN = 1 yap�l�rsa 8 MHz dahili
    osilat�r modunda x4 etkeniyle 32 MHz elde edilir.
    E�er sistemde iki osilat�r kayna�� kullan�lacaksa
    o zaman OSCCON kaydedicisinin SCS<1:0> bitleri '10'
    olarak ayarlan�r. B�ylece yaz�l�msal olarak iki kaynak aras�nda
    ge�i� yap�labilir. E�er do�rudan sadece dahili osilat�r
    kayna�� kullan�lacak ve OSC1-OSC2 pinleri bo�a ��kart�lacaksa
    CONFIG1 s�zc���n�n FOSC<2:0> bitleri '100' yap�l�r (INTOSC).
    Ard�ndan OSCCON kaydedicisinin SCS<1:0> bitleri '00' olarak
    ayarlan�r.
    */
    OSCCON = 0b01101000; //�u anda 4MHz'e ayarl�
    osilator = OSCCON;
    osilator = (osilator >> 3) & 0x0F;
    switch (osilator){
     case 0: strcpy(txt4,"31 kHz");break;
     case 1: strcpy(txt4,"31 kHz");break;
     case 2: strcpy(txt4,"31.25 kHz");break;
     case 3: strcpy(txt4,"31.25 kHz");break;
     case 4: strcpy(txt4,"62.5 kHz");break;
     case 5: strcpy(txt4,"125 kHz");break;
     case 6: strcpy(txt4,"250 kHz");break;
     case 7: strcpy(txt4,"500 kHz");break;
     case 8: strcpy(txt4,"125 kHz");break;
     case 9: strcpy(txt4,"250 kHz");break;
     case 10: strcpy(txt4,"500 kHz");break;
     case 11: strcpy(txt4,"1 MHz");break;
     case 12: strcpy(txt4,"2 MHz");break;
     case 13: strcpy(txt4,"4 MHz");break;
     case 14: strcpy(txt4,"8 MHz");break;
     case 15: strcpy(txt4,"16 MHz");break;
    }
    I2C1_Init(100000); // I2C Mod�l� 100kHz frekansta haz�rlan�yor
    I2C_LCD_Init(); //Kullan�c� tan�ml� LCD fonksiyonu ile LCD a��l�yor
    I2C_LCD_Cmd(_LCD_AC);
    I2C_LCD_Cmd(_LCD_TEMIZLE);
    I2C_LCD_Cmd(_LCD_CURSOR_ON);
    I2C_Lcd_Out(1,1,txt1);  // Birinci sat�ra yaz
    I2C_Lcd_Out(2,1,txt2);  // �kinci sat�ra yaz
    I2C_Lcd_Out(3,1,txt3);  // ���nc� sat�ra yaz
    I2C_Lcd_Out(4,1,txt4);  // D�rd�nc� sat�ra yaz
    I2C_LCD_Cmd(_LCD_AC);
    
    while(1) { //Sonsuz d�ng�
    }
}