#define KONTROL PORTD.RD0 // D portunun 0. pinine (RD0) KONTROL ismi veriliyor
unsigned int sayac, saniye;
void main() {
    OPTION_REG = 0x00; // �n �l�ekleyici WDT i�in ayarlanmad�
    TRISD = 0;
    PORTD = 0;
    ANSEL = 0;
    ANSELH = 0;
    CM1CON0 = 0;
    CM2CON0 = 0;
    OSCCON=0X00;
    INTCON.GIE=1;
    INTCON.PEIE=1;
    PIE1.TMR1IE=1;
    T1CON=0X01;
    TMR1L=0X00;
    TMR1H=0XF0; //61440 de�eri y�kleniyor
    WDTCON=0x03;
    KONTROL = 1;      // RD0 lojik-1 yap�l�yor
    while(!PIR1.TMR1IF); //Timer1 kesmesi olu�ana kadar D0 ��k��� aktif kal�yor
    saniye=0;
    KONTROL = 0;

    asm{ // Assembly kod blo�u a��l�yor
     SLEEP; // Mikrodenetleyici uyku moduna al�n�yor
     NOP;
    }
}
void interrupt(){
 if(PIR1.TMR1IF){
   PIR1.TMR1IF=0;
   TMR1L=0X00;
   TMR1H=0XF0;
   asm{// Timer1 tekrar a��lmadan �nce ge�ici bekleme yap�l�yor
    nop;nop;nop;nop;nop;
    }
    T1CON.TMR1ON=1;
 }
}