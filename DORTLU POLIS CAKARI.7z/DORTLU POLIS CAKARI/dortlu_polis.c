unsigned int i=0, efekt=0;
void cakar(){
   for(i=0;i<3;i++){
    PORTA=0X01;
    delay_ms(20);
    PORTA=0X00;
    delay_ms(20);
   }
   for(i=0;i<3;i++){
    PORTA=0X08;
    delay_ms(20);
    PORTA=0X00;
    delay_ms(20);
   }
   for(i=0;i<3;i++){
    PORTA=0X04;
    delay_ms(20);
    PORTA=0X00;
    delay_ms(20);
   }
   for(i=0;i<3;i++){
    PORTA=0X02;
    delay_ms(20);
    PORTA=0X00;
    delay_ms(20);
   }
}

void sirali(){
  PORTA=0x01; delay_ms(50);
  PORTA=0X02; delay_ms(50);
  PORTA=0x04; delay_ms(50);
  PORTA=0x08; delay_ms(50);
}

void durdur(){
 PORTA=0x00;
}

void main() {          // bekleme
TRISB=0xF1;
PORTB=0x00;
TRISA=0x00;
PORTA=0x00;
CMCON =0x07;
OPTION_REG=0X07;
INTCON.GIE = 1; // Evrensel kesme etkinle�tiriliyor
INTCON.INTE = 1; // Harici kesme etkinle�tiriliyor
INTCON.RBIE = 1;

 while(1){
  if(efekt==0){
   durdur();
  }
  else if(efekt==1){
   cakar();
  }
  else{
   sirali();
  }
 }
}

void interrupt(){
 if(INTCON.INTF){
  if(efekt>0) efekt=0;
  else if(efekt==0) efekt=1;
  INTCON.INTF=0;
 }
 if(INTCON.RBIF){
  if(!PORTB.RB4){
   efekt++;
   if(efekt>2){
    efekt=0;
   }
  }
  INTCON.RBIF=0;
 }
}