#include "DS1820.c"
// LCD Tan�mlamalar�
#define _LCD_TEMIZLE 0x01 // Ekran� temizle
#define _LCD_BASLANGIC 0x02 // Kurs�r� ba�lang�� noktas�na getir
#define _LCD_KAPAT 0x08 // Ekran� kapat
#define _LCD_AC 0x0C // Ekran� a� - kurs�r kapal�
#define _LCD_CURSOR_ON 0x0E // Ekran� a� - kurs�r de a��k
#define _LCD_BLINK_CURSOR_ON 0x0F // Kurs�r� yak�p-s�nd�r
#define _LCD_MOVE_CURSOR_LEFT 0x10 // Kurs�r� g�r�nt� veri RAM'ini de�i�tirmeden sola kayd�r
#define _LCD_MOVE_CURSOR_RIGHT 0x14 // Kurs�r� g�r�nt� veri RAM'ini de�i�tirmeden sa�a kayd�r
#define _LCD_SHIFT_LEFT 0x18 // G�r�nt� veri RAM'ini de�i�tirmeden g�r�nt�y� sola kayd�r
#define _LCD_SHIFT_RIGHT 0x1E // G�r�nt� veri RAM'ini de�i�tirmeden g�r�nt�y� sa�a kayd�r
#define _LCD_FIRST_ROW 0x80 // Kurs�r� 1'nci sat�ra getir
#define _LCD_SECOND_ROW 0xC0 // Kurs�r� 2'nci sat�ra getir
#define _LCD_THIRD_ROW 0x94 // Kurs�r� 3'nci sat�ra getir
#define _LCD_FOURTH_ROW 0xD4 // Kurs�r� 4'nci sat�ra getir
#define _LCD_4BIT_HAZIRLA 0X20 // LCD 4 bit modunda haz�rlan�yor ve RS/E bitleri lojik-0
#define _LCD_4BIT_FORMAT 0X28 // LCD 4 bit 2 sat�r 5x7 dotmatriks format�nda kuruluyor
#define _PCF8574_ADDR 0x4E // A0-2 pinleri lojik-1(VDD'ye ba�l�yken) olan PCF8574 yazma adresi
float t = 0;
char sicaklik[15];
char satir[4]="0";
char sensor_count = 0;
char sat;

void I2C_init(void){
 TRISA.F1=1; //SCL saat darbesi pini giri� olarak ayarland�
 TRISA.F2=1; //SDA seri data pini giri� olarak ayarland�
 SSP1CON1 = 0B00101000; //I2C master modunda etkinle�tirildi
 SSP1ADD = 0X09; // h�z = FOSC/(SSP1ADD + 1)*4 = 100kHz
 SSP1STAT = 0B11000000; //d�n�� oran� iptal edildi
}
void I2C_Bosta(void){
 while ( ( SSP1CON2 & 0x1F ) || ( SSPSTAT & 0x04 ) );
}
void I2C_Basla(void)
{
 I2C_Bosta();
 SEN_bit=1;
}
void I2C_Yaz(char veri)
{
 I2C_Bosta();
 SSPBUF = veri;
}
void I2C_Durdur(void)
{
    I2C_Bosta();
    PEN_bit=1;
}
void I2C_LCD_Cmd(char out_char) {
 char hi_n, lo_n; //high nibble ve low nibble verileri
  // 4bitlik modda �nce high sonra low nibble de�erleri g�nderildi�i i�in
  // 1 byte'l�k bilginin y�ksek ve al�ak 4bit k�s�mlar� ay�klan�yor
 hi_n = out_char & 0xF0; // 1 Byte'�n y�ksek k�sm� al�n�yor
 lo_n = (out_char << 4) & 0xF0; // 1 Byte'�n al�ak k�sm� al�n�yor
 I2C_Basla();
 I2C_Bosta();
 I2C_Yaz(_PCF8574_ADDR);
 I2C_Bosta();
 I2C_Yaz(hi_n | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(hi_n | _LCD_KAPAT);
 I2C_Bosta();
 Delay_us(100);
 I2C_Yaz(lo_n | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(lo_n | _LCD_KAPAT);
 I2C_Bosta();
 I2C_Durdur();
 if(out_char == 0x01)Delay_ms(2);
}
void I2C_LCD_Chr(char row, char column, char out_char) {
 char hi_n, lo_n;
 switch(row){
  case 1:
   I2C_LCD_Cmd(_LCD_FIRST_ROW + (column - 1));
  break;
  case 2:
   I2C_LCD_Cmd(_LCD_SECOND_ROW + (column - 1));
  break;
  case 3:
   I2C_LCD_Cmd(_LCD_THIRD_ROW + (column - 1));
  break;
  case 4:
   I2C_LCD_Cmd(_LCD_FOURTH_ROW + (column - 1));
  break;
 };
 hi_n = out_char & 0xF0;
 lo_n = (out_char << 4) & 0xF0;
 I2C_Basla();
 I2C_Bosta();
 I2C_Yaz(_PCF8574_ADDR);
 I2C_Bosta();
 I2C_Yaz(hi_n | _LCD_TEMIZLE | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(hi_n | _LCD_TEMIZLE | _LCD_KAPAT);
 I2C_Bosta();
 Delay_us(100);
 I2C_Yaz(lo_n | _LCD_TEMIZLE | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(lo_n | _LCD_TEMIZLE | _LCD_KAPAT);
 I2C_Bosta();
 I2C_Durdur();
}
void I2C_LCD_Chr_Cp(char out_char) {
 char hi_n, lo_n;
 hi_n = out_char & 0xF0;
 lo_n = (out_char << 4) & 0xF0;
 I2C_Basla();
 I2C_Bosta();
 I2C_Yaz(_PCF8574_ADDR);
 I2C_Bosta();
 I2C_Yaz(hi_n | _LCD_TEMIZLE | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(hi_n | _LCD_TEMIZLE| _LCD_KAPAT);
 I2C_Bosta();
 Delay_us(100);
 I2C_Yaz(lo_n | _LCD_TEMIZLE | _LCD_AC);
 I2C_Bosta();
 Delay_us(50);
 I2C_Yaz(lo_n | _LCD_TEMIZLE | _LCD_KAPAT);
 I2C_Bosta();
 I2C_Durdur();
}
void I2C_LCD_Init() {
 I2C_Basla();
 I2C_Bosta();
 I2C_Yaz(_PCF8574_ADDR);
 I2C_Bosta();

 // 4 bitlik veri transfer moduna g�re LCD ayarlan�yor
 Delay_ms(10);
 I2C_Yaz(_LCD_4BIT_HAZIRLA);
 I2C_Bosta();
 I2C_Durdur();
 Delay_ms(10);
 I2C_LCD_Cmd(_LCD_4BIT_FORMAT);
}
void I2C_LCD_Out(char row, char col, char *text) {
 while(*text)
  I2C_LCD_Chr(row, col++, *text++);
}
void I2C_LCD_Out_Cp(char *text) {
 while(*text)
  I2C_LCD_Chr_Cp(*text++);
}

void setup(){
 ANSELA = 0x00;
 TRISA = 0x00;
 PORTA = 0x00;
 LATA = 0x00;
 INTCON = 0;
 OSCCON = 0B01101000; //4MHz
 I2C_init();
 I2C_LCD_Init(); //Kullan�c� tan�ml� LCD fonksiyonu ile LCD a��l�yor
 I2C_LCD_Cmd(_LCD_AC);
 I2C_LCD_Cmd(_LCD_TEMIZLE);
}

void main()
{
 setup();

   while(1)
   {
      sensor_count = 0;
      sat=0;
      if(DS1820_find_first_device())
      {
         do
         {
        //  t = DS1820_get_temp();
          sat=sensor_count;
      //    BytetoStr(sat,satir);
          I2C_LCD_Out(sensor_count+1, 1, "Tmp ");
          I2C_LCD_Out_Cp(satir);
          I2C_LCD_Out_Cp("/");
          I2C_LCD_Out_Cp("�");
          I2C_LCD_Out_Cp("C");
          I2C_LCD_Out_Cp(":");
      //    FloatToStr(t, sicaklik);
          
          I2C_LCD_Out(sensor_count+1,11,"0");
          sensor_count++;
         }while(DS1820_find_next_device());
         sensor_count = 0;
         sat=0;
      }
   };
}