#define kodlayici_aktif PORTB.RB0 //7447'yi kontrol eden pin
#define buton1 PORTB.RB4 //saat de�erini artt�r�r
#define buton2 PORTB.RB5 //dakikay� artt�r�r
#define A PORTA.RA0
#define B PORTA.RA1
#define C PORTA.RA2
#define D PORTA.RA3
#define dakika1_K PORTA.RA6  //dakikan�n birler hanesini a�an port
#define dakika10_K PORTA.RA7 //dakikan�n onlar hanesini a�an port
#define saat1_K PORTB.RB1    //saatin birler hanesini a�an port
#define saat10_K PORTB.RB2   //saatin onlar hanesini a�an port
unsigned short saniye, dakika, saat, dakika1, dakika10, saat1, saat10;

void ayar(){
  TRISA = 0x10; // PORT A portu ��k�� olarak ayarlan�yor
  TRISB = 0x30; // PORT B portunun RB4-RB5 pinleri giri� yap�l�yor
  PORTA = 0x00; // PORT A'n�n t�m ��k��lar� 0 yap�l�yor
  PORTB = 0x00;
  OPTION_REG  = 0X07;   //�n �l�ekleyici Timer0 i�in 256 olarak ayarlan�yor
  CMCON = 0X07; //Analog giri�ler kapat�l�yor.
  INTCON.GIE = 1; // Evrensel kesme aktif yap�l�yor
  INTCON.PEIE=1;  //�evresel kesme aktif
  INTCON.RBIE = 1; // B4-B7 portlar� kesmesi etkinle�tiriliyor
  PIE1.TMR1IE=1; //Timer1 kesmesi aktif
  T1CON=0X0F; //�n �l�ekleyici 1:1, Harici osilat�r aktif ve
  Delay_us(50);
  TMR1H=0X80;     //Timer1 y�ksek kaydedicisine de�er atand� Prescaler*(65536-32768)*______1______ = 1*1 = 1sn
  TMR1L=0X00;     //                                                                     32768
  saniye, dakika1, dakika10, saat1, saat10 = 0;
}
void main()
{
  ayar();
  while(1){ //sonsuz d�ng�
   kodlayici_aktif = 1;
   PORTA = dakika1;
   dakika1_K = 1; //dakikan�n birler hanesi g�stergesi aktif
   dakika10_K = 0;
   saat1_K = 0;
   saat10_K = 0;
   delay_ms(40); //Tarama i�in gecikme

   PORTA = dakika10;
   dakika1_K = 0;
   dakika10_K = 1; //dakikan�n onlar hanesi g�stergesi aktif
   saat1_K = 0;
   saat10_K = 0;
   delay_ms(40);

   PORTA = saat1;
   dakika1_K = 0;
   dakika10_K = 0;
   saat1_K = 1; //saatin birler hanesi g�stergesi aktif
   saat10_K = 0;
   delay_ms(40);

   PORTA = saat10;
   dakika1_K = 0;
   dakika10_K = 0;
   saat1_K = 0;
   saat10_K = 1; //saatin onlar hanesi g�stergesi aktif
   delay_ms(40);

   if(saniye>59){
    saniye=0;
    dakika++;
    if(dakika>59){
     dakika = 0;
     saat++;
     if(saat>23){
      saat=0;
     }
    }
   }
   dakika1 = dakika%10;  //dakika de�erinin modu al�n�yor
   dakika10 = (dakika/10)%10; //birler ve onlar haneleri elde ediliyor
   saat1 = saat%10; //saat de�erinin modu al�n�yor
   saat10 = (saat/10)%10; //birler ve onlar haneleri elde ediliyor
  }
}
void interrupt()    // TMR0 veya RB4-7 kesmesi sonucu ger�ekle�ecek dallanma rutini
{
 if(INTCON.RBIF){  //RB4-7 kesmesi mi?
  if(!buton1){ //butona bas�ld��� anda saat de�erini artt�r
   if(saat<23) saat++;
   else if(saat==23) saat=0;
  }
  if(!buton2){ //butona bas�ld��� anda dakika de�erini artt�r
   if(dakika<59) dakika++;
   else if(dakika==59) dakika=0;
  }

  INTCON.RBIF=0; //B4-B7 kesme bayra�� temizleniyor
 }

 if(PIR1.TMR1IF){
   saniye++;
   T1CON.TMR1ON=0;
   Delay_us(50);
   TMR1H=0X80;     //Timer1 y�ksek kaydedicisine de�er atand� Prescaler*(65536-32768)*______1______ = 1*1 = 1sn
   TMR1L=0X00;     //                                                                     32768
   T1CON.TMR1ON=1;
   PIR1.TMR1IF=0;
 }
}