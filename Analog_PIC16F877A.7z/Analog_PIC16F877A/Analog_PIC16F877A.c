 // Lcd ayarlar�
sbit LCD_RS at RD2_bit;
sbit LCD_EN at RD3_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D7 at RD7_bit;

// Pin y�nleri
sbit LCD_RS_Direction at TRISD2_bit;
sbit LCD_EN_Direction at TRISD3_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

unsigned int temp_res, desimal, res;
char des_deger[7];
char analog_deger[14];
char analog_yedek[14]="0.           ";
char txt_sub[4] = "0.0";
unsigned char i=0;
float voltaj, doub;
char msg01[] = "Voltaj = ";
char msg02[] = "Dijital=";
char tek[] ="0";
void main() {
  Lcd_Init();                        // LCD'yi haz�rla
  Lcd_Cmd(_LCD_CLEAR);               // Ekran� temizle
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Kurs�r� kapat
  LCD_OUT(1,1,msg01);
  LCD_OUT(2,1,msg02);
  OPTION_REG=0X07;
  ADCON0 = 0b11000000;  // Kanal AN0 analog, di�erleri dijital, FRC clock
  ADCON1 = 0b00001111;  // AN3 +Vref, AN2 -Vref, AN0 ve AN1 analog di�erleri dijital
  CMCON = 0X07;              // Kar��la�t�r�c�lar� kapat;
  TRISA = 0x01;              // A0 giri�
  TRISB = 0;                 // PORTB ��k��
  TRISC = 0;                 // PORTC ��k��
  TRISD = 0;                 // PORTD ��k��
  TRISE = 0;                 // PORTE ��k��
  PORTA = 0, PORTB = 0; PORTC = 0; PORTD = 0; PORTE = 0;
  do {
    temp_res = ADC_Read(0);   // 10-bit'lik sonucu al, ADC d�n���m yap�l�yor
    PORTC = temp_res;         // D���k 8 bit'lik bilgiyi PORTC'ye g�nder
    PORTE = temp_res >> 8;    // 2 MSB bitini RE1 ve RE0'a g�nder
    voltaj= (temp_res*0.00489);
    IntToStr(temp_res, des_deger);
    LCD_OUT(2,9,des_deger);
    FloatToStr(voltaj, analog_deger);
    analog_deger[4]=0;
    if(voltaj>=1){
     LCD_OUT(1,10,analog_deger);
    }
    if(voltaj<1){
     analog_yedek[2]=analog_deger[0];
     analog_yedek[3]=analog_deger[2];
     if(temp_res<31){
      res = strcpy(analog_yedek,txt_sub);
     }
     LCD_OUT(1,10,analog_yedek);
    }
   LCD_OUT(1,14,"V");
  } while(1);
}