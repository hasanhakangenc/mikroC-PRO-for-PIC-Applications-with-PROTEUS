#define LED PORTA.RA0
char buton=0;
void delay100(){
 TMR3H=0XCF;
 TMR3L=0X2C;
 T3CON.TMR3ON=1;
 while(PIR2.TMR3IF==0); //Timer3 ta�mas� olu�ana kadar d�ner
 T3CON.TMR3ON=0;
 PIR2.TMR3IF=0;
}
void delay250(){
 TMR3H=0X85;
 TMR3L=0XEE;
 T3CON.TMR3ON=1;
 while(PIR2.TMR3IF==0); //Timer3 ta�mas� olu�ana kadar d�ner
 T3CON.TMR3ON=0;
 PIR2.TMR3IF=0;
}
void delay500(){
 TMR3H=0X0B;
 TMR3L=0XDC;
 T3CON.TMR3ON=1;
 while(PIR2.TMR3IF==0); //Timer3 ta�mas� olu�ana kadar d�ner
 T3CON.TMR3ON=0;
 PIR2.TMR3IF=0;
}
void ayarlar(){
 PORTB=0;
 CMCON=0X07; //Analog kar��la�t�r�c�lar kapal�
 ADCON0=0; //A/D mod�l� kapal�
 ADCON1=0X0F; //T�m AN kanallar� dijital I/O olarak ayarl�
 TRISB=0B00000111; //3 harici kesme pini de giri�
 TRISA=0;
 PORTA=0;
 TRISC=0;
 PORTC=0;
 INTCON.GIE=1; //Evrensel kesme aktif
 INTCON.INT0E=1; //1.harici kesme aktif
 INTCON2.RBPU=1; //Dahili pull-up'lar kapal�
 INTCON3.INT1E=1; //2. harici kesme aktif
 INTCON3.INT2E=1; //3. harici kesme aktif
 OSCCON=0X62; // 8MHz/2=4MHz dahili osilat�r
}
void timer3_ayar(){
 T3CON.T3CKPS1=1;
 T3CON.T3CKPS0=1; //1:8 prescaler
 T3CON.TMR3CS=0; // FOSC/4 i�lemci saat kayna��
 T3CON.TMR3ON=0; //Timer3 kapal�
}
void main() {
 ayarlar();
 timer3_ayar();
 while(1){
  switch(buton){
   case 1:
    LED=1;
    delay100(); //kullan�c� tan�ml� bekleme s�resi
    buton=0;
    break;
   case 2:
    LED=1;
    delay250();//kullan�c� tan�ml� bekleme s�resi
    buton=0;
   break;
   case 3:
    LED=1;
    delay500();//kullan�c� tan�ml� bekleme s�resi
    buton=0;
   break;
   default: LED=0;
  }
 }
}
void interrupt(){
 if(INT0F_bit){ //0 nolu harici kesme bayra��
  buton=1;
  INT0F_bit=0;
 }
 if(INT1F_bit){ //1 nolu harici kesme bayra��
  buton=2;
  INT1F_bit=0;
 }
 if(INT2F_bit){ //2 nolu harici kesme bayra��
  buton=3;
  INT2F_bit=0;
 }
}
