#include "LCD_ozel.c"

char msg1[] = "I2C LCD 4 Bit";
char msg2[] = "PIC12F1840 4 MHz";
char msg3[] = "MikroC, EasyPIC v7";
char msg4[] = "LCD adresi 0x07";
char msg5[] = "LCD adresi 0x06";

char const msg6[] = "zel Karakter Testi";

char character[] = {0,10,21,17,10,4,0,0};
char buyuk_o[] = {10,0,14,17,17,17,14,0};

void main() {
 ANSELA = 0x00;
 TRISA = 0x00;
 PORTA = 0x00;
 LATA = 0x00;
 OSCCON = 0b01101000;
 I2C_Init();

   I2C_LCD_Init(Waddr1);
   I2C_LCD_Cmd(Waddr1,_LCD_CURSOR_OFF);
   I2C_LCD_Cmd(Waddr1,_LCD_CLEAR);

   I2C_LCD_Init(Waddr2);
   I2C_LCD_Cmd(Waddr2,_LCD_CURSOR_OFF);
   I2C_LCD_Cmd(Waddr2,_LCD_CLEAR);

   I2C_LCD_Out(Waddr1,1,1,msg1);
   I2C_LCD_Out(Waddr1,2,1,msg2);
   I2C_LCD_Out(Waddr1,3,1,msg3);
   I2C_LCD_Out(Waddr1,4,1,msg4);

   I2C_LCD_Out(Waddr2,1,1,msg1);
   I2C_LCD_Out(Waddr2,2,1,msg2);
   I2C_LCD_Out(Waddr2,3,1,msg3);
   I2C_LCD_Out(Waddr2,4,1,msg5);

   delay_ms(5000);

   I2C_LCD_Cmd(Waddr1, _LCD_CLEAR);

   CustomChar(Waddr1,1,1,buyuk_o, 64, 0);
   I2C_LCD_Out(Waddr1,1,2,msg6);
   I2C_LCD_Out(Waddr1,2,1,"Birinci LCD ekran");
   CustomChar(Waddr1,3,10, character, 72, 1);

   I2C_LCD_Cmd(Waddr2, _LCD_CLEAR);

   CustomChar(Waddr2,1,1,buyuk_o, 64, 0);
   I2C_LCD_Out(Waddr2,1,2,msg6);
   I2C_LCD_Out(Waddr2,2,1,"Ikinci LCD ekran");
   CustomChar(Waddr2,4,5, character, 72, 1);

   while(1){
      //TODO: User Code
   }
}