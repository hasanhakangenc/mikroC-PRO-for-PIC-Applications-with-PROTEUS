#include "I2C_ozel.c"
#define _LCD_FIRST_ROW          0x80
#define _LCD_SECOND_ROW         0xC0
#define _LCD_THIRD_ROW          0x94
#define _LCD_FOURTH_ROW         0xD4
#define _LCD_CLEAR              0x01
#define _LCD_RETURN_HOME        0x02
#define _LCD_CURSOR_OFF         0x0C
#define _LCD_UNDERLINE_ON       0x0E
#define _LCD_BLINK_CURSOR_ON    0x0F
#define _LCD_MOVE_CURSOR_LEFT   0x10
#define _LCD_MOVE_CURSOR_RIGHT  0x14
#define _LCD_TURN_ON            0x0C
#define _LCD_TURN_OFF           0x08
#define _LCD_SHIFT_LEFT         0x18
#define _LCD_SHIFT_RIGHT        0x1E
#define EN_DELAY 100
#define  Waddr1 0x4E
#define  Waddr2 0x4C

void I2C_LCD_Cmd(char address, char out_char);
void I2C_LCD_Chr(char address, char row, char column, char out_char);
void I2C_LCD_Chr_Cp(char address, char out_char);
void I2C_LCD_Init(char address);
void I2C_LCD_Out(char address, char row, char col, char *text);
void I2C_LCD_Out_Cp(char address, char *text);
void CustomChar(char address, char pos_row, char pos_char);

/*   LCD_I2C found with PCF8574
 P7,P6,P5,P4 of PCF8574 = DB7,DB6,DB5,DB4 LCD ekran�n MSB bitleridir
 P3 LCD ekran �����n� kontrol eder (ArkaI��k : 1 = a��k / 0 = kapal�)
 P2 LCD E biti saat darbesidir : E = 1'den 0'a ge�i�te LCD'ye veri yaz�l�r
 P1 R/W biti Read/Write: Read = 1 / Write = 0
 P0 RS LCD Register Select biti: CmdReg = 0 / DataReg = 1
*/

void I2C_LCD_Cmd(char address, char out_char) {

    char hi_n, lo_n;
    char rs = 0x00;

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C_Basla();
    I2C_Yaz(address);
    I2C_Yaz(hi_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(hi_n | rs | 0x00 | 0x08);
    delay_us(100);
    I2C_Yaz(lo_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(lo_n | rs | 0x00 | 0x08);
    I2C_Durdur();

    if(out_char == 0x01)Delay_ms(2);
}

void I2C_LCD_Chr(char address, char row, char column, char out_char) {

    char hi_n, lo_n;
    char rs = 0x01;

    switch(row){

        case 1:
        I2C_LCD_Cmd(address, 0x80 + (column - 1));
        break;
        case 2:
        I2C_LCD_Cmd(address, 0xC0 + (column - 1));
        break;
        case 3:
        I2C_LCD_Cmd(address, 0x94 + (column - 1));
        break;
        case 4:
        I2C_LCD_Cmd(address, 0xD4 + (column - 1));
        break;
    };

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C_Basla();
    I2C_Yaz(address);
    I2C_Yaz(hi_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(hi_n | rs | 0x00 | 0x08);
    delay_us(100);
    I2C_Yaz(lo_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(lo_n | rs | 0x00 | 0x08);
    I2C_Durdur();
}

void I2C_LCD_Chr_Cp(char address, char out_char) {

    char hi_n, lo_n;
    char rs = 0x01;

    hi_n = out_char & 0xF0;
    lo_n = (out_char << 4) & 0xF0;

    I2C_Basla();
    I2C_Yaz(address);
    I2C_Yaz(hi_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(hi_n | rs | 0x00 | 0x08);
    delay_us(100);
    I2C_Yaz(lo_n | rs | 0x04 | 0x08);
    delay_us(50);
    I2C_Yaz(lo_n | rs | 0x00 | 0x08);
    I2C_Durdur();
}


void I2C_LCD_Init(char address) {

     char rs = 0x00;

     I2C_Basla();
     I2C_Yaz(address);

     delay_ms(30);

     I2C_Yaz(0x30 | rs | 0x04 | 0x08);
     delay_us(50);
     I2C_Yaz(0x30 | rs | 0x00 | 0x08);

     delay_ms(10);

     I2C_Yaz(0x30 | rs | 0x04 | 0x08);
     delay_us(50);
     I2C_Yaz(0x30 | rs | 0x00 | 0x08);

     delay_ms(10);

     I2C_Yaz(0x30 | rs | 0x04 | 0x08);
     delay_us(50);
     I2C_Yaz(0x30 | rs | 0x00 | 0x08);

     delay_ms(10);

     I2C_Yaz(0x20 | rs | 0x04 | 0x08);
     delay_us(50);
     I2C_Yaz(0x20 | rs | 0x00 | 0x08);
     I2C_Durdur();

     delay_ms(10);

     I2C_LCD_Cmd(address, 0x28);
     I2C_LCD_Cmd(address, 0x06);
}

void I2C_LCD_Out(char address, char row, char col, char *text) {
    while(*text)
         I2C_LCD_Chr(address, row, col++, *text++);
}

void I2C_LCD_Out_Cp(char address, char *text) {
    while(*text)
         I2C_LCD_Chr_Cp(address, *text++);
}

void CustomChar(char address,char pos_row, char pos_col, char gelen[], char karak_adres, char sira) {
  char i;
  I2C_Lcd_Cmd(address, karak_adres);
  for (i = 0; i<=7; i++) I2C_Lcd_Chr_Cp(address, gelen[i]);
  I2C_Lcd_Cmd(address, _LCD_RETURN_HOME);
  delay_ms(2);
  I2C_Lcd_Chr(address, pos_row, pos_col, sira);
}