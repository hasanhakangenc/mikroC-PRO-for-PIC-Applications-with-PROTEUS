//MSSP mod�l� I2C modunda ayarlan�r (PIC12F1840 i�in).
//Kaydedici ayarlar� di�er mikrodenetleyiciler i�in de�i�ebilir.
void I2C_init(void){
 TRISA.F1=1; //SCL saat darbesi pini giri� olarak ayarland�
 TRISA.F2=1; //SDA seri data pini giri� olarak ayarland�
 SSP1CON1 = 0B00101000; //I2C master modunda etkinle�tirildi
 SSP1ADD = 0X09; // h�z = FOSC/(SSP1ADD + 1)*4 = 100kHz
 SSPSTAT = 0B11000000; //d�n�� oran� iptal edildi
}
//I2C transferi bitene kadar bekler
void I2C_Bosta(void){
 while ( ( SSP1CON2 & 0x1F ) || ( SSPSTAT & 0x04 ) );
}
//I2C ileti�imini ba�lat�r
void I2C_Basla(void)
{
 I2C_Bosta();
 SEN_bit=1;
}
//1 baytl�k veri g�nderilir
void I2C_Yaz(char veri)
{
 I2C_Bosta();
 SSPBUF = veri;
}
//I2C haberle�mesini durdurur
void I2C_Durdur(void)
{
 I2C_Bosta();
 PEN_bit=1;
}
// i2c_Restart - I2C haberle�mesini yeniden ba�lat�r
void I2C_Restart(void){
 I2C_Bosta();
 RSEN_bit=1;
}
// i2c_Read - Slave ayg�ttan bir baytl�k bilgi okur
char i2c_Read(char ack)
{
    // Slave ayg�ttan bilgi oku
    // okunacak daha fazla bilginin olmas� durumunda ack 1 olmal�d�r
    // okunan, verinin son byte'� ise ack 0 olmal�d�r
    char i2cReadData;
    I2C_Bosta();
    RCEN_bit=1;
    I2C_Bosta();
    i2cReadData = SSPBUF;
    I2C_Bosta();
    if (ack) ACKDT_bit=0;  // Ack
    else  ACKDT_bit=1;    // NAck
    ACKEN_bit=1;    // onay s�ras�n� g�nder
    return( i2cReadData );
}
// i2c_Address - Slave ayg�t�n adresini ve Read/Write modunu g�nderir
// mod I2C_WRITE ya da I2C_READ olabilir
void i2c_Address(char address, char mode)
{
    char l_address;
    l_address=address<<1;
    l_address+=mode;
    I2C_Bosta();
    SSPBUF = l_address;
}