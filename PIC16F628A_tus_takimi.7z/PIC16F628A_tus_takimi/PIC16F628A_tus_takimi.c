#define LED_kontrol PORTA.RA4
#define sutun1 PORTB.RB1
#define sutun2 PORTB.RB2
#define sutun3 PORTB.RB3
#define satir1 PORTB.RB4
#define satir2 PORTB.RB5
#define satir3 PORTB.RB6
#define satir4 PORTB.RB7

unsigned short  tus,i, tus_id, tus_adres, sayac;
unsigned short sutun[3]={0xFD, 0XFB, 0XF7};
char msj01[]="TUSA BASIN";
char msj02[]="BASILAN TUS";
char sayac_txt[5];

sbit LCD_RS at RA7_bit;
sbit LCD_EN at RA6_bit;
sbit LCD_D4 at RA0_bit;
sbit LCD_D5 at RA1_bit;
sbit LCD_D6 at RA2_bit;
sbit LCD_D7 at RA3_bit;

// Pin direction
sbit LCD_RS_Direction at TRISA7_bit;
sbit LCD_EN_Direction at TRISA6_bit;
sbit LCD_D4_Direction at TRISA0_bit;
sbit LCD_D5_Direction at TRISA1_bit;
sbit LCD_D6_Direction at TRISA2_bit;
sbit LCD_D7_Direction at TRISA3_bit;

void ayarlar(){
     sayac=0;
     Lcd_Init();
     Lcd_Cmd(_LCD_CLEAR);
     Lcd_Cmd(_LCD_CURSOR_OFF);
     INTCON=0;
     CMCON=0X07;
     OPTION_REG=0X07;
     TRISA=0X00;
     PORTA=0;
     TRISB=0XF1;
     PORTB=0;
     for(i=0; i<5; i++){
       LED_kontrol=~LED_kontrol;
       Delay_ms(250);
     }
     LED_kontrol=0;
}
void tus_kontrol(){
      if ((sutun1==0) && (satir1==0)){
      tus_id=1;
      tus_adres=1;
      sayac++;
      }
      if ((sutun2==0) && (satir1==0)){
      tus_id=1;
      tus_adres=2;
      sayac++;
      }
      if ((sutun3==0) && (satir1==0)){
      tus_id=1;
      tus_adres=3;
      sayac++;
      }
      if ((sutun1==0) && (satir2==0)){
      tus_id=1;
      tus_adres=4;
      sayac++;
      }
      if ((sutun2==0)&& (satir2==0)){
      tus_id=1;
      tus_adres=5;
      sayac++;
      }
      if((sutun3==0) && (satir2==0)){
      tus_id=1;
      tus_adres=6;
      sayac++;
      }
      if((sutun1==0) && (satir3==0)){
      tus_id=1;
      tus_adres=7;
      sayac++;
      }
      if((sutun2==0) && (satir3==0)){
      tus_id=1;
      tus_adres=8;
      sayac++;
      }
      if((sutun3==0) && (satir3==0)){
      tus_id=1;
      tus_adres=9;
      sayac++;
      }
      if((sutun1==0) && (satir4==0)){
      tus_id=1;
      tus_adres=10;
      sayac++;
      }
      if((sutun2==0) && (satir4==0)){
      tus_id=1;
      tus_adres=0;
      sayac++;
      }
      if((sutun3==0) && (satir4==0)){
      tus_id=1;
      tus_adres=11;
      sayac++;
      }
}
void keyscan(){
     for(i=0; i<2; i++){
      PORTB=sutun[i];
      tus_kontrol();
      delay_ms(50);
     }
}
void main() {
     ayarlar();
     Lcd_Out(1,1,msj01);
     while(1){
      keyscan();
       if(tus_id==1){
         ShortToStr(sayac,sayac_txt);
         Lcd_Out(2,1,msj02);
         if(tus_adres<10){
          Lcd_Chr(2,14,tus_adres+48);
         }
          else if(tus_adres==10){
           Lcd_Chr(2,14,'*');
          }
         else{
          Lcd_Chr(2,14,'#');
         }
        Lcd_Out(1,11,sayac_txt);
        tus_id=0;
       }
     }
}