﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using easyUSBHidNetClass;

namespace USB_HID
{
    public partial class Form1 : Form
    {
        byte[] DataWrite = new byte[64];      //Buffer USB write 
        byte[] DataRead = new byte[64];       //Buffer USB Read 
        
        public Form1()
        {
            InitializeComponent();
            easyUSBHidNetClass1.SerialNumber = "1234567890";          
            
        }
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            easyUSBHidNetClass1.RegisterHandle(Handle);
        }

        protected override void WndProc(ref Message m)
        {
            easyUSBHidNetClass1.USBHidMensagens(ref m);
            base.WndProc(ref m);
        }

        // This function is responsible for sending USB data
        public void Send_Data(int report_id,byte[] Data)
        {

            try
            {
                if (this.easyUSBHidNetClass1.DeviceUsbHID != null)          //Verify USB conection
                {
                    easyUSBHidNetClass1.DeviceUsbHID.writeData(0,Data);  //reportID and Data -> Send to Microcontroller the USB Writebuffer 
                }
                else
                {
                    MessageBox.Show("Was not possible to send data!");
                }
            }
            catch (Exception w) //error Exception
            {
                MessageBox.Show(w.ToString()); //show error message
            }

        }

        private void easyUSBHidNetClass1_anyDeviceUSB_found(object sender, EventArgs e)
        {
            

        }

        private void easyUSBHidNetClass1_anyDeviceUSB_removed(object sender, EventArgs e)
        {

        }

        private void easyUSBHidNetClass1_DeviceUSB_dataReceived(object sender, easyUSBHidNetClass.DataRecievedEventArgs args)// data received here
        {
            
            

            if (InvokeRequired)
            {
                

                Invoke(new DataRecievedEventHandler(easyUSBHidNetClass1_DeviceUSB_dataReceived), new object[] { sender, args });

            }
            else
            {
                try
                {
                    System.Text.Encoding enc = System.Text.Encoding.ASCII;
                    string[] Result = enc.GetString((byte[])args.data).Split('\0');
                    textbox.Text = Result[0] ;
                }
                catch { }

            }
        }

        private void easyUSBHidNetClass1_DeviceUSB_dataSent(object sender, EventArgs e)// when sending over
        {

        }

        private void easyUSBHidNetClass1_DeviceUSB_found(object sender, EventArgs e)// event when your device found
        {
            label_status.Text = "My Device Found";

        }

        private void easyUSBHidNetClass1_DeviceUSB_removed(object sender, EventArgs e)// event when your device removed
        {
            label_status.Text = "USB Device Removed";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            easyUSBHidNetClass1.DeviceUSB_Config_VID_PID(0x1234, 0x0001);
        }

       

        private void textbox_LCD_TextChanged(object sender, EventArgs e)
        {

            
            if (textbox_LCD.Text != null)
            {
                for (int a = 1; a < textbox_LCD.Text.Length+1; a++)
                {
                    DataWrite[a] = (byte)textbox_LCD.Text[a-1];
                }
                
                DataWrite[textbox_LCD.Text.Length+1]=(byte)'\0';
                    Send_Data(0,DataWrite);
            }
            
            
            
            
        }

        private void textbox_LCD_KeyPress(object sender, KeyPressEventArgs e)
        {
     
        }

        private void textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_LCD_Enter(object sender, EventArgs e)
        {
            for (int a = 0; a < 64; a++)
            {
                //DataWrite[a] = (byte)'0';
            }
            DataWrite[0] = (byte)'0';// lcd use '1' for its identification on MCU side...... other component like pwn must use other to be detect on mcu side
        }

        private void numeric_pwm_ValueChanged(object sender, EventArgs e)
        {
           
            
                for (int a = 1; a < numeric_pwm.Value.ToString().Length+ 1; a++)
                {
                    DataWrite[a] = (byte)numeric_pwm.Value.ToString()[a - 1];
                }

                DataWrite[numeric_pwm.Value.ToString().Length + 1] = (byte)'\0';
                Send_Data(0, DataWrite);
            
        }

        private void numeric_pwm_Enter(object sender, EventArgs e)
        {
            for (int a = 0; a < 64; a++)
            {
                //DataWrite[a] = (byte)'0';
            }
            DataWrite[0] = (byte)'1';
        }

       

        
    }
}
