﻿namespace USB_HID
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.easyUSBHidNetClass1 = new easyUSBHidNetClass.EasyUSBHidNetClass(this.components);
            this.textbox_LCD = new System.Windows.Forms.TextBox();
            this.label_status = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textbox = new System.Windows.Forms.TextBox();
            this.label_result = new System.Windows.Forms.Label();
            this.numeric_pwm = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_pwm)).BeginInit();
            this.SuspendLayout();
            // 
            // easyUSBHidNetClass1
            // 
            this.easyUSBHidNetClass1.DeviceUSB_found += new System.EventHandler(this.easyUSBHidNetClass1_DeviceUSB_found);
            this.easyUSBHidNetClass1.DeviceUSB_removed += new System.EventHandler(this.easyUSBHidNetClass1_DeviceUSB_removed);
            this.easyUSBHidNetClass1.anyDeviceUSB_found += new System.EventHandler(this.easyUSBHidNetClass1_anyDeviceUSB_found);
            this.easyUSBHidNetClass1.anyDeviceUSB_removed += new System.EventHandler(this.easyUSBHidNetClass1_anyDeviceUSB_removed);
            this.easyUSBHidNetClass1.DeviceUSB_dataReceived += new easyUSBHidNetClass.DataRecievedEventHandler(this.easyUSBHidNetClass1_DeviceUSB_dataReceived);
            this.easyUSBHidNetClass1.DeviceUSB_dataSent += new System.EventHandler(this.easyUSBHidNetClass1_DeviceUSB_dataSent);
            // 
            // textbox_LCD
            // 
            this.textbox_LCD.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textbox_LCD.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textbox_LCD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textbox_LCD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textbox_LCD.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_LCD.Location = new System.Drawing.Point(521, 266);
            this.textbox_LCD.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.textbox_LCD.Multiline = true;
            this.textbox_LCD.Name = "textbox_LCD";
            this.textbox_LCD.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textbox_LCD.Size = new System.Drawing.Size(271, 82);
            this.textbox_LCD.TabIndex = 0;
            this.textbox_LCD.WordWrap = false;
            this.textbox_LCD.TextChanged += new System.EventHandler(this.textbox_LCD_TextChanged);
            this.textbox_LCD.Enter += new System.EventHandler(this.textbox_LCD_Enter);
            this.textbox_LCD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textbox_LCD_KeyPress);
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.BackColor = System.Drawing.Color.Transparent;
            this.label_status.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_status.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_status.ForeColor = System.Drawing.Color.Crimson;
            this.label_status.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_status.Location = new System.Drawing.Point(12, 317);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(240, 34);
            this.label_status.TabIndex = 5;
            this.label_status.Text = "Device Not Found";
            this.label_status.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label1.Location = new System.Drawing.Point(596, 351);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "LCD MODULE";
            // 
            // textbox
            // 
            this.textbox.BackColor = System.Drawing.Color.Black;
            this.textbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textbox.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.textbox.Location = new System.Drawing.Point(521, 132);
            this.textbox.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.textbox.Multiline = true;
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(271, 82);
            this.textbox.TabIndex = 0;
            this.textbox.TextChanged += new System.EventHandler(this.textbox_TextChanged);
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.BackColor = System.Drawing.Color.Transparent;
            this.label_result.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_result.ForeColor = System.Drawing.Color.DarkCyan;
            this.label_result.Location = new System.Drawing.Point(582, 217);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(146, 21);
            this.label_result.TabIndex = 4;
            this.label_result.Text = "DATA FROM USB";
            // 
            // numeric_pwm
            // 
            this.numeric_pwm.Location = new System.Drawing.Point(422, 317);
            this.numeric_pwm.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numeric_pwm.Name = "numeric_pwm";
            this.numeric_pwm.Size = new System.Drawing.Size(65, 20);
            this.numeric_pwm.TabIndex = 6;
            this.numeric_pwm.ValueChanged += new System.EventHandler(this.numeric_pwm_ValueChanged);
            this.numeric_pwm.Enter += new System.EventHandler(this.numeric_pwm_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(821, 381);
            this.Controls.Add(this.numeric_pwm);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textbox_LCD);
            this.Controls.Add(this.textbox);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Opacity = 0.98D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB HID";
            this.TransparencyKey = System.Drawing.Color.Teal;
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numeric_pwm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private easyUSBHidNetClass.EasyUSBHidNetClass easyUSBHidNetClass1;
        private System.Windows.Forms.TextBox textbox_LCD;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textbox;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.NumericUpDown numeric_pwm;
    }
}

