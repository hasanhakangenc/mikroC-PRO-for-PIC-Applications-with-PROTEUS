// Lcd pinout settings
sbit LCD_RS at Rd2_bit;
sbit LCD_EN at Rd3_bit;
sbit LCD_D7 at Rd7_bit;
sbit LCD_D6 at Rd6_bit;
sbit LCD_D5 at Rd5_bit;
sbit LCD_D4 at Rd4_bit;
// Pin direction
sbit LCD_RS_Direction at TRISd2_bit;
sbit LCD_EN_Direction at TRISd3_bit;
sbit LCD_D7_Direction at TRISd7_bit;
sbit LCD_D6_Direction at TRISd6_bit;
sbit LCD_D5_Direction at TRISd5_bit;
sbit LCD_D4_Direction at TRISd4_bit;
//---------------------------------------------------------------------------------------------------
unsigned char readbuff[64] absolute 0x500;   // Buffers should be in USB RAM, please consult datasheet
unsigned char writebuff[64] absolute 0x540;
//---------------------------------------------------------------------------------------------------
void interrupt()
{
   USB_Interrupt_Proc();                   // USB servicing is done inside the interrupt
}


void lcd(char d[64])
{
 char l[63];
 int a=0;
 for(a=0;a<63;a++)
 {
  l[a]=d[a+1];
 }
 lcd_cmd(_lcd_clear);
 lcd_out_cp(l);
}
//////////-------------------------------------------------------------------
int strToInt(char *string)
{
 int output = 0, i = 1, stringLength = strlen(string), temp = 0, numberLength = 0,j;
 char tempCh;

 for(j=0;j<stringLength;j++)
 {
  tempCh = string[j];
  temp = tempCh - 48;
  if (temp >= 0 && temp <= 9)
  {
   numberLength++;
  }
 }

 for(j=0;j<stringLength;j++)
 {
  tempCh = string[j];
  temp = tempCh - 48;
  if (temp >= 0 && temp <= 9)
  {
   output += temp * pow(10, (numberLength-i));
   i++;
  }
 }

 return output;
}
 // pwm function////---------------------
void pwm(char d[64])
{
 char l[3];
 int a=0;
 for(a=0;a<3;a++)
 {
  l[a]=d[a+1];
  }
 for(a=0;a<5;a++)
 {
  portc=~portc;
  vdelay_ms(strtoint(l)*10);
 }
  //pwm1_set_duty(l);
//  pwm1_start();
}
 //---------------------------------------------------------------------------------------------------


void main(void)
{
 int a;
 //-----------------------------------------------variable area--------------------------------------
 trisb=0; // port as output
 portb=0xff;
 trisc=0;
 portc=0xff;
 ADCON1 |= 0x0F;                         // Configure all ports with analog function as digital
 CMCON  |= 7;
 lcd_init();
 lcd_cmd(_lcd_cursor_off);
HID_Enable(readbuff,writebuff);      // Enable HID communication
pwm1_init(5000);// start pwn module and  set on 5 KHz

while(1)
 {
  if(!(hid_read()==0))
  {
    /*usb_read_filter(readbuff);*/
    /*lcd_cmd(_lcd_clear);
    lcd_out_cp(readbuff);*/
    if(readbuff[0]=='0')
    {
     lcd(readbuff);
    }
    else if(readbuff[0]=='1')
    {
         pwm(readbuff);
    }

    while(!hid_write(readbuff,64));
  }// if Data read  endz

 }  // while endz
}