#define ILERI PORTB.RB5
#define GERI PORTB.RB6
#define DURDUR PORTB.RB7
unsigned char sayac=0, dur=0, artir=1, azalt=0;
int digit=0;
unsigned int display[10]={95,6,155,143,198,205,221,7,223,207}; /*display g�stergeleri burada tan�mland�*/
void main() {
 TRISB=0xF0;  /*7 segman g�stergenin ba�l� oldu�u pinler ��k�� yap�l�yor */
 PORTB=0;
 TRISA=0X00;
 PORTA=0;
 CMCON =0x07;/* Kar��la�t�r�c� kapat�ld�. Pinler dijitale ayarland�. */
 OPTION_REG = 0B00000111;//Dahili pull-up'lar aktif
 T2CON = 0B01111011;  //Prescaler ve postscaler 1:16
 TMR2 = 0;
 PR2 = 0XFF;
 INTCON.RBIE = 1;
 INTCON.GIE = 1;
 INTCON.PEIE = 1;
 PIE1.TMR2IE = 1;  //Timer2 kesmesi aktif
 T2CON.TMR2ON = 1; //Timer2 sayac� ba�lat�l�yor
 while(1){ /* Sonsuz d�ng� */
  if(dur){
   PORTA=display[digit];/*dijiti display i�ine yazd�k */
   if(digit >= 10)digit = 0; /*dijit de�eri kontrol ediliyor */
   if(digit < 0) digit = 9;
  }
 }
}
void interrupt(){
 if(INTCON.RBIF){ //B portu de�i�im kesmesi
  if(!DURDUR){
   dur = ~dur;
  }
  if(!ILERI){
    artir = 1;
    azalt = 0;
  }
  if(!GERI){
    artir = 0;
    azalt = 1;
  }
  INTCON.RBIF=0;
 }
 if(PIR1.TMR2IF){//Timer2 kesmesi
  if(dur){
   sayac++;
   if(sayac>15){
    if(artir) digit++;
    if(azalt) digit--;
    sayac=0;
   }
  }
  PIR1.TMR2IF = 0;
 }
}