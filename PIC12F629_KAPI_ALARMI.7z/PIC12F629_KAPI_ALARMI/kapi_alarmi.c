unsigned short ikaz_biti=0;
unsigned short saniye, zaman=0;
unsigned short i, yukselen=0;
unsigned short ilk=0;
sbit SES at GP0_bit;
sbit KIRMIZI at GP1_bit;
sbit REED_ROLE at GP2_bit;
sbit BIR at GP4_bit;
sbit IKI at GP5_bit;

void setup(){
  ikaz_biti=0;
  TRISIO = 0x34; //GP2, GP4 ve GP5 giri� di�erleri ��k��
  GPIO = 0X00;   // T�m portlar s�f�rlan�yor
  INTCON.GIE=1;   //Evrensel kesme aktif
  INTCON.INTE=1;  //Harici kesme aktif
  INTCON.T0IE=1; //Timer0 kesmesi aktif
  TMR0=125;      //Timer0 kesmesi ba�lang�� de�eri kuruluyor
  OSCCAL = 0b00110100;
  CMCON=0X07;  //Analog kar��la�t�r�c�lar kapat�ld�
  OPTION_REG = 0b00000111;   // Timer0 kesmesi i�in 1:256 �n�l�ekleyici de�eri atan�yor
  KIRMIZI=0;
  SES=0;
}
void bitti(){
 GPIO = 0X00;
 saniye=0;
 ikaz_biti=0;
}
void bir_dakika(){
  if(saniye<=20){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>20){
    bitti();
  }
}
void iki_dakika(){
  if(saniye<=30){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>30){
    bitti();
  }
}
void uc_dakika(){
  if(saniye<=40){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>40){
    bitti();
  }
}
void bes_dakika(){
  if(saniye<=50){
   SES=~SES;
   KIRMIZI=~KIRMIZI;
   Delay_ms(50);
  }
  if(saniye>50){
    bitti();
  }
}
void main(){
setup();
 while(1){
  if(!ikaz_biti){
   GPIO = 0X00;
    asm{
     sleep
    }
  }
  if(ikaz_biti){
    if(!BIR && !IKI){ //Her iki anahtar da 0 konumunda. S�re 1dk.
     bir_dakika();
    }
    if(!BIR && IKI){ //Anahtarlar 0-1 konumunda. S�re 2dk.
     iki_dakika();
    }
    if(BIR && !IKI){ //Anahtarlar 1-0 konumunda. S�re 3dk.
     uc_dakika();
    }
    if(BIR && IKI){  //Her IKI anahtar da 1 konumunda. S�re 5dk.
     bes_dakika();
    }
   }
 }
}

void interrupt(){
 if(INTCON.INTF){
   zaman=0;
   ikaz_biti=1;
   INTCON.INTF=0;
 }
 if(INTCON.T0IF){
   zaman++;
   if(zaman>32){
    saniye++;
    zaman=0;
   }
   INTCON.T0IF=0;
   TMR0=125;
 }
}