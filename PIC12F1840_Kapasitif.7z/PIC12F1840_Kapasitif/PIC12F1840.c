#define GIRIS PORTA.RA0
#define LAMBA PORTA.RA2

const unsigned int referans=1000;
unsigned int touch, touch_low, touch_high;

void ayar(){
 ANSELA=0x01; //AN0 analog di�erleri dijital I/O
 TRISA = 0X01; // CPS0 pini giri� olarak ayarlan�yor
 CM1CON1 = 0; //Kar��la�t�r�c�lar kapal�
 CPSCON0.CPSRM = 0; //Dahili osilat�r�n voltaj referanslar� kullan�l�yor
 CPSCON0.CPSRNG1 = 1; //Osilat�r y�ksek menzil modunda
 CPSCON0.CPSRNG0 = 1;
 CPSCON0.CPSON = 1; //Kapasitif alg�lama mod�l� a��l�yor
 CPSCON1 = 0; //CPS0 giri� olarak se�iliyor
 T1CON = 0b11000101;//Timer1 kayna�� Capacitive Sensing osilat�r�d�r
 T1GCON.T1GSS1 = 0;
 T1GCON.T1GSS0 = 1; //Timer1 gate kayna�� olarak Timer0 ta�mas� se�ilir
 OSCCON=0B01101000; //4MHZ dahili HFINTOSC
 OPTION_REG = 0B00000111; //Timer0 prescaler 1:256
 PORTA = 0;
 INTCON.GIE=1;
 INTCON.T0IE=1;
 INTCON.PEIE=1;
 TMR0=0;
}
void main() {
  ayar();
  Delay_ms(100);
  LATA=0;
  while(1){
    if(touch<referans){
      LAMBA = 1;
    }
    else{
     LAMBA = 0;
    }
  }
}
void interrupt(){
 if(INTCON.TMR0IF){//Timer0 kesmesi olursa
  touch_low=TMR1L;// Timer1'i oku
  touch_high=TMR1H << 8;
  T1CON.TMR1ON=0; // Timer1'i kapat
  touch = touch_low + touch_high;
  TMR1H=0;// Timer1'i temizle
  TMR1L=0;
  Delay_us(20);
  T1CON.TMR1ON=1;// Timer1'i kur
  INTCON.TMR0IF=0;
  TMR0=0;
 }
}