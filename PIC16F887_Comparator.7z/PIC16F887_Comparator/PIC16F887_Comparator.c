#define BUTON PORTB.RB7
#define MIRRORC1 PORTC.RC0
#define KONTROL PORTD.RD0
#define CIKIS1 PORTD.RD1
#define CIKIS2 PORTD.RD2
#define CIKIS3 PORTD.RD3
#define CIKIS4 PORTD.RD4
unsigned char i, giris=0;
void ayar(){
/* Bu k�s�mda giri�/��k�� durumuna g�re portlar�n ayar� yap�l�r. */
 TRISA.RA0 = 1; //C12IN0- giri� olarak ayarlan�yor
 TRISA.RA1 = 1; //C12IN1- giri� olarak ayarlan�yor
 TRISA.RA3 = 1; //C1 evirmeyen giri�i C1IN+ giri� olarak ayarlan�yor
 TRISA.RA4 = 0;
 TRISB.RB1 = 1; //C12IN3- giri� olarak ayarlan�yor
 TRISB.RB3 = 1; //C12IN2- giri� olarak ayarlan�yor
 TRISB.RB7 = 1; //RB7 buton i�in giri� yap�l�yor
 PORTA = 0;
 PORTB = 0x80; //RB7 ba�lang��ta lojik-1 seviyesine �ekiliyor
 TRISC = 0X00;
 PORTC = 0;
 TRISD = 0X00;
 PORTD = 0;
 TRISE = 0X00;
 PORTE = 0;
 OPTION_REG = 0; // dahili pull-up'lar aktif
 WPUB=0X80; // RB7 pini i�in dahili pull-up etkin
 IOCB=0X80; // RB7 pini i�in port durum de�i�im kesmesi etkin
 /* Bu k�s�mda port giri�lerinin davran��� belirlenir ve
 analog kanal ayarlar� yap�l�r. */
 ANSEL = 0XFF; //T�m AN kanallar� analog olarak ayarland�
 ANSELH = 0XFF; //T�m AN kanallar� analog olarak ayarland�
 INTCON.GIE = 1;
 INTCON.RBIE = 1;
 OSCCON=0X70; /* Osilat�r dahili 8MHz ve OSC pinlerinin davran���
 CONFIG1 konfig�rasyon s�zc���ne g�re ayarlan�yor */
 /* Bu k�s�mda C1 kar��la�t�r�c�s�n�n ayarlar� yap�l�r. */
 CM1CON0.C1ON = 1; //C1 a��l�yor
 CM1CON0.C1OE = 1; //C1 ��k��� RA4/C1OUT pininden al�n�yor
 CM1CON0.C1POL = 0; //��k�� polaritesi terslenmiyor
 CM1CON0.C1R = 0; //C1 evirmeyen giri�i RA3/C1IN+ olarak ayarlan�yor
 CM1CON0.C1CH0 = 0; //
 CM1CON0.C1CH1 = 0; // C1IN- giri�i olarak C12IN0- se�iliyor
 Delay_ms(50);
}
void kontrol(){
 for(i=0;i<10;i++){
  KONTROL = ~KONTROL;
  Delay_ms(50);
 }
 KONTROL=0;
}
void main(){
 ayar();
 kontrol();
 while(1) {
  switch(giris){
   case 0:
    CIKIS4=0;
    CIKIS1=1;
    PORTC.RC0 = CM2CON1.MC1OUT; // C1OUT'un ayna de�eri
    CM1CON0.C1CH0 = 0; //
    CM1CON0.C1CH1 = 0; // C1IN- giri�i olarak C12IN0- se�iliyor
   break;
   case 1:
    CIKIS1=0;
    CIKIS2=1;
    CM1CON0.C1CH0 = 1; //
    CM1CON0.C1CH1 = 0; // C1IN- giri�i olarak C12IN1- se�iliyor
   break;
   case 2:
    CIKIS2=0;
    CIKIS3=1;
    CM1CON0.C1CH0 = 0; //
    CM1CON0.C1CH1 = 1; // C1IN- giri�i olarak C12IN2- se�iliyor
   break;
   case 3:
    CIKIS3=0;
    CIKIS4=1;
    CM1CON0.C1CH0 = 1; //
    CM1CON0.C1CH1 = 1; // C1IN- giri�i olarak C12IN3- se�iliyor
   break;
  }
 }
}
void interrupt(){
 if(INTCON.RBIF){
  if(!BUTON){
   giris++;
   if(giris>3) giris=0;
  }
  INTCON.RBIF=0;
 }
}