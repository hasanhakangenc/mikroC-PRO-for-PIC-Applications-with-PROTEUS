#define kodlayici_aktif PORTB.RB0 //7447'yi kontrol eden pin
#define buton1 PORTB.RB4 //saat ayar�n� yapacak butonlar
#define buton2 PORTB.RB5
#define buton3 PORTB.RB6
#define buton4 PORTB.RB7
#define A PORTA.RA0
#define B PORTA.RA1
#define C PORTA.RA2
#define D PORTA.RA3
#define dakika1_K PORTA.RA6  //dakikan�n birler hanesini a�an port
#define dakika10_K PORTA.RA7 //dakikan�n onlar hanesini a�an port
#define saat1_K PORTB.RB1    //saatin birler hanesini a�an port
#define saat10_K PORTB.RB2   //saatin onlar hanesini a�an port
unsigned short saniye, dakika, saat, dakika1, dakika10, saat1, saat10;

void ayar(){
  TRISA = 0x10; // PORT A portu ��k�� olarak ayarlan�yor
  TRISB = 0xF0; // PORT B portunun RB0-RB3 portlar� ��k��, RB4-RB7 giri� yap�l�yor
  PORTA = 0x00; // PORT A'n�n t�m ��k��lar� 0 yap�l�yor
  PORTB = 0x00;
  OPTION_REG  = 0b00110000;   /*�n �l�ekleyici (prescaler) 2 olarak ayarlan�yor
  Harici saat darbesi i�in T0CKI giri�i aktif */
  CMCON = 0X07; //Analog ��k��lar kapat�l�yor.
  INTCON.GIE = 1; // Evrensel kesme aktif yap�l�yor
  INTCON.INTE = 1;  //Harici kesme
  INTCON.RBIE = 1; // B4-B7 portlar� kesmesi etkinle�tiriliyor
  INTCON.T0IE = 1; // Timer0 kesmesi aktifle�tirildi
  TMR0 = 255; //Timer0 de�eri 255 olarak ayarlan�yor
  saniye, dakika1, dakika10, saat1, saat10 = 0;
}
void main()
{
  ayar();
  while(1){ //sonsuz d�ng�
   kodlayici_aktif = 1;
   PORTA = dakika1;
   dakika1_K = 1; //dakikan�n birler hanesi g�stergesi aktif
   dakika10_K = 0;
   saat1_K = 0;
   saat10_K = 0;
   delay_ms(40); //Tarama i�in gecikme

   PORTA = dakika10;
   dakika1_K = 0;
   dakika10_K = 1; //dakikan�n onlar hanesi g�stergesi aktif
   saat1_K = 0;
   saat10_K = 0;
   delay_ms(40);

   PORTA = saat1;
   dakika1_K = 0;
   dakika10_K = 0;
   saat1_K = 1; //saatin birler hanesi g�stergesi aktif
   saat10_K = 0;
   delay_ms(40);

   PORTA = saat10;
   dakika1_K = 0;
   dakika10_K = 0;
   saat1_K = 0;
   saat10_K = 1; //saatin onlar hanesi g�stergesi aktif
   delay_ms(40);

   if(saniye>59){
    saniye=0;
    dakika++;
    if(dakika>59){
     dakika = 0;
     saat++;
     if(saat>23){
      saat=0;
     }
    }
   }
   dakika1 = dakika%10;  //dakika de�erinin modu al�n�yor
   dakika10 = (dakika/10)%10; //birler ve onlar haneleri elde ediliyor
   saat1 = saat%10; //saat de�erinin modu al�n�yor
   saat10 = (saat/10)%10; //birler ve onlar haneleri elde ediliyor
  }
}
void interrupt()    // TMR0 veya RB4-7 kesmesi sonucu ger�ekle�ecek dallanma rutini
{
 if(INTCON.RBIF){  //RB4-7 kesmesi mi?
  if(!buton1){ //butona bas�ld��� anda dakika de�erini azalt
   if(dakika>0) dakika--;
   else if (dakika==0) dakika=59;
  }
  if(!buton2){ //butona bas�ld��� anda dakika de�erini artt�r
   if(dakika<59) dakika++;
   else if(dakika==59) dakika=0;
  }
  if(!buton3){ //butona bas�ld��� anda saat de�erini azalt
   if(saat>0) saat--;
   else if(saat==0) saat=23;
  }
  if(!buton4){ //butona bas�ld��� anda saat de�erini artt�r
   if(saat<23) saat++;
   else if(saat==23) saat=0;
  }
  INTCON.RBIF=0; //B4-B7 kesme bayra�� temizleniyor
 }
 if(INTCON.T0IF){ //Timer0 kesmesi mi?
  saniye++;
  INTCON.T0IF=0; //TMR0 bayra�� siliniyor ki tekrar kesme ger�ekle�ebilsin
  TMR0=255;     //TMR0 sayac� de�eri tekrar y�kleniyor 0 255 aras�
 }
}