#define MOTOR PORTC.RC2
#define MIRRORC1 PORTD.RD0
#define MIRRORC2 PORTD.RD1
unsigned char i;
void ayar(){
/* Bu k�s�mda giri�/��k�� durumuna g�re portlar�n ayar� yap�l�r. */
 TRISA.RA0 = 1; //C12IN0- giri� olarak ayarlan�yor
 TRISA.RA1 = 1; //C12IN1- giri� olarak ayarlan�yor
 TRISA.RA2 = 1; //C2 evirmeyen giri�i C2IN+ giri� olarak ayarlan�yor
 TRISA.RA3 = 1; //C1 evirmeyen giri�i C1IN+ giri� olarak ayarlan�yor
 TRISA.RA4 = 1; //T0CKI hatt� giri� olarak ayarlan�yor
 PORTA = 0;
 PORTB = 0;
 TRISC = 0;
 PORTC = 0;
 TRISD = 0;
 PORTD = 0;
 TRISE = 0;
 PORTE = 0;
 OPTION_REG.T0CS = 1; // Timer0 Clock-In giri�i aktif, ayr�ca prescaler 1:2
 TMR0 = 255; // (256-251)*2/T0CKI = 10/T0CKI, e�er T0CKI frekans� 1Hz ise
 // Timer0 kesmesinin olu�mas� i�in ge�ecek s�re 10sn olur
 /* Bu k�s�mda port giri�lerinin davran��� belirlenir ve
 analog kanal ayarlar� yap�l�r. */
 ANSEL = 0X0F; //A0-A3 kanallar� analog di�erleri dijital I/O
 ANSELH = 0; //T�m AN kanallar� dijital I/O olarak ayarland�
 INTCON.GIE = 1;
 INTCON.T0IE = 1;
 INTCON.PEIE = 1;
 OSCCON=0X70; /* Osilat�r dahili 8MHz ve OSC pinlerinin davran���
 CONFIG1 konfig�rasyon s�zc���ne g�re ayarlan�yor */
 /* Bu k�s�mda C1 kar��la�t�r�c�s�n�n ayarlar� yap�l�r. */
 CM1CON0.C1ON = 1; //C1 a��l�yor
 CM1CON0.C1OE = 0; //C1OUT dahili
 CM1CON0.C1POL = 1; //��k�� polaritesi tersleniyor
 CM1CON0.C1R = 0; //C1 evirmeyen giri�i RA3/C1IN+ olarak ayarlan�yor
 CM1CON0.C1CH0 = 0; //
 CM1CON0.C1CH1 = 0; // C1IN- giri�i olarak C12IN0- se�iliyor

 CM2CON0.C2ON = 1; //C2 a��l�yor
 CM2CON0.C2OE = 0; //C2OUT dahili
 CM2CON0.C1POL = 1; //��k�� polaritesi tersleniyor
 CM2CON0.C1R = 0; //C2 evirmeyen giri�i RA2/C2IN+ olarak ayarlan�yor
 CM2CON0.C1CH0 = 1; //
 CM2CON0.C1CH1 = 0; // C2IN- giri�i olarak C12IN1- se�iliyor
                 //yapay gecikme yap�l�yor
}
void main(){
 ayar();
 while(1) {

 }
}
void interrupt(){
 if(INTCON.T0IF){
   MIRRORC1=CM2CON1.MC1OUT;
   MIRRORC2=CM2CON1.MC2OUT;
   if(MIRRORC1 && MIRRORC2){
     MOTOR=1;
   }
  if(!MIRRORC1 || !MIRRORC2){
     MOTOR=0;
   }
 }
 INTCON.T0IF=0;
 TMR0=255;
}