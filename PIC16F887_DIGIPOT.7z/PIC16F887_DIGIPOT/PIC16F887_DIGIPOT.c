// LCD ba�lant�lar� tan�mlan�yor
sbit LCD_RS at RB0_bit;
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;
sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;

sbit Up at RD0_bit;//Kanal de�eri art�rma
sbit Down at RD1_bit;//Kanal de�eri azaltma
sbit kanal at RB2_bit; //Kanal se�me
//sbit kanal at RD3_bit;

sbit DigPot_CS at RD2_bit;//SPI dijital pot ayg�t�n� se�en hat
sbit DigPot_CS_Direction at TRISD2_bit;

unsigned int adc_value;
char counter0, counter1, counter2, counter3, counter4, counter5, sayac;
char pot_adres=0;
bit kontrol;

char message1[] = "Analog";
char message2[] = "W";
char *kanal_no="0";
char *ADC = "0000";

void InitMain() {
  //Kaydediciler yap�land�r�l�yor
  ANSEL = 0b00111111;  // RA0-5 analog giri�
  TRISA = 0b00101111; // RA0 giri�
  ANSELH = 0x00;       // T�m B portu dijital
  TRISB  = 0x04;
  TRISC = 0X10;
  TRISD = 0X0B;  //RD0 ve RD1 giri�
  TRISE = 0x01;
  OSCCON = 0X70;
  CM1CON0 = 0;
  INTCON.GIE = 1;
  INTCON.RBIE = 1;
  IOCB =  0X04;
  //Di�er mod�ller yap�land�r�l�yor
  ADC_Init(); // ADC k�t�phanesi komutuyla ADC a��l�yor
  SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_END, _SPI_CLK_IDLE_HIGH, _SPI_LOW_2_HIGH);
  Lcd_Init();        //LCD k�t�phanesiyle LCD yap�land�r�l�yor

  DigPot_CS = 1;
  DigPot_CS_Direction = 0;
  adc_value = 0;
  counter0 = 255;
  counter1 = 255;
  counter2 = 255;
  counter3 = 255;
  counter4 = 255;
  counter5 = 255;

  Lcd_Cmd(_LCD_CLEAR);          // CLEAR display
  Lcd_Cmd(_LCD_CURSOR_OFF);     // Cursor off
  Lcd_Out(1,1,message1);        // Write message1 in 1st row
  Lcd_Out(2,1,message2);        // Write message2 in 2nd row
}

void Debounce_Key(){
 Delay_ms(100);
}

void ADC_Display(char ch){
 unsigned int adc_value;
 adc_value = ADC_Read(ch);
 ADC[0] = adc_value/1000 + 48;
 ADC[1] = (adc_value/100)%10 + 48;
 ADC[2] = (adc_value/10)%10 + 48;
 ADC[3] = adc_value%10 + 48;
 kanal_no[0] = ch%10 + 48;
 LCD_Out(1, 7, kanal_no);
 LCD_Out_Cp(" = ");
 LCD_Out(1,11, ADC);
 kanal_no[0] = ch%10 + 49;
 LCD_Out(2,2, kanal_no);
}

void kanal_oku(char pot_adres_g, char sayac_g){
 DigPot_CS = 0;
 SPI1_Write(pot_adres_g);
 SPI1_Write(sayac_g);
 ADC_Display(pot_adres_g);
 DigPot_CS = 1;
}

void main() {
 InitMain();          // Ana yap�land�rma rutini �a�r�l�yor
 do{ /*
  if(!kanal){
   kontrol=~kontrol;
   if(kontrol) pot_adres++;
   Debounce_Key();
   if(pot_adres>5) pot_adres=0;
  } */
  switch(pot_adres){
   case 0:
    sayac=counter0;
   break;
   case 1:
    sayac=counter1;
   break;
   case 2:
    sayac=counter2;
   break;
   case 3:
    sayac=counter3;
   break;
   case 4:
    sayac=counter4;
   break;
   case 5:
    sayac=counter5;
   break;
  }
  kanal_oku(pot_adres, sayac);
  if(!Up){
   switch (pot_adres){
    case 0:
     counter0++;
     Debounce_Key();
    break;
    case 1:
     counter1++;
     Debounce_Key();
    break;
    case 2:
     counter2++;
     Debounce_Key();
    break;
    case 3:
     counter3++;
     Debounce_Key();
    break;
    case 4:
     counter4++;
     Debounce_Key();
    break;
    case 5:
     counter5++;
     Debounce_Key();
    break;
   }
  }
  if(!Down){
   switch (pot_adres){
    case 0:
     counter0--;
     Debounce_Key();
    break;
    case 1:
     counter1--;
     Debounce_Key();
    break;
    case 2:
     counter2--;
     Debounce_Key();
    break;
    case 3:
     counter3--;
     Debounce_Key();
    break;
    case 4:
     counter4--;
     Debounce_Key();
    break;
    case 5:
     counter5--;
     Debounce_Key();
    break;
   }
  }
 }while (1);
}
void interrupt(){
 if(INTCON.RBIF){
  if(!kanal){
   pot_adres++;
   if(pot_adres>5) pot_adres=0;
  }
  INTCON.RBIF=0;
 }
}