// LCD mod�l baglantilari
sbit LCD_RS at RB4_bit;
sbit LCD_EN at RB5_bit;
sbit LCD_D4 at RB0_bit;
sbit LCD_D5 at RB1_bit;
sbit LCD_D6 at RB2_bit;
sbit LCD_D7 at RB3_bit;
sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// LCD mod�l baglantilari sonu
// Manchester mod�l baglantilari
sbit MANRXPIN at RC0_bit;
sbit MANRXPIN_Direction at TRISC0_bit;
sbit MANTXPIN at RC1_bit;
sbit MANTXPIN_Direction at TRISC1_bit;
// Manchester mod�l baglantilari sonu
char error, ErrorCount, temp;
void main() {  ErrorCount = 0;
  ANSEL  = 0;
  ANSELH = 0;
  C1ON_bit = 0;
  C2ON_bit = 0;
  OSCCON = 0X72;
  TRISC.F5 = 0;
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Man_Receive_Init();                             // Alici baslatilir
  while (1) {
      Lcd_Cmd(_LCD_FIRST_ROW);

      while (1) {                              // Baslama bayti i�in beklenilir
        temp = Man_Receive(&error);            // Bayte alimina �alisilir
        if (temp == 0x0B)      // Verici kodunda karsilik gelen baslama bayti
          break;               // Baslama kodu yakalandiysa if yapisindan �ik
        if (error)             // Hata da varsa if yapisindan �ik
          break;       
      }
      do {
          temp = Man_Receive(&error);             // Bayt alimina calisilir
          if (error) {                            // Hata olduysa
            Lcd_Chr_CP('?');     // LCD ekan �zerine soru isareti yaz
            ErrorCount++;                         // Hata sayicisini g�nceller
            if (ErrorCount > 20) {                // �ok fazla hata olduysa
              temp = Man_Synchro();               // Tekrar senkronizasyon dene
              //Man_Receive_Init() //Alternatif olarak aliciyi tekrar baslatmayi
              ErrorCount = 0;      // deneyebilirsiniz. Hata sayicisi sifirlanir
              }            }
          else {                    // Hata yoksa
            if (temp != 0x0E)       // vericide tanimlanan bitis kodu g�r�lene
              Lcd_Chr_CP(temp);     // kadar alinan karakterler LCD'ye yazilir
              } 
              Delay_ms(25);
            }
      while (temp != 0x0E) ;// Eger bitis koduna ulasildiysa d�ng�den �ikilir
   }
}