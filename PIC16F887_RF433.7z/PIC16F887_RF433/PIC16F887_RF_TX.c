sbit MANRXPIN at RC0_bit;
sbit MANRXPIN_Direction at TRISC0_bit;
sbit MANTXPIN at RC1_bit;
sbit MANTXPIN_Direction at TRISC1_bit;

char index, character;
char s1[] = "mikroElektronika";

void main() {
  ANSEL  = 0;
  ANSELH = 0;
  C1ON_bit = 0;
  C2ON_bit = 0;
  OSCCON = 0X72;
  Man_Send_Init();                 // Verici baslatilir

  while (1) {
    Man_Send(0x0B);    // Aliciyla eslesme i�in bir baslama kodu belirlenir
    Delay_ms(100);                 // Bi s�religine beklenilir

    character = s1[0];             // Stringten ilk karakter alinir
    index = 0;                     // Indeks degiskeni kurulur
    while (character) { // String dizisinin sonundaki sifira ulasilana kadar
      Man_Send(character);         // karakter dizisini g�nder
      Delay_ms(90);
      index++;                     // indeks degiskeni arttirilir
      character = s1[index];       // sonraki karakter alinir
      }
    Man_Send(0x0E); // G�nderimin bittigini belirten koda karar verilir
    Delay_ms(1000);
  }
}