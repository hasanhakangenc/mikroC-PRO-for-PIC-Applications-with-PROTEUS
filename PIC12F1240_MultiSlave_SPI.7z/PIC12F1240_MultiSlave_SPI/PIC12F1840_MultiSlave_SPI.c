// Mikroc codes for SPI master device
#define chip_select PORTA.RA4

// Port GEN��LET�C� mod�l ba�lant�lar�
sbit  SPExpanderRST at RA4_bit;
sbit  SPExpanderCS  at RA5_bit;
sbit  SPExpanderCS_Direction  at TRISA5_bit;
sbit  SPExpanderRST_Direction at TRISA4_bit;


unsigned short tx_data=0, rx_data=0;
char msg1[] = "I2C LCD 4 Bit";
char rx_data_txt[4];

void SPI_MASTER_INIT(void){
 TRISA = 0b00001100;
 SSP1STAT.SMP=0;
 SSP1STAT.CKE=0;
 SSP1CON1.SSPEN=1;
 SSP1CON1.CKP=1;
 SSP1CON1.WCOL=0;
 SSP1CON1.SSPM3=0;
 SSP1CON1.SSPM2=0;
 SSP1CON1.SSPM1=0;
 SSP1CON1.SSPM0=0;
 PCON=0;
}
void main(){
 ANSELA = 0x00;
 INTCON.GIE = 1;
 PORTA = 0x00;
 LATA = 0x00;
 OSCCON = 0b01101000;
 CM1CON0=0;
 ADCON0=0;
 chip_select=1;
 SPI_MASTER_INIT(); //  Spi1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_END, _SPI_CLK_Idle_HIGH, _SPI_LOW_2_HIGH);
  while(1){
   tx_data++;
   chip_select=0;
   SSP1CON1.WCOL=0;
   SSP1STAT.BF=0;
   SSP1BUF=tx_data;
   SSP1BUF=0;//D��ardan gelen bilgi i�in tampon temizleniyor
   while(!SSP1IF_bit);
   SSP1IF_bit=0;
   SSP1CON1.WCOL=0;
   SSP1STAT.BF=0;
   rx_data = SSP1BUF;
   BytetoStr(rx_data, rx_data_txt);
   SPI_Lcd_Config(0);
   SPI_Lcd_Cmd(_LCD_CLEAR);
   SPI_Lcd_Cmd(_LCD_CURSOR_OFF);
   SPI_Lcd_Out(1,1, "SAYI= ");
   SPI_Lcd_Out(1,7, rx_data_txt);
   delay_ms(250);
   if(tx_data>=255) tx_data=0;
  }
}