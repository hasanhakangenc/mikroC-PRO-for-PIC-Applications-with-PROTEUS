#define chip_select PORTA.RA3
unsigned int buffer, toplam;
unsigned short rx_data=0, tx_data=0;
void SPI_SLAVE_INIT(void){
 TRISA=0b00001110;
 SSP1STAT.SMP=0;
 SSP1STAT.CKE=0;
 SSP1CON1.SSPEN=1;
 SSP1CON1.CKP=1;
 SSP1CON1.SSPM3=0;
 SSP1CON1.SSPM2=1;
 SSP1CON1.SSPM1=0;
 SSP1CON1.SSPM0=0;
 SSP1CON3.BOEN=1; //Daisy-Chain uygulamas�
}
void main()
{
 ANSELA = 0x00;
 INTCON.GIE = 1;
 PORTA = 0x00;
 LATA = 0x00;
 OSCCON = 0b01101000;
 SPI_SLAVE_INIT();//Spi_Init_Advanced(SLAVE_SS_ENABLE,DATA_SAMPLE_END,CLK_Idle_HIGH,LOW_2_HIGH);
 while(1){
  while(!SSP1IF_bit);
  SSP1IF_bit=0;
  rx_data=SSP1BUF;
  if(rx_data%10 == 0){
   PORTA.F4=1;
   PORTA.F5=0;
  }
  else if(rx_data%2 == 0){
   PORTA.F4=0;
   PORTA.F5=1;
  }
  else{
   SSP1BUF = rx_data;
   PORTA.F4=0;
   PORTA.F5=0;
  }
 }
}