/*
char uart_rd;void main() {
  TRISD = 0;
  PORTD = 0;
  ANSEL  = 0;                     // Configure AN pins as digital  ANSELH = 0;
  UART1_Init(9600);               // Initialize UART module at 9600 bps
  Delay_ms(100);                  // Wait for UART module to stabilize
  UART1_Write_Text("MERHABA ");
  UART1_Write(10);
  UART1_Write(13);
  while (1) {                     // Endless loop
    if (UART1_Data_Ready()) {     // If data is received,
      uart_rd = UART1_Read();     // read the received data,
      PORTD = uart_rd;
      UART1_Write(uart_rd);       // and send data via UART
      UART1_Write(10);
      UART1_Write(13);
    }
  }
} */

char veri = 0;
char kontrol = 0;
//Fonksiyon deklerasyonlari
void UART_RXTX_Init(void);
void port_Init(void);

//Ana fonksiyon
void main(void) {
 port_Init();
 UART_RXTX_Init();
  while(1) {
   while(!TRMT);
   if(kontrol){
     TXREG = veri;
     kontrol = 0;
   }
  }
}
//UART alici-verici olarak ayarlaniyor
void UART_RXTX_Init(void){
 BAUDCTL = 0;
 TXSTA.BRGH = 1;
 SPBRG = 51;
 TXSTA.SYNC = 0;
 RCSTA.SPEN = 1;
 TXSTA.TXEN = 1;
 RCSTA.CREN = 1;
}

//Portlar ve kesmeler ayarlaniyor
void port_Init(void){
 OSCCON = 0X72;
 INTCON.GIE = 1;
 INTCON.PEIE = 1;
 //PIE1.TXIE = 1;
 PIE1.RCIE = 1;
 ANSEL = 0; //t�m portlar dijital I/O
 ANSELH = 0;
 CM1CON0 = 0;  //karsilastiricilar kapali
 CM2CON0 = 0;
 TRISA = 0;
 PORTA = 0;
 TRISB = 0;
 PORTB = 0;
 TRISC = 0XC0;
 PORTC = 0;
 TRISD = 0;
 PORTD = 0;
 TRISE = 0;
 PORTE = 0;
}
//Alma islemi kesme ile kontrol ediliyor
void interrupt(void){
 if(PIR1.RCIF){
  veri = RCREG;
  PORTD = veri;
  kontrol = 1;
 }
}