// ------------------------------------------------------
// GLCD Picture name: mikro.bmp
// GLCD Model: T6963C 128x128
// ------------------------------------------------------

const code char mikro[528] = {
  0,   6, 255, 255, 255, 255, 255, 255, 176,   0,   0,
  0,   6, 255, 255, 255, 255, 255, 255, 176,   0,   0,
  0,   6, 248,  15, 255, 128,  63, 255, 176,   0,   0,
  0,   6, 224,   3, 252,   0,   7, 255, 176,   0,   0,
  0,   6, 224,   1, 240,   0,   1, 255, 176,   0,   0,
  0,   6, 231, 249, 224,   0,   0, 127, 176,   0,   0,
  0,   6, 239, 249, 128,   0,   0,  63, 176,   0,   0,
  0,   6, 224,   3, 128,   0,   0,  63, 176,   0,   0,
  0,   6, 224,   3,   0,   0,   0,  31, 176,   0,   0,
  0,   6, 240,   7,   0,  14,   0,  15, 176,   0,   0,
  0,   6, 255, 254,   0,  15,   0,  15, 176,   0,   0,
  0,   6, 255, 254,   0,  31,   0,  15, 176,   0,   0,
  0,   6, 227, 254,   0,  31,   0,   7, 176,   0,   0,
  0,   6, 225, 254,   0,  31,   0,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  31,   0,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  31,   0,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  31,   0,   7, 176,   0,   0,
  0,   6, 255, 254,   0,  15,   0,   7, 176,   0,   0,
  0,   6, 239, 238,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 225, 142,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 225,  14,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 248,  30,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 232,  14,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 224,  14,   0,   0,   0,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  15, 255, 255, 176,   0,   0,
  0,   6, 239, 254,   0,  31, 255, 255, 176,   0,   0,
  0,   6, 255, 254,   0,  31, 255, 255, 176,   0,   0,
  0,   6, 236,  14,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 236,  14,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 232,  14,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 255, 254,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 255, 254,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 224,  14,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 224,   6,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 239, 254,   0,  31, 128,   7, 176,   0,   0,
  0,   6, 255, 254,   0,  15,   0,  15, 176,   0,   0,
  0,   6, 224,   7,   0,  15,   0,  15, 176,   0,   0,
  0,   6, 224,   3,   0,   4,   0,  15, 176,   0,   0,
  0,   6, 224,   3, 128,   0,   0,  31, 176,   0,   0,
  0,   6, 239, 255, 128,   0,   0,  63, 176,   0,   0,
  0,   6, 239, 255, 192,   0,   0, 127, 176,   0,   0,
  0,   6, 224,   0, 224,   0,   0, 255, 176,   0,   0,
  0,   6, 224,   0, 120,   0,   1, 255, 176,   0,   0,
  0,   6, 224,   0,  62,   0,   7, 255, 176,   0,   0,
  0,   6, 255, 255, 255, 255, 255, 255, 176,   0,   0,
  0,   6, 255, 255, 255, 255, 255, 255, 176,   0,   0,
  0,   6, 255, 255, 255, 255, 255, 255, 112,   0,   0
};


sbit  SPExpanderRST at RC0_bit;sbit  SPExpanderCS  at RC1_bit;
sbit  SPExpanderRST_Direction at TRISC0_bit;
sbit  SPExpanderCS_Direction  at TRISC1_bit;
// End Port Expander module connections
void Delay2s(){                         // 2 seconds delay function
  Delay_ms(2000);
}
  
void main() {
  char counter;  char *someText;
  #define COMPLETE_EXAMPLE
  ADCON0  = 0;                             // Configure AN pins as digital
  CMCON = 0X07;
  SPI1_Init();                                      // Initialize SPI module used with PortExpander
//  // If Port Expander Library uses SPI2 module
//  SPI2_Init();                                   // Initialize SPI module used with PortExpander
  SPI_Glcd_Init(0);                                // Initialize Glcd via SPI
  SPI_Glcd_Fill(0x00);                             // Clear Glcd  while(1) {
    #ifdef COMPLETE_EXAMPLE
      SPI_Glcd_Image(mikro);                // Draw image
      Delay2s(); Delay2s();
    #endif
    SPI_Glcd_Fill(0x00);                           // Clear Glcd    Delay2s;
    SPI_Glcd_Box(62,40,124,56,1);                  // Draw box
    SPI_Glcd_Rectangle(5,5,84,35,1);               // Draw rectangle
    SPI_Glcd_Line(0, 63, 127, 0,1);                // Draw line    Delay2s();
    for(counter = 5; counter < 60; counter+=5 ) {  // Draw horizontal and vertical line
      Delay_ms(250);      SPI_Glcd_V_Line(2, 54, counter, 1);
      SPI_Glcd_H_Line(2, 120, counter, 1);      }    Delay2s();
    #ifdef COMPLETE_EXAMPLE
      SPI_Glcd_Fill(0x00);                                   // Clear Glcd
      SPI_Glcd_Set_Font(Font_Glcd_Character8x7, 8, 8, 32);   // Choose font, see __Lib_GLCDFonts.c in Uses folder
      SPI_Glcd_Write_Text("mikroE", 5, 7, 2);                // Write string
    #endif
    for (counter = 1; counter <= 10; counter++)              // Draw circles
      SPI_Glcd_Circle(63,32, 3*counter, 1);    Delay2s();
   #ifdef COMPLETE_EXAMPLE
      SPI_Glcd_Box(12,20, 70,63, 2);                         // Draw box
      Delay2s();
      SPI_Glcd_Fill(0xFF);                                   // Fill Glcd
      SPI_Glcd_Set_Font(Font_Glcd_Character8x7, 8, 7, 32);   // Change font
      someText = "8x7 Font";
      SPI_Glcd_Write_Text(someText, 5, 1, 2);                // Write string
      Delay2s();
      SPI_Glcd_Set_Font(Font_Glcd_System3x5, 3, 5, 32);      // Change font
      someText = "3X5 CAPITALS ONLY";
      SPI_Glcd_Write_Text(someText, 5, 3, 2);                // Write string
      Delay2s();
      SPI_Glcd_Set_Font(Font_Glcd_System5x7, 5, 7, 32);      // Change font
      someText = "5x7 Font";
      SPI_Glcd_Write_Text(someText, 5, 5, 2);                // Write string
      Delay2s();
      SPI_Glcd_Set_Font(Font_Glcd_5x7, 5, 7, 32);            // Change font
      someText = "5x7 Font (v2)";
      SPI_Glcd_Write_Text(someText, 5, 7, 2);                // Write string
      Delay2s();
     #endif
  }