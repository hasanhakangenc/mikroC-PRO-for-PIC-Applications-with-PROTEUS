#include <PID motor.h>
#fuses HSPLL,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN
#use delay(clock=48000000)
#include <usb_cdc.h>
#include <usb_desc_cdc.h>

#byte PORTA = 0xF80
#byte PORTB = 0xF81
#byte PORTC = 0xF82
#byte PORTE = 0xF84
#define ledMavi PIN_B2
#define ledKirmizi PIN_B1
#define on     output_high
#define off    output_low

int okuma;
int16 duty_max = 0xAFC8; // 70% del Duty
int duty_min = 0; // 10% del Duty
int duty = 0;

void main()
{

   output_B(0x00);
   setup_timer_1(T1_EXTERNAL| T1_DIV_BY_1);
   setup_ccp1(CCP_PWM);
   setup_timer_2(T2_DIV_BY_16, 0xFFFF,1);
   set_pwm1_duty(duty);
   usb_cdc_init();
   usb_init();
   while (!usb_cdc_connected()) {
   }
   usb_task();
   
   while (true)
   {
     off(ledKirmizi);
     off(ledMavi);
     if(usb_enumerated())         
      {
         set_timer1(0);
         delay_ms(250);
         okuma=get_timer1();
         if(okuma>0){
          output_toggle(ledMavi);
          usb_cdc_putc(okuma);
          delay_ms(20);
         }
         if (usb_cdc_kbhit())          
         {            
            
            duty = usb_cdc_getc();
            if(duty > duty_max)
            {
               duty=duty_max;
            }
            else if(duty < duty_min)
            {
               duty=duty_min;
            }
            set_pwm1_duty(duty);
            on(ledKirmizi);
            delay_ms(20);
         }
      }
   }   
}

