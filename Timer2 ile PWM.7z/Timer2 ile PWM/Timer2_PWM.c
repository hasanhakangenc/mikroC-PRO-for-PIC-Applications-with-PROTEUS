unsigned short current_duty, baslat, saniye;
unsigned int sayac;
void main(){
     CMCON = 0X07;  //Kar��la�t�r�c�lar kapat�l�yor.
     OPTION_REG = 0B00000000;//�n �l�ekleyici 1:1
     TRISA = 0;
     TRISB = 0X01;
     PORTA = 0;
     PORTB = 0;
     PR2 = 249;
     CCPR1L = 0;
     T2CON = 0B00000001; //Postscaler 1:1, prescaler 1:4, Timer2 off
     CCP1CON = 0; //PWM modu
     INTCON.GIE=1;
     INTCON.INTE=1;
     TMR0=156;
     Delay_ms(10);
     TMR2=0;
     T2CON.TMR2ON = 1;
     CCP1CON = 0B00001100;
     while(1){
        do{
         current_duty++;
         CCPR1L = current_duty;
         delay_ms(50);
        }while(current_duty<255 && baslat);
        do{
         current_duty--;
         CCPR1L = current_duty;
         delay_ms(50);
        }while(current_duty>0 && !baslat);
     }
}
void interrupt(){
 if(INTCON.INTF){
   baslat = ~baslat;
   INTCON.INTF=0;
 }
}