#define LED_TMR1 PORTA.RA0
#define LED_TMR3 PORTA.RA1
#define T1CKI PORTC.RC0
char kesmeTMR1=0, kesmeTMR3=0;
unsigned int zaman1, zaman2;
void ayarlar(){
 PORTB=0;
 CMCON=0X07; // Analog kar��la�t�r�c�lar kapal�
 ADCON0=0; // A/D mod�l� kapal�
 ADCON1=0X0F; // T�m AN kanallar� dijital I/O olarak ayarl�
 OSCCON = 0X72;
 TRISB=0;
 TRISA=0;
 PORTA=0;
 TRISC=0x01;
 PORTC=0;
 INTCON.GIE=1; // Evrensel kesme aktif
 INTCON.PEIE=1; // �evresel ayg�t kesmesi aktif
 INTCON.T0IE = 1; // Timer0 kesmesi aktif
 T0CON=0B00000110; //Timer0 prescaler 1:128
 T0CON.TMR0ON=1;
 TMR0L=0xF7;
 TMR0H=0xC2; //49911 de�eri y�kleniyor
 PIE1.TMR1IE=1; // Timer1 kesmesi aktif
 PIE2.TMR3IE=1; // Timer3 kesmesi aktif
 OSCCON=0X71; // 8MHz dahili osilat�r-�kincil osilat�r Timer1, uyku modu i�in
}
void timer1_ayar(){
 T1CON.T1CKPS1=1;
 T1CON.T1CKPS0=1; // Timer1 prescaler 1:8
 T1CON.T1OSCEN=0;
 T1CON.TMR1CS=1;
 T1CON.T1SYNC=1;
 TMR1H=0XFF;
 TMR1L=0XFE;
 Delay_ms(50);
 T1CON.TMR1ON=1;
}
void timer3_ayar(){
 T3CON.T3CKPS1=0;
 T3CON.T3CKPS0=0; // Timer3 prescaler 1:1
 T3CON.TMR3CS=1; // T1CKI giri�i saat darbesi kayna��
 T3CON.T3SYNC=1;
 TMR3H=0XFF;
 TMR3L=0XFE; // 65534 de�eri ba�lang�� olarak y�kleniyor
 Delay_ms(50);
 T3CON.TMR3ON=1;
}
void main() {
 ayarlar();
 timer1_ayar();
 timer3_ayar();
 while(1){
   if(!kesmeTMR1 && !kesmeTMR3){
  /*   asm{
      sleep
     }   */
   }
   if(kesmeTMR1){
    if(zaman1>2){
     LED_TMR1=0;
     kesmeTMR1=0;
     zaman1=0;
    }
   }
   if(kesmeTMR3){
    if(zaman2>2){
     LED_TMR3=0;
     kesmeTMR3=0;
     zaman2=0;
    }
   }
 }
}

void Kesme_yordami() iv 0x000008{
 if(INTCON.T0IF){ //Timer0 kesmesi mi?
  if(LED_TMR1){
   zaman1++;
  }
  if(LED_TMR3){
   zaman2++;
  }
  INTCON.T0IF=0; //TMR0 bayra�� siliniyor ki tekrar kesme ger�ekle�ebilsin
  TMR0L=0xF7;
  TMR0H=0xC2; //49911 de�eri y�kleniyor
 }
 if(PIR1.TMR1IF){ //Timer1 kesmesi mi?
   LED_TMR1=1;
   kesmeTMR1=1;
   T1CON.TMR1ON=0;
   Delay_us(50);
   TMR1H=0XFF;
   TMR1L=0XFF;
   T1CON.TMR1ON=1;
   PIR1.TMR1IF=0;
 }
 if(PIR2.TMR3IF){ //Timer3 kesmesi mi?
  LED_TMR3=1;
  kesmeTMR3=1;
  T3CON.TMR3ON=0;
  Delay_us(50);
  TMR3H=0XFF;
  TMR3L=0XFF;
  T3CON.TMR3ON=1;
  PIR2.TMR3IF=0;
 }
}