char kesmeTMR10;
unsigned int saniye, dakika, saat;
void ayarlar2(){
 CMCON=0X07; // Analog kar��la�t�r�c�lar kapal�
 ADCON0=0; // A/D mod�l� kapal�
 ADCON1=0X0F; // T�m AN kanallar� dijital I/O olarak ayarl�
 OSCCON = 0X72;
 TRISA=0;
 TRISB=0;
 TRISC=0;
 PORTA=0;
 PORTB=0;
 PORTC=0;
 TMR1H=0X80; // TMR1 kaydedicisi 32768 ile y�kleniyor
 TMR1L=0X00;
 INTCON.GIE=1; // Evrensel kesme aktif
 INTCON.PEIE=1; // �evresel ayg�t kesmesi aktif
 PIE1.TMR1IE=1; // Timer1 kesmesi aktif
 T1CON=0X0F; // Prescaler 1:1 Timer1 hariciosilat�r kayna��ndan
             // a��l�yor

}
void main2() {
 ayarlar2();
 while(1){
   if(!kesmeTMR10){
    asm{
      sleep
     }
   }
   if(kesmeTMR10){
    if(saniye>59){
     dakika++;
     saniye=0;
     if(dakika>59){
      saat++;
      dakika=0;
      if(saat>24) saat=0;
     }
    }
    kesmeTMR10=0;
   }
    asm{
   MOVWF 0x20 // ak�m�lat�r veri belle�inin 0.bank�n�n 20h adresine yaz�l�r
   MOVFF STATUS, 0x21 // Veri belle�inin 0.bank�n�n 21h adresine yaz�l�r
   MOVFF BSR, 0x22 // Veri belle�inin 0.bank�n�n 22h adresine yaz�l�r
  }
 }
}

void Kesme_yordami2() iv 0x000008{
 if(PIR1.TMR1IF){ //Timer1 kesmesi mi?
  kesmeTMR10=1;
  saniye++;
  asm{
   BTFSC TMR1L, 0 //TMR1L'nin 0 oldu�u garanti
   BRA $-2        //edilene kadar d�n�yor
  }
   TMR1H=0x80;
   PIR1.TMR1IF=0;
 }
  asm{
  MOVFF 0x22, BSR  //22h adresindeki veri BSR kaydedicisine y�klenir
  MOVF 0x20, 0, 0 //20h adresindeki veri ak�m�lat�re y�klenir
  MOVFF 0x21, STATUS //21h adresindeki veri STATUS kaydedicisine y�klenir
 }
}
       /*
void main(){
 .
 .
 .
 while(1){
  .
  .
  .
  asm{
   MOVWF 20h // ak�m�lat�r veri belle�inin 0.bank�n�n 20h adresine yaz�l�r
   MOVFF STATUS, 21h // Veri belle�inin 0.bank�n�n 21h adresine yaz�l�r
   MOVFF BSR, 22h // Veri belle�inin 0.bank�n�n 22h adresine yaz�l�r
  }
  .
  .
  .
}
void interrupt(){
 .
 .
 asm{
  MOVFF 22h, BSR  //22h adresindeki veri BSR kaydedicisine y�klenir
  MOVF 20h, 0, 0 //20h adresindeki veri ak�m�lat�re y�klenir
  MOVFF 21h, STATUS //21h adresindeki veri STATUS kaydedicisine y�klenir
 }
}   */