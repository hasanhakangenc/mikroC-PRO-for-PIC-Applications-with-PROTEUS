unsigned int i;
char msj01[] = "MOTOR DEVRI= ";
char msj02[6];

char *pointer_msj01, *pointer_msj02;   //pointer t�r�nde de�i�ken
unsigned int uzunluk_msj01, uzunluk_msj02, konum, devir, son_devir, sayac=1;

sbit LCD_RS at RB0_bit; //LCD ba�lant�lar� ayarlan�yor
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB2_bit;
sbit LCD_D5 at RB3_bit;
sbit LCD_D6 at RB4_bit;
sbit LCD_D7 at RB5_bit;

sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;

void ayarlar(){
 TRISA=0X10;
 PORTA=0;
 TRISB=0x00;
 PORTB=0;
 Lcd_Init(); // Lcd_Init PORTB LCD i�in haz�rland�
 CMCON=0x07; // Kar��la�t�r�c� mod�lleri dijitale ayarland�
 OPTION_REG  = 0b00110000;   /*�n �l�ekleyici (prescaler) 2 olarak ayarlan�yor, harici saat darbesi i�in T0CKI giri�i aktif */
 INTCON.GIE = 1; // Evrensel kesme aktif yap�l�yor
 INTCON.T0IE = 1; // Timer0 kesmesi aktifle�tirildi
 TMR0 = 255; //Timer0 de�eri 255 olarak ayarlan�yor
 T1CON = 0B00000111;
 Delay_us(50);
 TMR1H=0X00;
 TMR1L=0X00;
 
}
void main() {
 ayarlar();
  Lcd_out(1,1,msj01);
 while(1){
  WordtoStr(devir,msj02);//2byte'l�k bilgi string mesaja �evriliyor
  Lcd_out(2,5,msj02);
  delay_ms(100);
 }
}

void interrupt()
{
 if(INTCON.T0IF){ //Timer0 kesmesi mi?
  T1CON.TMR1ON=0;
  devir = ((TMR1H << 8) + TMR1L);
  Delay_us(50);
  TMR1H=0X00;
  TMR1L=0X00;
  T1CON.TMR1ON=1;
  INTCON.T0IF=0; //TMR0 bayra�� siliniyor ki tekrar kesme ger�ekle�ebilsin
  TMR0=255;     //TMR0 sayac� de�eri tekrar y�kleniyor 0 255 aras�
 }
}