#define LED_TMR3 PORTA.RA1
#define T1CKI PORTC.RC0
unsigned int zaman1, zaman2;
void ayarlar(){
 PORTB=0;
 CMCON=0X07; // Analog kar��la�t�r�c�lar kapal�
 ADCON0=0; // A/D mod�l� kapal�
 ADCON1=0X0F; // T�m AN kanallar� dijital I/O olarak ayarl�
 TRISB=0;
 TRISA=0;
 PORTA=0;
 TRISC=0x01;
 PORTC=0;
 INTCON.GIE=1; // Evrensel kesme aktif
 INTCON.PEIE=1; // �evresel ayg�t kesmesi aktif
 PIE2.TMR3IE=1; // Timer3 kesmesi aktif
 OSCCON=0X70; // 8MHz dahili osilat�r
}
void timer3_ayar(){
 T3CON.T3CKPS1=0;
 T3CON.T3CKPS0=0; // Timer3 prescaler 1:1
 T3CON.TMR3CS=1; // T1CKI giri�i saat darbesi kayna��
 T3CON.T3SYNC=1;
 TMR3H=0XFF;
 TMR3L=0XFE; // 65535 de�eri ba�lang�� olarak y�kleniyor
 Delay_ms(50);
 T3CON.TMR3ON=1;
}
void main() {
 ayarlar();
 timer3_ayar();
/* while(1){
     asm{
      sleep
     }
  } */
}
void interrupt(){
 if(PIR2.TMR3IF){ //Timer3 kesmesi mi?
   LED_TMR3=1;
     Delay_ms(1000);
        LED_TMR3=0;
     T3CON.TMR3ON=0;
     Delay_us(50);
     TMR3H=0XFF;
     TMR3L=0XFE;
     T3CON.TMR3ON=1;
     PIR2.TMR3IF=0;
 }
}